# FAZBEAR CONTROL Android App

This is the Android Studio project for the FNAF-style phone controller.

## Features
- Matches the 480x320 ESP32 controller visual layout.
- Freddy, Bonnie, Chica, Stage pages.
- Four ESP32 IP targets.
- Animation slots 1-8.
- Play, pause, stop, restart, previous/next.
- Play All.
- Autoplay next animation when an ESP32 sends `ANIM_DONE`.
- Volume control using `[VOLUME n]`.
- Wireless serial/debug monitor on UDP port 4211.
- Settings/test/status commands.
- Uses the existing character images.

## ESP32 UDP control
Control commands are sent to UDP port 4210:
[START 1]
[PAUSE]
[RESUME]
[STOP]
[RESTART]
[RESET]
[VOLUME 80]
[STATUS]

## Wireless serial/debug
The app listens on UDP port 4211. For example, the ESP32 can send:
[DEBUG] AUDIO: STARTING PLAYBACK
[DEBUG] Running after START: YES
ANIM_DONE 1

`ANIM_DONE 1` can be used by the app's Autoplay feature to start the next animation.

## Build
Open the `FazbearControlApp` folder in Android Studio.
Let Gradle sync, then:
Build -> Build APK(s)

The project is Java-only and has no third-party dependencies.

## GitHub Actions APK build

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.
It builds the debug APK in the cloud and uploads it as `Fazbear-Control-debug-apk`.
No Android Studio is required for the GitHub build.


Orientation: Portrait (phone app is locked to portrait mode).


Portrait layout: the app uses a native vertical 360x800 layout scaled proportionally to the phone display. It no longer letterboxes a landscape 480x320 screen.

Menu screen uses the supplied animated menu.gif. App runs immersive portrait to keep Android system bars from covering the UI.

Controller IP configuration: Settings > tap a controller's displayed IP address to edit it. Addresses are saved on the phone; TEST sends [STATUS] to that controller. DEFAULT restores the original address.
