package com.fazbear.control;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.*;
import android.view.*;
import android.content.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    FazbearView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        view = new FazbearView(this);
        setContentView(view);
    }

    @Override protected void onDestroy() {
        if (view != null) view.shutdown();
        super.onDestroy();
    }
}

class FazbearView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService net = Executors.newCachedThreadPool();
    final DatagramSocket rxSocket;
    final SharedPreferences prefs;

    final String[] names = {"FREDDY", "BONNIE", "CHICA", "STAGE"};
    final String[] defaultIPs = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
    final String[] ips = new String[4];
    final String[] animNames = {"Idle", "Welcome Show", "Song 1", "Song 2", "Wave", "Point", "Laugh", "Custom"};
    final Bitmap[] chars = new Bitmap[4];

    static final int HOME = 0, DEVICES = 1, TIMELINE = 2, CONTROL = 3, SETTINGS = 4, DEBUG = 5, DEVICE_DETAIL = 6;

    int screen = HOME;
    int page = 0;
    int selectedAnimation = 1;
    boolean autoplay = false;
    boolean loop = false;
    boolean[] online = new boolean[4];
    long[] lastSeen = new long[4];
    String[] playing = {"Idle", "Idle", "Idle", "Stage Lights"};
    int[] progress = {0, 0, 0, 0};
    int syncedVolume = -1;
    ArrayList<String> log = new ArrayList<>();
    String status = "SYSTEM READY";
    String errorTitle = "";
    String errorMessage = "";
    String errorDetails = "";
    boolean errorPopup = false;
    int theme = 0;

    FazbearView(Context c) {
        super(c);
        setFocusable(true);
        prefs = c.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        for (int i = 0; i < 4; i++) ips[i] = prefs.getString("ip" + i, defaultIPs[i]);
        theme = prefs.getInt("theme", 0);

        chars[0] = load(c, "freddy");
        chars[1] = load(c, "bonnie");
        chars[2] = load(c, "chica");
        chars[3] = load(c, "stage");

        DatagramSocket s = null;
        try {
            s = new DatagramSocket(4211);
            s.setBroadcast(true);
            addLog("UDP RX READY  //  PORT 4211");
        } catch (Exception e) {
            addLog("UDP RX ERROR: " + e.getMessage());
            showError("NETWORK ERROR", "Unable to open UDP 4211", String.valueOf(e.getMessage()));
        }
        rxSocket = s;
        if (rxSocket != null) startReceiver();
        addLog("FAZBEAR CONTROL ONLINE");

        main.postDelayed(() -> {
            for (int i = 0; i < 4; i++) {
                if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
            }
            invalidate();
            main.postDelayed(this::tick, 1000);
        }, 1000);
    }

    void tick() {
        for (int i = 0; i < 4; i++) {
            if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
        }
        invalidate();
        main.postDelayed(this::tick, 1000);
    }

    Bitmap load(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(getResources(), id);
    }

    void startReceiver() {
        net.execute(() -> {
            byte[] buf = new byte[2048];
            while (rxSocket != null && !rxSocket.isClosed()) {
                try {
                    DatagramPacket d = new DatagramPacket(buf, buf.length);
                    rxSocket.receive(d);
                    String msg = new String(d.getData(), d.getOffset(), d.getLength()).trim();
                    final String host = d.getAddress().getHostAddress();
                    main.post(() -> handlePacket(host, msg));
                } catch (Exception ignored) {}
            }
        });
    }

    void handlePacket(String host, String msg) {
        int idx = indexForHost(host);
        if (idx >= 0) {
            online[idx] = true;
            lastSeen[idx] = System.currentTimeMillis();
        }
        addLog(host + " > " + msg);

        int v = parseVolume(msg);
        if (v >= 0) {
            syncedVolume = v;
            status = "VOLUME " + v + "%  //  ESP32 POT";
        }

        if (msg.toUpperCase(Locale.US).contains("ANIM_DONE")) {
            if (idx >= 0) {
                progress[idx] = 100;
                if (autoplay) {
                    int next = selectedAnimation >= 8 ? 1 : selectedAnimation + 1;
                    selectedAnimation = next;
                    playing[idx] = animNames[next - 1];
                    send(idx, "[START " + next + "]");
                }
            }
        }
        invalidate();
    }

    int indexForHost(String host) {
        for (int i = 0; i < 4; i++) if (ips[i].equals(host)) return i;
        return -1;
    }

    int parseVolume(String msg) {
        String u = msg.toUpperCase(Locale.US);
        int i = u.indexOf("VOLUME");
        if (i < 0) return -1;
        i += 6;
        while (i < u.length() && !Character.isDigit(u.charAt(i))) i++;
        if (i >= u.length()) return -1;
        int start = i;
        while (i < u.length() && Character.isDigit(u.charAt(i))) i++;
        try { return Math.max(0, Math.min(100, Integer.parseInt(u.substring(start, i)))); }
        catch (Exception e) { return -1; }
    }

    void addLog(String s) {
        log.add(timeStamp() + "  " + s);
        while (log.size() > 160) log.remove(0);
        invalidate();
    }

    String timeStamp() {
        long n = System.currentTimeMillis() / 1000;
        return String.format(Locale.US, "%02d:%02d:%02d", (n / 3600) % 24, (n / 60) % 60, n % 60);
    }

    void send(int which, String cmd) {
        if (which < 0 || which > 3) return;
        final String ip = ips[which];
        addLog(ip + " < " + cmd);
        net.execute(() -> {
            try {
                byte[] data = cmd.getBytes("UTF-8");
                DatagramPacket dp = new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210);
                DatagramSocket s = new DatagramSocket();
                s.setBroadcast(true);
                s.send(dp);
                s.close();
                main.post(() -> {
                    online[which] = true;
                    lastSeen[which] = System.currentTimeMillis();
                    invalidate();
                });
            } catch (Exception e) {
                main.post(() -> {
                    addLog("SEND ERROR " + ip + ": " + e.getMessage());
                    showError("COMMAND FAILED", "Could not reach ESP32 " + names[which],
                            "Target: " + ip + "\nUDP command port: 4210\n" + e.getMessage());
                });
            }
        });
    }

    void broadcast(String cmd) { for (int i = 0; i < 4; i++) send(i, cmd); }

    void play(int i, int anim) {
        selectedAnimation = anim;
        playing[i] = animNames[anim - 1];
        progress[i] = 0;
        send(i, "[START " + anim + "]");
        status = names[i] + "  //  PLAYING " + animNames[anim - 1];
    }

    void playAll() {
        for (int i = 0; i < 4; i++) {
            if (i == 3) playing[i] = "Stage Lights";
            else playing[i] = animNames[selectedAnimation - 1];
            progress[i] = 0;
        }
        broadcast("[START " + selectedAnimation + "]");
        status = "PLAY ALL  //  " + animNames[selectedAnimation - 1];
    }

    void showError(String title, String message, String details) {
        errorTitle = title;
        errorMessage = message;
        errorDetails = details == null ? "" : details;
        errorPopup = true;
        invalidate();
    }

    void retryError() {
        errorPopup = false;
        send(page, "[STATUS]");
        status = "STATUS REQUEST SENT";
        invalidate();
    }

    void shutdown() {
        try { if (rxSocket != null) rxSocket.close(); } catch (Exception ignored) {}
        net.shutdownNow();
    }

    int accent() { return theme == 1 ? Color.CYAN : (theme == 2 ? Color.YELLOW : 0xFFB000FF); }
    int red() { return 0xFFFF1744; }
    int panel() { return 0xFF090B14; }
    int panel2() { return 0xFF111525; }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(size); p.setColor(color); p.setTextAlign(a); p.setStyle(Paint.Style.FILL);
        c.drawText(s, x, y, p);
    }

    void rect(Canvas c, float l, float t, float r, float b, int color, boolean stroke) {
        p.setColor(color); p.setStyle(stroke ? Paint.Style.STROKE : Paint.Style.FILL); p.setStrokeWidth(stroke ? 1.5f : 1);
        c.drawRect(l, t, r, b, p); p.setStyle(Paint.Style.FILL);
    }

    void button(Canvas c, int x, int y, int w, int h, String label, int color) {
        p.setColor(panel2()); c.drawRoundRect(x, y, x + w, y + h, 7, 7, p);
        rect(c, x, y, x + w, y + h, color, true);
        text(c, label, x + w / 2f, y + h / 2f + 4, 7, Color.WHITE, Paint.Align.CENTER);
    }

    void background(Canvas c) {
        c.drawColor(Color.BLACK);
        for (int y = 0; y < 320; y += 20) {
            p.setColor((y / 20) % 2 == 0 ? 0xFF070711 : 0xFF0A0810);
            c.drawRect(0, y, 480, y + 20, p);
        }
        rect(c, 2, 2, 478, 318, accent(), true);
    }

    void title(Canvas c, String s, String sub) {
        text(c, "FAZBEAR CONTROL", 12, 18, 10, Color.WHITE, Paint.Align.LEFT);
        text(c, s, 240, 20, 14, accent(), Paint.Align.CENTER);
        if (sub != null) text(c, sub, 240, 34, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, syncedVolume >= 0 ? (syncedVolume + "%") : "--%", 468, 16, 7, Color.WHITE, Paint.Align.RIGHT);
        text(c, "VOL SYNC", 468, 28, 5, Color.LTGRAY, Paint.Align.RIGHT);
        rect(c, 8, 40, 472, 41, accent(), false);
    }

    void nav(Canvas c, int selected) {
        rect(c, 0, 276, 480, 320, 0xFF05060B, false);
        String[] n = {"HOME", "DEVICES", "TIMELINE", "CONTROL", "SETTINGS", "DEBUG"};
        for (int i = 0; i < 6; i++) {
            int x = i * 80;
            int col = i == selected ? accent() : Color.LTGRAY;
            text(c, navIcon(i), x + 40, 292, 11, col, Paint.Align.CENTER);
            text(c, n[i], x + 40, 309, 5.5f, col, Paint.Align.CENTER);
        }
    }

    String navIcon(int i) { return new String[]{"⌂", "▣", "≋", "▶", "⚙", "!"}[i]; }

    @Override protected void onDraw(Canvas real) {
        float sx = getWidth() / 480f, sy = getHeight() / 320f;
        real.save(); real.scale(sx, sy);
        Canvas c = real;
        background(c);
        switch (screen) {
            case HOME: drawHome(c); break;
            case DEVICES: drawDevices(c); break;
            case TIMELINE: drawTimeline(c); break;
            case CONTROL: drawControl(c); break;
            case SETTINGS: drawSettings(c); break;
            case DEBUG: drawDebug(c); break;
            case DEVICE_DETAIL: drawDeviceDetail(c); break;
        }
        if (screen != DEVICE_DETAIL) nav(c, screen);
        if (errorPopup) drawErrorPopup(c);
        real.restore();
    }

    void image(Canvas c, Bitmap b, RectF dst) {
        if (b == null) return;
        Rect src = new Rect(0, 0, b.getWidth(), b.getHeight());
        c.drawBitmap(b, src, dst, p);
    }

    void drawHome(Canvas c) {
        title(c, "HOME", "WIRELESS SHOW CONTROL");
        image(c, chars[0], new RectF(15, 50, 230, 178));
        text(c, "FAZBEAR", 245, 74, 22, Color.WHITE, Paint.Align.LEFT);
        text(c, "CONTROL", 245, 98, 22, red(), Paint.Align.LEFT);
        text(c, "4 ESP32 CONTROLLERS", 245, 119, 7, Color.LTGRAY, Paint.Align.LEFT);
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, on + " / 4 ONLINE", 245, 137, 12, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        button(c, 245, 148, 105, 31, "START SHOW", accent());
        button(c, 360, 148, 105, 31, "DEBUG", Color.DKGRAY);

        button(c, 15, 190, 106, 42, "DEVICES", accent());
        button(c, 130, 190, 106, 42, "TIMELINE", accent());
        button(c, 245, 190, 106, 42, "CONTROL", accent());
        button(c, 360, 190, 105, 42, "SETTINGS", accent());
        text(c, "PHYSICAL ESP32 POTENTIOMETER = VOLUME SOURCE", 240, 250, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, status, 240, 265, 6, Color.WHITE, Paint.Align.CENTER);
        nav(c, HOME);
    }

    void deviceCard(Canvas c, int i, int y) {
        int a = i == page ? accent() : 0xFF263044;
        rect(c, 10, y, 470, y + 48, panel2(), false);
        rect(c, 10, y, 470, y + 48, a, true);
        image(c, chars[i], new RectF(16, y + 4, 68, y + 44));
        text(c, "ESP32 - " + names[i], 78, y + 15, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, ips[i], 78, y + 28, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, online[i] ? "● ONLINE" : "● OFFLINE", 78, y + 40, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "Playing: " + playing[i], 205, y + 16, 6.5f, Color.WHITE, Paint.Align.LEFT);
        text(c, "Animation " + String.format(Locale.US, "%02d", i == 3 ? 5 : selectedAnimation), 205, y + 29, 6, accent(), Paint.Align.LEFT);
        button(c, 372, y + 7, 45, 30, "PLAY", Color.GREEN);
        button(c, 423, y + 7, 40, 30, "…", a);
    }

    void drawDevices(Canvas c) {
        title(c, "DEVICES", "4 ESP32 CONTROLLERS");
        for (int i = 0; i < 4; i++) deviceCard(c, i, 47 + i * 51);
        text(c, "TAP A DEVICE FOR ANIMATIONS + PLAYBACK", 240, 262, 5.5f, Color.LTGRAY, Paint.Align.CENTER);
        nav(c, DEVICES);
    }

    void drawDeviceDetail(Canvas c) {
        title(c, "ESP32 - " + names[page], ips[page]);
        button(c, 10, 48, 55, 26, "BACK", accent());
        image(c, chars[page], new RectF(75, 48, 175, 112));
        text(c, online[page] ? "● ONLINE" : "● OFFLINE", 190, 61, 7, online[page] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "NOW PLAYING", 190, 78, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, playing[page], 190, 94, 11, Color.WHITE, Paint.Align.LEFT);
        text(c, "VOLUME  " + (syncedVolume >= 0 ? syncedVolume + "%" : "--%") + "  •  ESP32 POT", 190, 108, 6, Color.LTGRAY, Paint.Align.LEFT);

        text(c, "ANIMATIONS", 12, 132, 8, accent(), Paint.Align.LEFT);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 4, row = (i - 1) / 4;
            int x = 12 + col * 116, y = 140 + row * 30;
            button(c, x, y, 105, 23, String.format(Locale.US, "%02d  %s", i, animNames[i - 1]), i == selectedAnimation ? accent() : 0xFF303444);
        }
        button(c, 12, 205, 92, 29, "PLAY", Color.GREEN);
        button(c, 112, 205, 92, 29, "PAUSE", Color.YELLOW);
        button(c, 212, 205, 92, 29, "STOP", red());
        button(c, 312, 205, 92, 29, "RESTART", accent());
        button(c, 412, 205, 56, 29, "BACK", 0xFF303444);
        text(c, "AUTOPLAY NEXT", 15, 252, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, autoplay ? "ON" : "OFF", 110, 252, 7, autoplay ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "UDP 4210", 470, 252, 6, Color.LTGRAY, Paint.Align.RIGHT);
    }

    void drawTimeline(Canvas c) {
        title(c, "TIMELINE", "AUDIO PLAYBACK");
        text(c, "NOW PLAYING", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "Five Nights at Freddy's - Show", 15, 73, 9, Color.WHITE, Paint.Align.LEFT);
        rect(c, 12, 84, 392, 146, panel2(), false);
        rect(c, 12, 84, 392, 146, accent(), true);
        p.setStrokeWidth(2);
        for (int x = 16; x < 390; x += 4) {
            double wave = Math.sin(x * 0.12) * 13 + Math.sin(x * 0.31) * 6 + Math.sin(x * 0.61) * 3;
            p.setColor(x % 24 < 8 ? 0xFFFF1744 : accent());
            c.drawLine(x, 115, x, (float)(115 + wave), p);
        }
        rect(c, 188, 86, 190, 144, Color.WHITE, false);
        text(c, "1:24 / 3:45", 202, 160, 7, Color.WHITE, Paint.Align.CENTER);
        text(c, "L", 420, 92, 6, Color.WHITE, Paint.Align.CENTER);
        text(c, "R", 458, 92, 6, Color.WHITE, Paint.Align.CENTER);
        for (int i = 0; i < 8; i++) {
            int h = 12 + (i % 5) * 5;
            rect(c, 415, 142 - h, 430, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
            rect(c, 448, 142 - h, 463, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
        }
        button(c, 35, 170, 65, 30, "-5s", accent());
        button(c, 108, 170, 80, 30, "◀◀", accent());
        button(c, 198, 166, 44, 38, "Ⅱ", accent());
        button(c, 252, 170, 80, 30, "▶▶", accent());
        button(c, 340, 170, 65, 30, "+5s", accent());
        text(c, "CURRENT EVENT", 15, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "Freddy Move", 15, 238, 9, Color.WHITE, Paint.Align.LEFT);
        text(c, "00:45", 120, 238, 7, accent(), Paint.Align.LEFT);
        text(c, "PHYSICAL VOLUME", 280, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%" : "WAITING", 280, 238, 10, Color.WHITE, Paint.Align.LEFT);
        nav(c, TIMELINE);
    }

    void drawControl(Canvas c) {
        title(c, "SHOW CONTROL", "MULTI-ESP32");
        text(c, "SELECTED ANIMATION", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation - 1]), 15, 76, 12, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 92, 106, 40, "PLAY ALL", Color.GREEN);
        button(c, 129, 92, 106, 40, "PAUSE ALL", Color.YELLOW);
        button(c, 243, 92, 106, 40, "STOP ALL", red());
        button(c, 357, 92, 108, 40, "RESTART", accent());
        for (int i = 0; i < 4; i++) {
            int x = 15 + (i % 2) * 230, y = 145 + (i / 2) * 48;
            rect(c, x, y, x + 215, y + 40, panel2(), false);
            text(c, names[i], x + 10, y + 15, 7, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "ONLINE" : "OFFLINE", x + 10, y + 29, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, playing[i], x + 85, y + 22, 7, accent(), Paint.Align.LEFT);
        }
        button(c, 15, 243, 140, 25, loop ? "LOOP ON" : "LOOP OFF", loop ? Color.GREEN : Color.DKGRAY);
        button(c, 165, 243, 140, 25, autoplay ? "AUTO NEXT ON" : "AUTO NEXT OFF", autoplay ? Color.GREEN : Color.DKGRAY);
        nav(c, CONTROL);
    }

    void drawSettings(Canvas c) {
        title(c, "SETTINGS", "APP + CONTROLLER STATUS");
        text(c, "CONTROLLER IP ADDRESSES", 15, 57, 7, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            int y = 65 + i * 40;
            text(c, names[i], 15, y + 17, 7, Color.WHITE, Paint.Align.LEFT);
            rect(c, 92, y, 280, y + 27, panel2(), false);
            text(c, ips[i], 102, y + 18, 7, Color.WHITE, Paint.Align.LEFT);
            button(c, 292, y, 75, 27, "TEST", accent());
            text(c, online[i] ? "ONLINE" : "OFFLINE", 382, y + 17, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        }
        text(c, "VOLUME IS READ-ONLY", 15, 239, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%  •  SYNCED FROM ESP32 POT" : "WAITING FOR ESP32", 160, 239, 6, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 250, 110, 25, theme == 0 ? "NEON PURPLE" : "CYAN THEME", accent());
        button(c, 135, 250, 110, 25, "DEBUG", Color.DKGRAY);
        button(c, 255, 250, 110, 25, "CLEAR LOG", red());
        nav(c, SETTINGS);
    }

    void drawDebug(Canvas c) {
        title(c, "DEBUG", "WIRELESS SERIAL + DIAGNOSTICS");
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, "UDP RX 4211", 12, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "UDP TX 4210", 110, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, on + "/4 ONLINE", 220, 56, 7, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "VOLUME " + (syncedVolume >= 0 ? syncedVolume + "%" : "WAITING"), 330, 56, 7, Color.WHITE, Paint.Align.LEFT);
        rect(c, 10, 64, 470, 242, panel2(), false);
        int start = Math.max(0, log.size() - 11), y = 80;
        for (int i = start; i < log.size(); i++) {
            String s = log.get(i);
            if (s.length() > 74) s = s.substring(0, 74);
            text(c, s, 16, y, 5.5f, Color.LTGRAY, Paint.Align.LEFT);
            y += 15;
        }
        button(c, 12, 248, 95, 25, "CLEAR", red());
        button(c, 115, 248, 95, 25, "STATUS", accent());
        button(c, 218, 248, 110, 25, "TEST ALL", Color.GREEN);
        text(c, "ERROR POPUP: READY", 345, 264, 5.5f, errorPopup ? red() : Color.GREEN, Paint.Align.CENTER);
        nav(c, DEBUG);
    }

    void drawErrorPopup(Canvas c) {
        rect(c, 0, 0, 480, 320, 0x99000000, false);
        int l = 42, t = 67, r = 438, b = 252;
        rect(c, l, t, r, b, 0xFF10050A, false);
        rect(c, l, t, r, b, red(), true);
        text(c, "⚠  SYSTEM ERROR", 240, 92, 13, red(), Paint.Align.CENTER);
        text(c, errorTitle, 240, 116, 9, Color.WHITE, Paint.Align.CENTER);
        text(c, errorMessage, 240, 139, 8, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "Details are available in DEBUG.", 240, 160, 6, Color.LTGRAY, Paint.Align.CENTER);
        button(c, 62, 191, 100, 34, "RETRY", accent());
        button(c, 190, 191, 100, 34, "DETAILS", Color.WHITE);
        button(c, 318, 191, 100, 34, "CLOSE", red());
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;
        float x = e.getX() * 480f / getWidth();
        float y = e.getY() * 320f / getHeight();

        if (errorPopup) {
            if (y >= 185 && y <= 235) {
                if (x < 175) retryError();
                else if (x < 305) { errorPopup = false; screen = DEBUG; invalidate(); }
                else { errorPopup = false; invalidate(); }
            }
            return true;
        }

        if (screen == DEVICE_DETAIL) return touchDeviceDetail(x, y);
        if (y >= 276) {
            int n = Math.max(0, Math.min(5, (int)(x / 80)));
            screen = n;
            invalidate();
            return true;
        }

        if (screen == HOME) {
            if (y >= 145 && y < 185 && x >= 235 && x < 355) { playAll(); invalidate(); return true; }
            if (y >= 145 && y < 185 && x >= 355) { screen = DEBUG; invalidate(); return true; }
            if (y >= 188 && y < 238) {
                if (x < 120) screen = DEVICES;
                else if (x < 240) screen = TIMELINE;
                else if (x < 355) screen = CONTROL;
                else screen = SETTINGS;
                invalidate(); return true;
            }
        } else if (screen == DEVICES) {
            if (y >= 47 && y < 251) {
                int i = (int)((y - 47) / 51);
                if (i >= 0 && i < 4) { page = i; screen = DEVICE_DETAIL; invalidate(); return true; }
            }
        } else if (screen == TIMELINE) {
            if (y >= 165 && y < 210 && x < 100) { status = "SEEK -5s"; invalidate(); return true; }
            if (y >= 165 && y < 210 && x >= 108 && x < 188) { broadcast("[PAUSE]"); status = "PAUSED"; invalidate(); return true; }
            if (y >= 165 && y < 210 && x >= 198 && x < 242) { broadcast("[PAUSE]"); status = "PLAY/PAUSE"; invalidate(); return true; }
            if (y >= 165 && y < 210 && x >= 252 && x < 340) { status = "SEEK +5s"; invalidate(); return true; }
        } else if (screen == CONTROL) {
            if (y >= 92 && y < 135) {
                if (x < 125) playAll();
                else if (x < 240) { broadcast("[PAUSE]"); status = "PAUSE ALL"; }
                else if (x < 355) { broadcast("[STOP]"); status = "STOP ALL"; }
                else { broadcast("[RESTART]"); status = "RESTART ALL"; }
                invalidate(); return true;
            }
            if (y >= 243 && y < 273) {
                if (x < 155) loop = !loop;
                else if (x < 310) autoplay = !autoplay;
                invalidate(); return true;
            }
        } else if (screen == SETTINGS) {
            for (int i = 0; i < 4; i++) {
                int yy = 65 + i * 40;
                if (y >= yy && y <= yy + 27 && x >= 292 && x <= 367) { send(i, "[STATUS]"); status = "STATUS TEST " + names[i]; invalidate(); return true; }
            }
            if (y >= 250 && y < 278) {
                if (x < 125) { theme = (theme + 1) % 3; prefs.edit().putInt("theme", theme).apply(); }
                else if (x < 245) screen = DEBUG;
                else if (x < 365) { log.clear(); invalidate(); return true; }
                invalidate(); return true;
            }
        } else if (screen == DEBUG) {
            if (y >= 248 && y < 278) {
                if (x < 110) log.clear();
                else if (x < 220) send(page, "[STATUS]");
                else if (x < 335) for (int i = 0; i < 4; i++) send(i, "[STATUS]");
                invalidate(); return true;
            }
        }
        return true;
    }

    boolean touchDeviceDetail(float x, float y) {
        if (y >= 48 && y <= 78 && x < 70) { screen = DEVICES; invalidate(); return true; }
        if (y >= 140 && y < 200) {
            int col = (int)((x - 12) / 116), row = (int)((y - 140) / 30);
            if (col >= 0 && col < 4 && row >= 0 && row < 2) {
                int a = row * 4 + col + 1;
                selectedAnimation = a;
                play(page, a);
                invalidate(); return true;
            }
        }
        if (y >= 205 && y < 240) {
            if (x < 104) { play(page, selectedAnimation); }
            else if (x < 204) { send(page, "[PAUSE]"); status = "PAUSED " + names[page]; }
            else if (x < 304) { send(page, "[STOP]"); status = "STOPPED " + names[page]; }
            else if (x < 404) { send(page, "[RESTART]"); progress[page] = 0; status = "RESTARTED " + names[page]; }
            else { screen = DEVICES; }
            invalidate(); return true;
        }
        if (y >= 240 && y < 270 && x < 160) { autoplay = !autoplay; invalidate(); return true; }
        return true;
    }
}
