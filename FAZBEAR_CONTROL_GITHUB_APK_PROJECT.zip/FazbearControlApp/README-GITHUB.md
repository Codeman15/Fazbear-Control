# Fazbear Control — GitHub APK Build

This project is ready to build as an Android APK using GitHub Actions. No Android Studio is required on your phone or PC.

## Build the APK

1. Create a GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build Fazbear Control APK**.
4. Choose **Run workflow**.
5. When the build finishes, open the completed workflow run.
6. Under **Artifacts**, download **Fazbear-Control-debug-apk**.
7. Extract the ZIP and install `app-debug.apk` on the Android phone.

GitHub Actions stores the generated APK as a workflow artifact. The workflow uses Gradle 8.7 and Java 17, matching this project's Android Gradle Plugin configuration.
