package com.fazbear.control;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.*;
import android.view.*;
import android.content.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    FazbearView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        view = new FazbearView(this);
        setContentView(view);
    }

    @Override protected void onDestroy() {
        if (view != null) view.shutdown();
        super.onDestroy();
    }
}

class FazbearView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService net = Executors.newCachedThreadPool();
    final DatagramSocket rxSocket;
    final SharedPreferences prefs;

    final String[] names = {"FREDDY", "BONNIE", "CHICA", "STAGE"};
    final String[] defaultIPs = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
    final String[] ips = new String[4];
    final Bitmap[] chars = new Bitmap[4];

    // Mirrors the ESP32 touchscreen controller.
    int page = 0;
    // 0 controller, 1 advanced, 2 looks, 3 debug, 4 animations, 5 serial, 6 settings.
    int screen = 0;
    int selectedAnimation = 1;
    boolean autoplay = false;
    boolean[] online = new boolean[4];
    long[] lastSeen = new long[4];
    ArrayList<String> log = new ArrayList<>();
    String status = "SYSTEM READY";
    int theme = 0;
    int brightness = 100;

    FazbearView(Context c) {
        super(c);
        setFocusable(true);
        prefs = c.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        for (int i = 0; i < 4; i++) ips[i] = prefs.getString("ip" + i, defaultIPs[i]);
        theme = prefs.getInt("theme", 0);
        brightness = prefs.getInt("brightness", 100);

        chars[0] = load(c, "freddy");
        chars[1] = load(c, "bonnie");
        chars[2] = load(c, "chica");
        chars[3] = load(c, "stage");

        DatagramSocket s = null;
        try {
            s = new DatagramSocket(4211);
            s.setBroadcast(true);
        } catch (Exception e) {
            addLog("SERIAL RX ERROR: " + e.getMessage());
        }
        rxSocket = s;
        if (rxSocket != null) startReceiver();
        addLog("FAZBEAR CONTROL ONLINE");
    }

    Bitmap load(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(getResources(), id);
    }

    void startReceiver() {
        net.execute(() -> {
            byte[] buf = new byte[2048];
            while (!rxSocket.isClosed()) {
                try {
                    DatagramPacket d = new DatagramPacket(buf, buf.length);
                    rxSocket.receive(d);
                    String msg = new String(d.getData(), d.getOffset(), d.getLength()).trim();
                    final String host = d.getAddress().getHostAddress();
                    main.post(() -> {
                        markOnline(host);
                        addLog(host + " > " + msg);
                        if (msg.contains("ANIM_DONE") && autoplay) {
                            int next = selectedAnimation + 1;
                            if (next <= 8) {
                                selectedAnimation = next;
                                sendToCurrent("[START " + selectedAnimation + "]");
                                status = "PLAYING ANIMATION " + selectedAnimation;
                                invalidate();
                            }
                        }
                    });
                } catch (Exception ignored) {}
            }
        });
    }

    void markOnline(String host) {
        for (int i = 0; i < 4; i++) {
            if (ips[i].equals(host)) {
                online[i] = true;
                lastSeen[i] = System.currentTimeMillis();
            }
        }
    }

    void addLog(String s) {
        log.add(String.format("%02d:%02d:%02d  %s",
                (System.currentTimeMillis() / 3600000) % 24,
                (System.currentTimeMillis() / 60000) % 60,
                (System.currentTimeMillis() / 1000) % 60, s));
        while (log.size() > 120) log.remove(0);
        invalidate();
    }

    void send(int which, String cmd) {
        if (which < 0 || which > 3) return;
        final String ip = ips[which];
        addLog(ip + " < " + cmd);
        net.execute(() -> {
            try {
                byte[] data = cmd.getBytes("UTF-8");
                DatagramPacket dp = new DatagramPacket(data, data.length,
                        InetAddress.getByName(ip), 4210);
                DatagramSocket s = new DatagramSocket();
                s.setBroadcast(true);
                s.send(dp);
                s.close();
                main.post(() -> {
                    online[which] = true;
                    lastSeen[which] = System.currentTimeMillis();
                    invalidate();
                });
            } catch (Exception e) {
                main.post(() -> addLog("SEND ERROR " + ip + ": " + e.getMessage()));
            }
        });
    }

    void sendToCurrent(String cmd) { send(page, cmd); }

    void broadcast(String cmd) {
        for (int i = 0; i < 4; i++) send(i, cmd);
    }

    void playCurrent() {
        sendToCurrent("[START " + selectedAnimation + "]");
        status = "PLAYING ANIMATION " + selectedAnimation;
    }

    void playAll() {
        broadcast("[START " + selectedAnimation + "]");
        status = "PLAY ALL  //  ANIMATION " + selectedAnimation;
    }

    void shutdown() {
        try { if (rxSocket != null) rxSocket.close(); } catch (Exception ignored) {}
        net.shutdownNow();
    }

    int accent() {
        if (theme == 1) return Color.CYAN;
        if (theme == 2) return Color.YELLOW;
        if (page == 0) return 0xFFFF8800;
        if (page == 1) return Color.MAGENTA;
        if (page == 2) return Color.YELLOW;
        return Color.WHITE;
    }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        p.setTextSize(size); p.setColor(color); p.setTextAlign(a);
        p.setStyle(Paint.Style.FILL);
        c.drawText(s, x, y, p);
    }

    void rect(Canvas c, float l, float t, float r, float b, int color, boolean stroke) {
        p.setColor(color);
        p.setStyle(stroke ? Paint.Style.STROKE : Paint.Style.FILL);
        p.setStrokeWidth(stroke ? 2 : 1);
        c.drawRect(l, t, r, b, p);
        p.setStyle(Paint.Style.FILL);
    }

    @Override protected void onDraw(Canvas real) {
        float sx = getWidth() / 480f, sy = getHeight() / 320f;
        real.save();
        real.scale(sx, sy);
        Canvas c = real;
        c.drawColor(Color.BLACK);
        switch (screen) {
            case 0: drawController(c); break;
            case 1: drawAdvanced(c); break;
            case 2: drawLooks(c); break;
            case 3: drawDebug(c); break;
            case 4: drawAnimations(c); break;
            case 5: drawSerial(c); break;
            default: drawSettings(c); break;
        }
        real.restore();
    }

    void frame(Canvas c, int a) {
        rect(c, 0, 0, 479, 319, Color.DKGRAY, true);
        rect(c, 2, 2, 477, 317, a, true);
    }

    void button(Canvas c, int x, int y, int w, int h, String label, int color) {
        p.setColor(Color.DKGRAY); p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(x, y, x + w, y + h, 6, 6, p);
        rect(c, x, y, x + w, y + h, Color.WHITE, true);
        rect(c, x + 2, y + 2, x + w - 2, y + h - 2, color, true);
        text(c, label, x + w / 2f, y + h / 2f + 4, 8, Color.WHITE, Paint.Align.CENTER);
    }

    void header(Canvas c, String title, int a) {
        rect(c, 1, 1, 479, 41, Color.DKGRAY, true);
        rect(c, 6, 40, 474, 42, a, false);
        button(c, 8, 4, 58, 34, "<", a);
        button(c, 414, 4, 58, 34, ">", a);
        text(c, "ESP32 " + (page + 1) + " / 4", 240, 18, 15, Color.WHITE, Paint.Align.CENTER);
        text(c, names[page], 240, 34, 8, a, Paint.Align.CENTER);
        text(c, "REC", 454, 14, 7, Color.RED, Paint.Align.RIGHT);
        p.setColor(Color.RED); c.drawCircle(462, 13, 3, p);
    }

    void drawImage(Canvas c) {
        if (chars[page] == null) return;
        Rect src = new Rect(0, 0, chars[page].getWidth(), chars[page].getHeight());
        RectF dst = new RectF(0, 43, 250, 214);
        c.drawBitmap(chars[page], src, dst, p);
    }

    void drawController(Canvas c) {
        int a = accent();
        frame(c, a);
        header(c, "CONTROL TERMINAL", a);
        drawImage(c);

        text(c, names[page], 12, 61, 15, a, Paint.Align.LEFT);
        if (page == 0) text(c, "CELEBRATE!", 12, 77, 7, 0xFFFF8800, Paint.Align.LEFT);
        else if (page == 1) text(c, "ROCK THE STAGE", 12, 77, 7, Color.MAGENTA, Paint.Align.LEFT);
        else if (page == 2) text(c, "LET'S EAT!", 12, 77, 7, Color.YELLOW, Paint.Align.LEFT);
        else text(c, "SHOW TIME!", 12, 77, 10, Color.WHITE, Paint.Align.LEFT);

        // Same status panel as the ESP32 touchscreen.
        rect(c, 252, 51, 472, 163, Color.BLACK, false);
        rect(c, 252, 51, 472, 163, Color.WHITE, true);
        rect(c, 254, 53, 470, 161, Color.DKGRAY, true);
        rect(c, 260, 55, 464, 59, a, false);
        text(c, "STATUS", 262, 69, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, online[page] ? "CONNECTED" : "OFFLINE", 330, 69, 8,
                online[page] ? Color.GREEN : Color.RED, Paint.Align.LEFT);
        text(c, "IP:", 262, 87, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, ips[page], 292, 87, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "AUDIO:", 262, 105, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, page == 3 ? "N/A" : "REMOTE", 320, 105, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "SD CARD:", 262, 123, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "REMOTE", 320, 123, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "ANIM:", 262, 141, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, page == 3 ? "N/A" : String.valueOf(selectedAnimation), 320, 141, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "UDP:", 370, 141, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "4210", 402, 141, 8, Color.WHITE, Paint.Align.LEFT);

        // Volume controller intentionally removed. The space is used for show status.
        text(c, "SHOW CONTROL", 360, 180, 8, a, Paint.Align.CENTER);
        text(c, status, 360, 195, 7, Color.LTGRAY, Paint.Align.CENTER);

        button(c, 12, 217, 132, 40, "RESET", Color.RED);
        button(c, 153, 217, 112, 40, "ADV", Color.WHITE);
        button(c, 277, 217, 55, 40, "ANIM", a);

        drawFooter(c, a);
    }

    void drawFooter(Canvas c, int a) {
        for (int y = 282; y < 320; y += 16) {
            for (int x = 0; x < 480; x += 16) {
                p.setColor((((x / 16) + (y / 16)) & 1) == 0 ? Color.DKGRAY : Color.BLACK);
                c.drawRect(x, y, x + 16, y + 16, p);
            }
        }
        rect(c, 0, 282, 480, 284, Color.WHITE, false);
        text(c, "FIVE NIGHTS", 10, 296, 7, Color.RED, Paint.Align.LEFT);
        text(c, "AT FREDDY'S", 10, 309, 7, Color.RED, Paint.Align.LEFT);
        text(c, "FAZBEAR SECURITY", 190, 297, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "CONTROL TERMINAL", 190, 309, 7, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            p.setColor(i == page ? a : Color.DKGRAY);
            c.drawCircle(225 + i * 10, 311, 3, p);
        }
        button(c, 392, 286, 36, 28, "<", a);
        button(c, 435, 286, 36, 28, ">", a);
    }

    void drawAdvanced(Canvas c) {
        int a = accent();
        frame(c, a);
        text(c, "ADVANCED", 240, 28, 18, a, Paint.Align.CENTER);
        text(c, "ESP32 #" + (page + 1) + "  " + names[page], 12, 48, 8, Color.LTGRAY, Paint.Align.LEFT);

        button(c, 20, 62, 205, 65, "LOOKS", a);
        text(c, "Display / visual settings", 122, 112, 7, Color.WHITE, Paint.Align.CENTER);
        button(c, 255, 62, 205, 65, "DEBUG", a);
        text(c, "Network / hardware info", 357, 112, 7, Color.WHITE, Paint.Align.CENTER);

        button(c, 20, 140, 205, 55, "ANIMATIONS", a);
        text(c, "8 Bottango slots", 122, 181, 7, Color.LTGRAY, Paint.Align.CENTER);
        button(c, 255, 140, 205, 55, "SERIAL", a);
        text(c, "Wireless debug monitor", 357, 181, 7, Color.LTGRAY, Paint.Align.CENTER);

        text(c, "TARGET", 25, 215, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, ips[page], 80, 215, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "STATUS", 255, 215, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, online[page] ? "CONNECTED" : "OFFLINE", 305, 215, 8,
                online[page] ? Color.GREEN : Color.RED, Paint.Align.LEFT);

        button(c, 20, 250, 100, 38, "BACK", a);
        text(c, "CONTROLLER PAGE", 145, 270, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, (page + 1) + " / 4", 250, 270, 8, Color.YELLOW, Paint.Align.LEFT);
    }

    void drawLooks(Canvas c) {
        int a = theme == 0 ? Color.RED : theme == 1 ? Color.CYAN : Color.YELLOW;
        frame(c, a);
        text(c, "LOOKS", 240, 28, 18, a, Paint.Align.CENTER);
        text(c, "FNAF DISPLAY CUSTOMIZATION", 15, 48, 8, Color.LTGRAY, Paint.Align.LEFT);

        button(c, 12, 60, 145, 65, "FNAF DARK", theme == 0 ? a : Color.DKGRAY);
        button(c, 168, 60, 145, 65, "SECURITY NIGHT", theme == 1 ? a : Color.DKGRAY);
        button(c, 324, 60, 145, 65, "ARCADE STAGE", theme == 2 ? a : Color.DKGRAY);

        text(c, "BACKLIGHT", 15, 148, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, brightness + "%", 420, 148, 8, Color.WHITE, Paint.Align.LEFT);
        rect(c, 15, 158, 469, 176, Color.WHITE, true);
        p.setColor(a); c.drawRect(18, 161, 18 + (451 * brightness / 100f), 173, p);

        text(c, "DISPLAY", 15, 195, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "480 x 320  /  ST7796S", 80, 195, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "IMAGE", 15, 213, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, names[page], 80, 213, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "TOUCH", 15, 231, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "XPT2046 CALIBRATED", 80, 231, 8, Color.GREEN, Paint.Align.LEFT);

        button(c, 15, 250, 135, 38, "SAVE", Color.GREEN);
        button(c, 165, 250, 135, 38, "RESET LOOKS", Color.DKGRAY);
        button(c, 315, 250, 150, 38, "BACK", Color.DKGRAY);
    }

    void drawDebug(Canvas c) {
        int a = accent();
        frame(c, a);
        text(c, "DEBUG", 240, 28, 18, a, Paint.Align.CENTER);
        int row = 22, y = 54;
        text(c, "TARGET ESP32", 10, y, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, ips[page], 120, y, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "UDP PORT", 10, y + row, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "4210", 120, y + row, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "PHONE RX", 10, y + row * 2, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "4211", 120, y + row * 2, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "CONTROLLER", 10, y + row * 3, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, names[page], 120, y + row * 3, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "LAST CMD", 250, y, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, status, 250, y + row, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "PAGE", 250, y + row * 2, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, (page + 1) + " / 4", 330, y + row * 2, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "ANIM", 250, y + row * 3, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.valueOf(selectedAnimation), 330, y + row * 3, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "UDP RX", 250, y + row * 4, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.valueOf(log.size()), 330, y + row * 4, 8, Color.WHITE, Paint.Align.LEFT);
        button(c, 10, 215, 105, 38, "BACK", a);
        button(c, 130, 215, 120, 38, "STATUS", a);
        button(c, 265, 215, 95, 38, "SERIAL", a);
    }

    void drawAnimations(Canvas c) {
        int a = accent();
        frame(c, a);
        text(c, "ANIMATION CONTROL", 240, 28, 16, a, Paint.Align.CENTER);
        text(c, names[page] + "  •  " + ips[page], 240, 49, 7, Color.LTGRAY, Paint.Align.CENTER);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 4, row = (i - 1) / 4;
            int x = 20 + col * 112, y = 65 + row * 55;
            button(c, x, y, 100, 40, "ANIM " + i, i == selectedAnimation ? a : Color.DKGRAY);
        }
        button(c, 20, 180, 105, 36, "PLAY ALL", Color.GREEN);
        button(c, 135, 180, 105, 36, "PAUSE", Color.YELLOW);
        button(c, 250, 180, 105, 36, "STOP", Color.RED);
        button(c, 365, 180, 95, 36, "RESTART", Color.RED);
        button(c, 20, 230, 105, 34, "PREV", Color.DKGRAY);
        button(c, 135, 230, 105, 34, "NEXT", Color.DKGRAY);
        button(c, 250, 230, 105, 34, autoplay ? "AUTO ON" : "AUTO OFF", autoplay ? Color.GREEN : Color.DKGRAY);
        button(c, 365, 230, 95, 34, "BACK", Color.DKGRAY);
    }

    void drawSerial(Canvas c) {
        frame(c, Color.RED);
        text(c, "SERIAL MONITOR", 240, 28, 16, Color.RED, Paint.Align.CENTER);
        text(c, "● LIVE   UDP DEBUG PORT 4211", 240, 49, 7, Color.GREEN, Paint.Align.CENTER);
        int start = Math.max(0, log.size() - 11), y = 70;
        for (int i = start; i < log.size(); i++) {
            String s = log.get(i);
            if (s.length() > 64) s = s.substring(0, 64);
            text(c, s, 10, y, 6, Color.LTGRAY, Paint.Align.LEFT);
            y += 17;
        }
        button(c, 20, 275, 90, 28, "CLEAR", Color.RED);
        button(c, 120, 275, 110, 28, "REFRESH", Color.DKGRAY);
        button(c, 350, 275, 110, 28, "BACK", Color.DKGRAY);
    }

    void drawSettings(Canvas c) {
        frame(c, Color.RED);
        text(c, "SYSTEM SETTINGS", 240, 28, 16, Color.RED, Paint.Align.CENTER);
        text(c, "ESP32 CONTROLLER IP ADDRESSES", 240, 49, 8, Color.WHITE, Paint.Align.CENTER);
        for (int i = 0; i < 4; i++) {
            int y = 70 + i * 43;
            text(c, names[i], 25, y + 18, 8, Color.LTGRAY, Paint.Align.LEFT);
            rect(c, 100, y, 350, y + 28, Color.DKGRAY, false);
            text(c, ips[i], 112, y + 19, 8, Color.WHITE, Paint.Align.LEFT);
            button(c, 365, y, 90, 28, "TEST", Color.RED);
        }
        text(c, "NO VOLUME CONTROL  //  AUDIO REMAINS ON ESP32", 240, 257, 6, Color.LTGRAY, Paint.Align.CENTER);
        button(c, 365, 275, 95, 22, "BACK", Color.DKGRAY);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;
        float x = e.getX() * 480f / getWidth();
        float y = e.getY() * 320f / getHeight();

        if (screen == 0) {
            // Header navigation.
            if ((y <= 45 && x <= 75) || (y >= 282 && x >= 380 && x < 432)) {
                page = (page + 3) % 4; invalidate(); return true;
            }
            if ((y <= 45 && x >= 405) || (y >= 282 && x >= 432)) {
                page = (page + 1) % 4; invalidate(); return true;
            }
            if (y >= 217 && y <= 257 && x >= 12 && x <= 144) {
                sendToCurrent("[RESET]"); status = "RESET SENT"; invalidate(); return true;
            }
            if (y >= 217 && y <= 257 && x >= 153 && x <= 265) {
                screen = 1; invalidate(); return true;
            }
            if (y >= 217 && y <= 257 && x >= 277 && x <= 332) {
                screen = 4; invalidate(); return true;
            }
        } else if (screen == 1) {
            if (y >= 62 && y <= 127 && x <= 225) { screen = 2; invalidate(); return true; }
            if (y >= 62 && y <= 127 && x >= 255) { screen = 3; invalidate(); return true; }
            if (y >= 140 && y <= 195 && x <= 225) { screen = 4; invalidate(); return true; }
            if (y >= 140 && y <= 195 && x >= 255) { screen = 5; invalidate(); return true; }
            if (y >= 250 && y <= 290 && x <= 125) { screen = 0; invalidate(); return true; }
        } else if (screen == 2) {
            if (y >= 60 && y <= 125) {
                if (x < 157) theme = 0;
                else if (x < 313) theme = 1;
                else theme = 2;
                prefs.edit().putInt("theme", theme).apply(); invalidate(); return true;
            }
            if (y >= 150 && y <= 180) {
                brightness = Math.max(20, Math.min(100, (int)(x * 100 / 480f)));
                prefs.edit().putInt("brightness", brightness).apply(); invalidate(); return true;
            }
            if (y >= 250 && x >= 315) { screen = 1; invalidate(); return true; }
        } else if (screen == 3) {
            if (y >= 210 && y <= 260 && x <= 120) { screen = 1; invalidate(); return true; }
            if (y >= 210 && y <= 260 && x >= 125 && x <= 255) { sendToCurrent("[STATUS]"); invalidate(); return true; }
            if (y >= 210 && y <= 260 && x >= 260) { screen = 5; invalidate(); return true; }
        } else if (screen == 4) {
            if (y >= 65 && y < 175) {
                int col = (int)((x - 20) / 112), row = (int)((y - 65) / 55);
                if (col >= 0 && col < 4 && row >= 0 && row < 2) {
                    selectedAnimation = row * 4 + col + 1;
                    playCurrent(); invalidate(); return true;
                }
            }
            if (y >= 180 && y < 216) {
                if (x < 125) playAll();
                else if (x < 250) { broadcast("[PAUSE]"); status = "PAUSED"; }
                else if (x < 360) { broadcast("[STOP]"); status = "STOPPED"; }
                else { broadcast("[RESTART]"); status = "RESTARTED"; }
                invalidate(); return true;
            }
            if (y >= 230 && y < 270) {
                if (x < 125) selectedAnimation = Math.max(1, selectedAnimation - 1);
                else if (x < 250) selectedAnimation = Math.min(8, selectedAnimation + 1);
                else if (x < 360) autoplay = !autoplay;
                else screen = 0;
                invalidate(); return true;
            }
        } else if (screen == 5) {
            if (y >= 270 && x < 120) { log.clear(); invalidate(); return true; }
            if (y >= 270 && x > 330) { screen = 0; invalidate(); return true; }
        } else {
            if (y >= 70 && y < 250 && x >= 365) {
                for (int i = 0; i < 4; i++) {
                    int yy = 70 + i * 43;
                    if (y >= yy && y <= yy + 28) { send(i, "[STATUS]"); return true; }
                }
            }
            if (y > 270 && x > 340) { screen = 0; invalidate(); return true; }
        }
        return true;
    }
}
