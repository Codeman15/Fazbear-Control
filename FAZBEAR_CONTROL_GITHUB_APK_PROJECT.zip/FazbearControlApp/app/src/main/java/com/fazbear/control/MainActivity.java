package com.fazbear.control;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    FazbearView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        view = new FazbearView(this);
        setContentView(view);
    }

    @Override protected void onDestroy() {
        view.shutdown();
        super.onDestroy();
    }
}

class FazbearView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService net = Executors.newCachedThreadPool();
    final DatagramSocket rxSocket;
    final SharedPreferences prefs;

    final String[] names = {"FREDDY","BONNIE","CHICA","STAGE"};
    final String[] defaultIPs = {"10.0.0.28","10.0.0.102","10.0.0.103","10.0.0.104"};
    String[] ips = new String[4];
    Bitmap[] chars = new Bitmap[4];

    int page = 0;
    int screen = 0; // 0 controller, 1 animation, 2 serial, 3 settings
    int selectedAnimation = 1;
    int volume = 80;
    boolean autoplay = false;
    boolean[] online = new boolean[4];
    long[] lastSeen = new long[4];
    ArrayList<String> log = new ArrayList<>();
    String status = "SYSTEM READY";

    FazbearView(Context c) {
        super(c);
        setFocusable(true);
        prefs = c.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        for (int i=0;i<4;i++) ips[i] = prefs.getString("ip"+i, defaultIPs[i]);

        chars[0] = load(c, "freddy");
        chars[1] = load(c, "bonnie");
        chars[2] = load(c, "chica");
        chars[3] = load(c, "stage");

        DatagramSocket s = null;
        try {
            s = new DatagramSocket(4211);
            s.setBroadcast(true);
        } catch(Exception e) {
            addLog("SERIAL RX ERROR: " + e.getMessage());
        }
        rxSocket = s;
        if (rxSocket != null) startReceiver();
        addLog("FAZBEAR CONTROL ONLINE");
    }

    Bitmap load(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(getResources(), id);
    }

    void startReceiver() {
        net.execute(() -> {
            byte[] buf = new byte[2048];
            while (!rxSocket.isClosed()) {
                try {
                    DatagramPacket d = new DatagramPacket(buf, buf.length);
                    rxSocket.receive(d);
                    String msg = new String(d.getData(), d.getOffset(), d.getLength()).trim();
                    final String host = d.getAddress().getHostAddress();
                    main.post(() -> {
                        markOnline(host);
                        addLog(host + " > " + msg);
                        if (msg.contains("ANIM_DONE") && autoplay) {
                            int next = selectedAnimation + 1;
                            if (next <= 8) {
                                selectedAnimation = next;
                                playAnimationAllOrCurrent();
                            }
                        }
                    });
                } catch(Exception ignored) {}
            }
        });
    }

    void markOnline(String host) {
        for(int i=0;i<4;i++) if(ips[i].equals(host)) {
            online[i] = true;
            lastSeen[i] = System.currentTimeMillis();
        }
    }

    void addLog(String s) {
        log.add(String.format("%02d:%02d:%02d  %s",
                (System.currentTimeMillis()/3600000)%24,
                (System.currentTimeMillis()/60000)%60,
                (System.currentTimeMillis()/1000)%60, s));
        while(log.size()>120) log.remove(0);
        invalidate();
    }

    void send(int which, String cmd) {
        String ip = ips[which];
        addLog(ip + " < " + cmd);
        net.execute(() -> {
            try {
                byte[] data = cmd.getBytes();
                DatagramPacket dp = new DatagramPacket(data, data.length,
                        InetAddress.getByName(ip), 4210);
                DatagramSocket s = new DatagramSocket();
                s.send(dp);
                s.close();
                main.post(() -> { online[which]=true; lastSeen[which]=System.currentTimeMillis(); });
            } catch(Exception e) {
                main.post(() -> addLog("SEND ERROR " + ip + ": " + e.getMessage()));
            }
        });
    }

    void broadcast(String cmd) {
        for(int i=0;i<4;i++) send(i, cmd);
    }

    void playAnimationAllOrCurrent() {
        String cmd = "[START " + selectedAnimation + "]";
        broadcast(cmd);
        status = "PLAYING ANIMATION " + selectedAnimation;
    }

    void shutdown() {
        try { if(rxSocket != null) rxSocket.close(); } catch(Exception ignored) {}
        net.shutdownNow();
    }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        p.setTextSize(size); p.setColor(color); p.setTextAlign(a);
        p.setStyle(Paint.Style.FILL);
        c.drawText(s,x,y,p);
    }

    void rect(Canvas c, float l,float t,float r,float b,int color, boolean stroke) {
        p.setColor(color); p.setStyle(stroke ? Paint.Style.STROKE : Paint.Style.FILL);
        p.setStrokeWidth(stroke ? 2 : 1);
        c.drawRect(l,t,r,b,p);
        p.setStyle(Paint.Style.FILL);
    }

    @Override protected void onDraw(Canvas real) {
        float sx=getWidth()/480f, sy=getHeight()/320f;
        real.save();
        real.scale(sx,sy);
        Canvas c=real;
        c.drawColor(Color.BLACK);
        if(screen==0) drawController(c);
        else if(screen==1) drawAnimations(c);
        else if(screen==2) drawSerial(c);
        else drawSettings(c);
        real.restore();
    }

    void frame(Canvas c, int accent) {
        rect(c,5,5,475,315,Color.DKGRAY,true);
        rect(c,9,9,471,311,accent,true);
        rect(c,20,48,460,50,Color.DKGRAY,false);
    }

    void header(Canvas c, String title, int accent) {
        text(c,"FAZBEAR SECURITY",240,28,18,Color.RED,Paint.Align.CENTER);
        text(c,title,240,43,9,accent,Paint.Align.CENTER);
    }

    void drawController(Canvas c) {
        int accent = page==0 ? 0xFFFF8800 : page==1 ? 0xFFFF00FF : page==2 ? 0xFFFFFF00 : Color.WHITE;
        frame(c,accent); header(c,"CONTROL TERMINAL",accent);

        if(chars[page]!=null) {
            Rect src=new Rect(0,0,chars[page].getWidth(),chars[page].getHeight());
            RectF dst=new RectF(0,52,245,205);
            c.drawBitmap(chars[page],src,dst,p);
        }

        text(c,names[page],14,68,15,accent,Paint.Align.LEFT);
        text(c,"STATUS",260,66,8,Color.LTGRAY,Paint.Align.LEFT);
        text(c,online[page] ? "CONNECTED":"OFFLINE",330,66,8,online[page]?Color.GREEN:Color.RED,Paint.Align.LEFT);
        text(c,"IP:",260,85,8,Color.LTGRAY,Paint.Align.LEFT);
        text(c,ips[page],292,85,8,Color.WHITE,Paint.Align.LEFT);
        text(c,"AUDIO:",260,103,8,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"REMOTE",320,103,8,Color.WHITE,Paint.Align.LEFT);
        text(c,"ANIM:",260,121,8,Color.LTGRAY,Paint.Align.LEFT);
        text(c,String.valueOf(selectedAnimation),320,121,8,Color.WHITE,Paint.Align.LEFT);
        text(c,"UDP:",370,121,8,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"4210",402,121,8,Color.WHITE,Paint.Align.LEFT);

        // Volume
        text(c,"VOLUME",255,153,8,Color.LTGRAY,Paint.Align.LEFT);
        text(c,volume+"%",455,153,8,Color.WHITE,Paint.Align.RIGHT);
        rect(c,255,160,460,178,Color.WHITE,true);
        p.setColor(accent); c.drawRect(258,163,258+(199*volume/100f),175,p);

        button(c,15,215,105,40,"RESET",Color.RED);
        button(c,130,215,115,40,"ANIMATIONS",accent);
        button(c,255,215,100,40,"SERIAL",Color.RED);
        button(c,365,215,100,40,"PLAY",Color.GREEN);

        button(c,18,275,70,28,"<",accent);
        text(c,"ESP32 "+(page+1)+" / 4",240,294,9,Color.LTGRAY,Paint.Align.CENTER);
        button(c,392,275,70,28,">",accent);

        text(c,status,240,267,8,Color.LTGRAY,Paint.Align.CENTER);
    }

    void drawAnimations(Canvas c) {
        int accent=Color.RED;
        frame(c,accent); header(c,"ANIMATION CONTROL",accent);
        text(c,names[page]+"  •  "+ips[page],240,63,8,Color.LTGRAY,Paint.Align.CENTER);

        for(int i=1;i<=8;i++) {
            int col=(i-1)%4, row=(i-1)/4;
            int x=20+col*112, y=82+row*55;
            int a=(i==selectedAnimation)?Color.RED:Color.DKGRAY;
            button(c,x,y,100,40,"ANIM "+i,a);
        }

        button(c,20,205,105,36,"PLAY ALL",Color.GREEN);
        button(c,135,205,105,36,"PAUSE",Color.YELLOW);
        button(c,250,205,105,36,"STOP",Color.RED);
        button(c,365,205,95,36,"RESTART",Color.RED);

        button(c,20,252,105,34,"PREV",Color.DKGRAY);
        button(c,135,252,105,34,"NEXT",Color.DKGRAY);
        button(c,250,252,105,34,autoplay?"AUTO ON":"AUTO OFF",autoplay?Color.GREEN:Color.DKGRAY);
        button(c,365,252,95,34,"BACK",Color.DKGRAY);
    }

    void drawSerial(Canvas c) {
        frame(c,Color.RED); header(c,"SERIAL MONITOR",Color.RED);
        text(c,"● LIVE   UDP DEBUG PORT 4211",240,63,8,Color.GREEN,Paint.Align.CENTER);
        int start=Math.max(0,log.size()-12);
        int y=82;
        for(int i=start;i<log.size();i++) {
            String s=log.get(i);
            if(s.length()>62) s=s.substring(0,62);
            text(c,s,16,y,7,Color.LTGRAY,Paint.Align.LEFT);
            y+=17;
        }
        button(c,20,275,90,28,"CLEAR",Color.RED);
        button(c,120,275,110,28,"REFRESH",Color.DKGRAY);
        button(c,350,275,110,28,"BACK",Color.DKGRAY);
    }

    void drawSettings(Canvas c) {
        frame(c,Color.RED); header(c,"SYSTEM SETTINGS",Color.RED);
        text(c,"ESP32 CONTROLLER IP ADDRESSES",240,64,9,Color.WHITE,Paint.Align.CENTER);
        for(int i=0;i<4;i++) {
            int y=88+i*43;
            text(c,names[i],25,y+12,8,Color.LTGRAY,Paint.Align.LEFT);
            rect(c,100,y,350,y+28,Color.DKGRAY,false);
            text(c,ips[i],112,y+19,9,Color.WHITE,Paint.Align.LEFT);
            button(c,365,y,90,28,"TEST",Color.RED);
        }
        text(c,"Commands: START / PAUSE / RESUME / STOP / RESTART / VOLUME",240,275,7,Color.LTGRAY,Paint.Align.CENTER);
        button(c,365,286,95,22,"BACK",Color.DKGRAY);
    }

    void button(Canvas c,int x,int y,int w,int h,String label,int color) {
        rect(c,x,y,x+w,y+h,color,false);
        rect(c,x,y,x+w,y+h,Color.WHITE,true);
        text(c,label,x+w/2f,y+h/2f+4,8,Color.WHITE,Paint.Align.CENTER);
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e) {
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float x=e.getX()*480f/getWidth(), y=e.getY()*320f/getHeight();

        if(screen==0) {
            if(y>=215&&y<=255&&x>=130&&x<245){ screen=1; invalidate(); return true; }
            if(y>=215&&y<=255&&x>=255&&x<355){ screen=2; invalidate(); return true; }
            if(y>=215&&y<=255&&x>=365){ send(page,"[START "+selectedAnimation+"]"); status="PLAYING ANIMATION "+selectedAnimation; invalidate(); return true; }
            if(y>=215&&y<=255&&x<120){ send(page,"[RESET]"); status="RESET SENT"; invalidate(); return true; }
            if(y>=275&&x<100){ page=(page+3)%4; invalidate(); return true; }
            if(y>=275&&x>380){ page=(page+1)%4; invalidate(); return true; }
            if(y>=160&&y<=190&&x>=250&&x<=465){
                volume=Math.max(0,Math.min(100,(int)((x-258)*100/199f)));
                send(page,"[VOLUME "+volume+"]"); invalidate(); return true;
            }
        } else if(screen==1) {
            if(y>=82&&y<192) {
                int col=(int)((x-20)/112), row=(int)((y-82)/55);
                if(col>=0&&col<4&&row>=0&&row<2) {
                    int a=row*4+col+1; selectedAnimation=a;
                    send(page,"[START "+a+"]"); status="PLAYING ANIMATION "+a;
                    invalidate(); return true;
                }
            }
            if(y>=205&&y<241) {
                if(x<125) { playAnimationAllOrCurrent(); }
                else if(x<250) broadcast("[PAUSE]");
                else if(x<360) broadcast("[STOP]");
                else broadcast("[RESTART]");
                invalidate(); return true;
            }
            if(y>=252&&y<290) {
                if(x<125) { selectedAnimation=Math.max(1,selectedAnimation-1); }
                else if(x<250) { selectedAnimation=Math.min(8,selectedAnimation+1); }
                else if(x<360) { autoplay=!autoplay; }
                else { screen=0; }
                invalidate(); return true;
            }
        } else if(screen==2) {
            if(y>=270&&x<120){ log.clear(); invalidate(); return true; }
            if(y>=270&&x>330){ screen=0; invalidate(); return true; }
        } else if(screen==3) {
            if(y>=80&&y<260) {
                for(int i=0;i<4;i++){
                    int yy=88+i*43;
                    if(y>=yy&&y<=yy+28&&x>=365){
                        send(i,"[STATUS]"); return true;
                    }
                }
            }
            if(y>275&&x>340){screen=0;invalidate();return true;}
        }
        return true;
    }
}
