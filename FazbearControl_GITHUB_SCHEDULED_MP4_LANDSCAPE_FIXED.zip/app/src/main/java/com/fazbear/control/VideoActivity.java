package com.fazbear.control;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.VideoView;
import android.media.MediaPlayer;
import android.content.Intent;

/** Full-screen scheduled-show MP4 player. Audio comes exclusively from the MP4. */
public class VideoActivity extends Activity {
    private static volatile VideoActivity current;
    private VideoView videoView;
    private int kind;
    private boolean completed;

    public static void stopCurrent() {
        VideoActivity v = current;
        if (v != null) v.finishWithoutCallback();
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        current = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        try { setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); } catch (Exception ignored) { }

        videoView = new VideoView(this);
        videoView.setLayoutParams(new android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT));
        videoView.setBackgroundColor(android.graphics.Color.BLACK);
        setContentView(videoView);
        String uriString = getIntent().getStringExtra("VIDEO_URI");
        kind = getIntent().getIntExtra("VIDEO_KIND", 0);
        if (uriString == null || uriString.isEmpty()) { finishWithoutCallback(); return; }
        videoView.setVideoURI(Uri.parse(uriString));
        videoView.setOnPreparedListener(mp -> {
            mp.setVolume(1f, 1f);
            mp.setLooping(false);
            videoView.start();
        });
        videoView.setOnCompletionListener(mp -> complete());
        videoView.setOnErrorListener((mp, what, extra) -> { complete(); return true; });
    }

    private void complete() {
        if (completed) return;
        completed = true;
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("FAZBEAR_VIDEO_COMPLETE", true);
        i.putExtra("VIDEO_KIND", kind);
        try { startActivity(i); } catch (Exception ignored) { }
        finish();
    }

    private void finishWithoutCallback() {
        completed = true;
        try { if (videoView != null) videoView.stopPlayback(); } catch (Exception ignored) { }
        finish();
    }

    @Override protected void onDestroy() {
        try { if (videoView != null) videoView.stopPlayback(); } catch (Exception ignored) { }
        if (current == this) current = null;
        super.onDestroy();
    }
}
