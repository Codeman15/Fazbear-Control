FAZBEAR CONTROL — PORTRAIT PIZZA PLACE VISUAL REDESIGN

This pass updates the Canvas-based UI styling for theme 3:
- Warm pizzeria palette, checkerboard trim, marquee header, arcade buttons.
- Home dashboard includes the existing home media plus the four existing character bitmaps.
- Existing touch target bands and controller actions were kept in place.
- The 10 theme choices remain available; theme 3 is labeled Pizza Place.
- Existing source image assets were not replaced.

Important:
- This is a visual redesign pass only.
- The uploaded source did not include a Show Schedule screen or background scheduler;
  those are not added by this ZIP.
- No successful Gradle build has been run in this environment. Build and test in Android Studio,
  especially home-screen touch actions and all theme choices, before relying on the app.


Follow-up UI cleanup:
- Separated the Timeline / WAV and Show Control buttons so their panels no longer overlap.
- Updated the HOME touch bands to match the revised button positions.
- Moved the volume indicator up to add breathing room above the checkerboard divider.
- Changed the selected Pizza Place navigation tab from a solid yellow block to a dark inset with a gold outline.
- Kept the five existing navigation destinations and existing source images.
- This is a source patch; a successful Android Gradle build/device test is still required.
- Refined character-card separation and improved status/IP text legibility while retaining the existing image assets.


Full Pizza Place home layout rebuild:
- Rebuilt the theme 3 home screen with a Freddy marquee, live America/Denver date/time, larger stage panel, four controller cards, expanded status panel, four colored action panels, a bordered volume panel, checkerboard trim, and four-tab navigation.
- Updated home button hit regions and Pizza Place navigation touch mapping to match the new layout.
- Other themes keep their existing home layout and five-tab navigation.
- Source-only update: run Gradle build and test on-device before installing.


Navigation correction:
- Restored the HOME tab in the Pizza Place bottom navigation.
- Pizza Place now has HOME, DEVICES, ANIMATIONS, CONTROL, and SETTINGS tabs.
- Updated tab hit regions so each tab opens the matching screen.
