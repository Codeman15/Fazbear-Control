package com.fazbear.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Locale;

/** Receives background show alarms and dispatches the existing ESP32 UDP start command. */
public final class ScheduledShowReceiver extends BroadcastReceiver {
    private static MediaPlayer scheduledPlayer;
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        int animation = intent != null ? intent.getIntExtra("animation", prefs.getInt("schedule_animation", 1)) : prefs.getInt("schedule_animation", 1);
        animation = Math.max(1, Math.min(8, animation));
        final int selected = animation;
        final PendingResult result = goAsync();
        new Thread(() -> {
            try {
                String[] defaults = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
                for (int i = 0; i < 4; i++) {
                    String ip = prefs.getString("ip" + i, defaults[i]);
                    byte[] data = ("[START " + selected + "]").getBytes("UTF-8");
                    try (DatagramSocket socket = new DatagramSocket()) {
                        socket.send(new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210));
                    } catch (Exception ignored) { }
                }
                // Play the animation's assigned local WAV in the phone when the saved mode requests it.
                int mode = prefs.getInt("audio_output_mode", 0);
                String uri = prefs.getString("animWavUri" + (selected - 1), null);
                if (mode != 0 && uri != null) {
                    try {
                        if (scheduledPlayer != null) { try { scheduledPlayer.release(); } catch (Exception ignored) {} }
                        MediaPlayer player = new MediaPlayer();
                        scheduledPlayer = player;
                        player.setDataSource(context, Uri.parse(uri));
                        player.setOnCompletionListener(mp -> { mp.release(); if (scheduledPlayer == mp) scheduledPlayer = null; });
                        player.setOnErrorListener((mp, what, extra) -> { mp.release(); if (scheduledPlayer == mp) scheduledPlayer = null; return true; });
                        player.prepare(); player.start();
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) {
            } finally {
                // Re-arm the next recurring occurrence using current saved schedule settings.
                if (prefs.getBoolean("schedule_enabled", false)) {
                    ScheduleAlarm.schedule(context, true, prefs.getInt("schedule_hour", 19),
                            prefs.getInt("schedule_minute", 0), prefs.getInt("schedule_days", 0),
                            prefs.getInt("schedule_animation", selected));
                }
                result.finish();
            }
        }, "Fazbear-Scheduled-Show").start();
    }
}
