LCD TIMER AND INTRO MUSIC FIX

Changes:
- The code-rendered black-screen timer now uses the bundled LCD Solid font rather than a hand-built seven-segment drawing that rendered malformed glyphs.
- The timer is centered horizontally and vertically using font metrics and is sized to fit the landscape screen.
- The intro audio asset is dynamically compressed and peak-limited. This raises the average/quiet music level while keeping the loudest transients/chime peaks capped instead of simply applying a blanket volume boost.
- Other screen fonts and scheduled show behavior are unchanged.

Build note: this package has not been verified by a full Gradle build in this environment.
