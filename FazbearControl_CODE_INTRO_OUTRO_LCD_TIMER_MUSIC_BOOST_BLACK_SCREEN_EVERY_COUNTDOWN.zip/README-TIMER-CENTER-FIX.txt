TIMER CENTERING FIX
- The black-screen intro countdown (0:01 -> 0:00) now places the complete digital glyph group at the true vertical center of the display.
- The digits remain custom-drawn pixel/segment shapes to avoid the broken glyph rendering seen with a font fallback.
- Timer digits are slightly taller (up to 38% of display height) while retaining the centered horizontal layout.
- Other intro title cards use a center-screen anchor as well.
