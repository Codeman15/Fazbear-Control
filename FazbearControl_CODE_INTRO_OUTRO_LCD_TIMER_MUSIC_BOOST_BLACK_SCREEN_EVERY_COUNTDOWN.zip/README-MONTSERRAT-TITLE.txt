Intro title update
- The final “Five Nights / at Freddy's” code-rendered title now requests the Montserrat Bold typeface and has a soft red glow.
- Android Typeface.create("Montserrat", Typeface.BOLD) uses Montserrat if installed; otherwise Android may substitute its default sans-serif font.
- This change does not alter the countdown or the intro/outro timing.
