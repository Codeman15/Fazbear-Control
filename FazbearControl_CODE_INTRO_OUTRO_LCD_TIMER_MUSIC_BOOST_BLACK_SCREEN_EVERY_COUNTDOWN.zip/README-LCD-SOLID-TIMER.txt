LCD Solid timer font update

- Added the provided LcdSolid.ttf font to app/src/main/assets/fonts/LcdSolid.ttf.
- Applied it only to countdown timer digits/text (landscape timer, portrait countdown timer, and scheduled show-start countdown number).
- All other app labels, the intro/outro title cards, and the “Five Nights at Freddy's” title retain their existing fonts, including the Montserrat Bold request for that title.
- No MP4/video playback or scheduled-show logic was changed.
