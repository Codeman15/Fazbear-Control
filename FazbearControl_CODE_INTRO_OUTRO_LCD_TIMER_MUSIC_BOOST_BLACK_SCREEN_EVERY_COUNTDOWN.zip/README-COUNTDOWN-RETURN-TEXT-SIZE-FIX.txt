Fixes in this version:
- After the code-rendered intro ends, remove the black overlay and stay in landscape so the original artwork-backed scheduled show screen appears.
- After the code-rendered outro ends, remove the black overlay and return to the original landscape artwork-backed countdown screen.
- Prevent the obsolete portrait INTERMISSION screen from appearing after the black screen disappears.
- Enlarged black-screen countdown digits from 112 to 220 logical units.
- Enlarged black-screen title text to 100 logical units (116 for the red Five Nights at Freddy's title), targeting roughly half the landscape screen width while keeping two-line layout.
- Existing app artwork, show logic, and audio resources are preserved.
