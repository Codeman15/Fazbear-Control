Change in this build:
- The code-rendered black intro now starts whenever the scheduled countdown reaches 1 second or less, including if a scheduler tick lands at zero.
- This runs on every repeat countdown, not just the first run.
- Entering phase 3 prevents duplicate launches while the intro is visible.
- Existing code-rendered intro/outro, timer font, audio, artwork, and show logic are otherwise preserved.
