INTRO REFERENCE MATCH
- Built from the user-provided FazbearControl_CODE_INTRO_OUTRO_LANDSCAPE_COUNTDOWN_TEXT_HALF.zip.
- The scheduled intro remains code-rendered with Android Canvas (no MP4 decoder or video surface).
- The timer uses vector seven-segment digits on pure black.
- Title cards use large centered text sized to match the uploaded 13257.mp4 reference: white sans-serif cards and a red serif Five Nights at Freddy's title.
- Text is positioned in the upper-middle portion of the landscape frame and sized relative to the available display width.
- Intro begins when the scheduled countdown reaches one second remaining.
- When intro ends, the scheduled show starts. When outro ends, the code overlay is removed and the original landscape countdown/artwork returns.
