BLACK-SCREEN COUNTDOWN FONT UPDATE

The countdown digits (0:01 / 0:00) in the code-rendered black-screen intro now use the bundled Open 24 Display ST font supplied by the user.

This change applies only to the black-screen intro timer. The regular app timer retains LCD Solid, and other intro title cards and app labels keep their existing fonts. Timer alignment, scale-to-fit, intro timing, show transition, and existing WAV behavior are unchanged.
