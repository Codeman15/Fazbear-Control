FAZBEAR CONTROL — PORTRAIT PIZZA PLACE VISUAL REDESIGN

This pass updates the Canvas-based UI styling for theme 3:
- Warm pizzeria palette, checkerboard trim, marquee header, arcade buttons.
- Home dashboard includes the existing home media plus the four existing character bitmaps.
- Existing touch target bands and controller actions were kept in place.
- The 10 theme choices remain available; theme 3 is labeled Pizza Place.
- Existing source image assets were not replaced.

Important:
- This is a visual redesign pass only.
- The uploaded source did not include a Show Schedule screen or background scheduler;
  those are not added by this ZIP.
- No successful Gradle build has been run in this environment. Build and test in Android Studio,
  especially home-screen touch actions and all theme choices, before relying on the app.


Follow-up UI cleanup:
- Separated the Timeline / WAV and Show Control buttons so their panels no longer overlap.
- Updated the HOME touch bands to match the revised button positions.
- Moved the volume indicator up to add breathing room above the checkerboard divider.
- Changed the selected Pizza Place navigation tab from a solid yellow block to a dark inset with a gold outline.
- Kept the five existing navigation destinations and existing source images.
- This is a source patch; a successful Android Gradle build/device test is still required.
- Refined character-card separation and improved status/IP text legibility while retaining the existing image assets.


Full Pizza Place home layout rebuild:
- Rebuilt the theme 3 home screen with a Freddy marquee, live America/Denver date/time, larger stage panel, four controller cards, expanded status panel, four colored action panels, a bordered volume panel, checkerboard trim, and four-tab navigation.
- Updated home button hit regions and Pizza Place navigation touch mapping to match the new layout.
- Other themes keep their existing home layout and five-tab navigation.
- Source-only update: run Gradle build and test on-device before installing.


Navigation correction:
- Restored the HOME tab in the Pizza Place bottom navigation.
- Pizza Place now has HOME, DEVICES, ANIMATIONS, CONTROL, and SETTINGS tabs.
- Updated tab hit regions so each tab opens the matching screen.


Default home GIF and clock update:
- Added the user's uploaded animated GIF as app/src/main/assets/menu.gif, which is loaded by the existing default-home-media code.
- The default GIF now center-crops to fill the wide home hero panel. A user-selected home image/GIF still takes priority.
- Added a live date/time panel using the America/Denver time zone (Mountain Time), with header typography adjusted to prevent overlap.
- Source-only change; Gradle build and on-device verification are still required.


Customizable Show Timer tab:
- Added a sixth bottom-navigation tab named TIMER.
- Large live countdown with editable duration (1–600 minutes) using +/- 1 and +/- 5 minute controls.
- Start, pause, and reset controls; timer preferences and active end time persist across app restarts.
- Auto-start is enabled by default and starts the timer when Play All or Restart Show is triggered; can be toggled off.
- Timer uses wall-clock end time so countdown continues correctly while the app is backgrounded/closed, then updates when reopened.
- Source-only update; Gradle build and device testing required.


Direct show-duration entry:
- Tap the large timer display to open a Set Show Duration dialog.
- Enter hours and minutes directly (1 minute to 10 hours; minutes 0–59).
- Saving stores the configured duration and resets the countdown to it.
- Source-only update; Gradle build and on-device testing required.


Intermission WAV playlist:
- Added a multi-select file picker for .wav intermission music and sound effects; playlist is saved in app preferences.
- Intermission controls are gated to a running show timer AND PHONE ONLY audio output (not MAX-only or BOTH).
- Play/resume starts the selected playlist item; each completed WAV automatically advances to the next and loops the playlist.
- Pausing/resetting/completing the timer, leaving PHONE ONLY audio mode, or closing the app stops intermission playback.
- Source-only update; Gradle build and real-device testing required.

\n\nScheduled show start and animation gap:
- Timer tab includes a daily scheduled start time, configured in phone-local time.
- AlarmManager receiver starts Bottango animation index 0 at the scheduled time and updates the saved show countdown.
- Alarm is restored after reboot or local time/time-zone changes.
- Android exact-alarm access may be needed for precise scheduling; fallback uses an inexact idle-compatible alarm.
- Automatic animation transitions now wait 5 seconds after completion before sending the next Bottango playback command.
- Source-only changes; Gradle build and real-device tests are required. Confirm the SharedPreferences file name and test exact-alarm behavior on target Android version.
