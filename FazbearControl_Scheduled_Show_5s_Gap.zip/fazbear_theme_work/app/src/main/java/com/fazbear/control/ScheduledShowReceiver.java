package com.fazbear.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Build;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.util.Calendar;

/** Fires the scheduled show start and schedules the next daily occurrence. */
public class ScheduledShowReceiver extends BroadcastReceiver {
    private static final String PLAYBACK_URL = "http://10.0.0.226:59224/PlaybackState/";

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("scheduled_show_enabled", false)) return;

        int hour = prefs.getInt("scheduled_show_hour", 18);
        int minute = prefs.getInt("scheduled_show_minute", 30);
        long now = System.currentTimeMillis();

        // Start animation 1 through the same Bottango PlaybackState API used by the app.
        final PendingResult pending = goAsync();
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(PLAYBACK_URL).openConnection();
                connection.setRequestMethod("PUT");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] body = "{\\"selectedAnimationIndex\\":0,\\"playbackTimeInMS\\":0,\\"isPlaying\\":true}".getBytes("UTF-8");
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(body); }
                connection.getResponseCode();
            } catch (Exception ignored) {
                // The next app launch can show the status; the daily alarm is still rescheduled.
            } finally {
                if (connection != null) connection.disconnect();
                long duration = prefs.getInt("show_timer_minutes", 30) * 60L * 1000L;
                prefs.edit()
                        .putBoolean("show_timer_running", true)
                        .putLong("show_timer_end_at", now + duration)
                        .putLong("show_timer_paused_ms", duration)
                        .apply();
                scheduleNext(context, hour, minute);
                pending.finish();
            }
        }, "FazbearScheduledShow").start();
    }

    static void scheduleNext(Context context, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        Intent intent = new Intent(context, ScheduledShowReceiver.class);
        intent.setAction("com.fazbear.control.SCHEDULED_SHOW");
        PendingIntent pi = PendingIntent.getBroadcast(context, 7351, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            else alarm.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        } catch (SecurityException ex) {
            if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            else alarm.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        }
    }
}
