package com.fazbear.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Restores the next daily show alarm after reboot or local-time changes. */
public class ScheduledShowBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        if (prefs.getBoolean("scheduled_show_enabled", false)) {
            ScheduledShowReceiver.scheduleNext(context,
                    prefs.getInt("scheduled_show_hour", 18),
                    prefs.getInt("scheduled_show_minute", 30));
        }
    }
}
