FAZBEAR CONTROL — THEME PHOTOS APPLIED

The theme photo assets now come from the user-selected master reference sheet.
Theme IDs preserve the existing app mapping: ID 3 is Classic Fazbear (the existing default), followed by Night Shift, Security, Retro, Worn & Withered, Party, Halloween, Arcade, Abandoned, Pirate Cove, and Cartoon.

The custom photo picker remains intact and overrides the built-in artwork per theme.
The existing app layout and controls are preserved.
