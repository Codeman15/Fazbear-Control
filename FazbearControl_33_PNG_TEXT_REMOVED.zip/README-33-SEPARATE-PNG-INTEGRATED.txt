33 SEPARATE THEME PNGS INTEGRATED

This is the Android project, not just the image ZIP.

33 separate PNG artwork files are integrated into app/src/main/res/drawable-nodpi:
- 11 Freddy
- 11 Bonnie
- 11 Chica

Theme mapping follows the canonical app order:
0 Classic Fazbear
1 Night Shift
2 Security
3 Retro (8-Bit)
4 Worn & Withered
5 Party
6 Halloween
7 Arcade
8 Abandoned
9 Pirate Cove
10 Cartoon

The old combined/image-only ZIP should NOT be uploaded as the Android project.
This archive contains settings.gradle, build.gradle, the app module, source code, and the 33 PNG resources.
