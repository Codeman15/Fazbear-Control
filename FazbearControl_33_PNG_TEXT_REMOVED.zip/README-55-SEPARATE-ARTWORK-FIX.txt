Fazbear Control — 55 Separate Theme Artwork Fix

This version uses 55 separate artwork files, not a combined theme card:
11 themes x 5 files each = 55 files.

Each theme has:
- Freddy
- Bonnie
- Chica
- Stage
- Background UI

The artwork is extracted from the approved theme reference sheet as individual
images and stored at 3840 pixels wide, preserving each image's own aspect ratio.

The Android renderer now uses aspect-fit scaling for these standalone files.
It no longer stretches or center-crops them into the Devices cards.

Custom theme photos continue to override the built-in artwork.
Open 24 Display ST remains the application font.
