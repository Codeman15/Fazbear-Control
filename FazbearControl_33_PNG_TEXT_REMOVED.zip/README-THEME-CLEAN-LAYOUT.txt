THEME CLEAN LAYOUT FIX

- Restored the original Fazbear Control portrait layout/background treatment.
- Theme background images are no longer stretched over the entire app.
- Theme character and stage artwork remains available in the intended image areas.
- Theme-specific buttons remain in place without changing screen geometry.
- Custom theme photos and Open 24 Display ST remain enabled.
