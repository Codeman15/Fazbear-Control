FAZBEAR CONTROL — THEME AND IMAGE CUSTOMIZATION UPDATE

Changes in this package:
- App is locked to portrait orientation.
- Expanded accent themes: Classic Fazbear Green, Neon Purple, Cyan, Amber,
  Alert Red, Ice Blue, Sunset Orange, Pink, Monochrome, and Toxic Lime.
- Theme choices are saved between launches.
- CRT scanlines and glitch transitions remain configurable.
- Custom background image selection remains available.
- Freddy, Bonnie, Chica, and Stage artwork can each be replaced with an image
  from the phone and are saved between launches.
- The clock/time display remains app-generated and is not replaced by artwork.
- Existing animation names/images, ESP32 UDP communication, Bottango polling,
  audio controls, and read-only ESP32 volume display are retained.

Build:
1. Extract this ZIP.
2. Open the fazbear_theme_work folder in Android Studio.
3. Sync Gradle and build the debug APK.
4. In the app, open Settings > Themes / Images / Effects.

Note: The source has been updated, but an Android Gradle build has not been run
in this environment. Verify the build in Android Studio or GitHub Actions.

Additional theme customization:
- Each theme has its own optional saved background image.
- Each theme has selectable effect presets: theme default, CRT scanlines,
  glitch/signal tearing, security-camera static, neon glow pulse, or none.
- Home screen artwork can be replaced with a photo or animated GIF and persists.
- Select a theme first, then open Settings > Themes / Images / Effects.

Audio output selector update:
- MAX ONLY: sends [AUDIO MAX] and does not run the phone receiver.
- BOTH: starts the phone receiver and sends [AUDIO BOTH].
- PHONE: starts the phone receiver and sends [AUDIO PHONE].
Important: BOTH requires the ESP32 firmware to recognize [AUDIO BOTH] and
stream to the phone while continuing MAX98357 playback. This ZIP changes the
Android app only; it does not update ESP32 firmware.

THEME PHOTO SETS
----------------
Each theme now has its own optional Freddy, Bonnie, Chica, and Stage photo set.
Open SETTINGS -> THEMES -> MORE OPTIONS -> PHOTOS FOR THIS THEME.
Choose a photo for the current theme. Theme photos are saved independently using
SharedPreferences and persist across theme changes and app restarts.
If a theme has no custom photo for a slot, the normal bundled character/stage
artwork is used automatically.

BUTTON STYLE UPDATE
-------------------
The main button renderer now applies a distinct visual treatment to every built-in theme while keeping all existing touch geometry and button behavior unchanged:
0 Classic - brushed metal
1 Night Shift - blue neon
2 Security - red emergency/hazard
3 Retro - pixel arcade
4 Worn & Withered - rusty metal
5 Party - colorful confetti plastic
6 Halloween - orange/purple haunted metal
7 Arcade - blue/magenta neon
8 Abandoned - corroded green/brown plate
9 Pirate Cove - carved dark wood
10 Cartoon - bright beveled plastic
All displayed button labels continue to use the bundled Open 24 Display ST font through the existing text renderer.
