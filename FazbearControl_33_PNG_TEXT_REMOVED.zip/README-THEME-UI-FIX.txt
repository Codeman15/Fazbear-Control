FAZBEAR CONTROL THEME UI FIX

This version restores the existing Fazbear Control screen structure and keeps the
new theme artwork/button styling contained to the themed assets. The full-screen
CRT/HUD/grid/scanline overlay has been removed so the app does not become a
full-screen security-console redesign.

The existing Open 24 Display ST font, theme photo customization, theme defaults,
and existing controls remain in the project.
