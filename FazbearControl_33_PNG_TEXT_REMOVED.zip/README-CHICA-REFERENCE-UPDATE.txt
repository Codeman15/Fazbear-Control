Chica artwork update

The 11 theme Chica images were regenerated from the supplied Chica and cupcake references. Freddy, Bonnie, and Stage artwork were left unchanged. Each theme remains a separate image asset and custom-photo overrides remain supported.
