Fazbear Control — Separate 4K Theme Artwork

This project stores each theme image as its own high-resolution JPEG resource:
- Freddy
- Bonnie
- Chica
- Stage
- Background UI

11 themes x 5 images = 55 separate artwork files.
Each theme image is 3840 pixels wide and keeps its original artwork aspect ratio.

The Android app loads only the currently selected theme at runtime to avoid decoding all 55 high-resolution images into memory at once. The selected theme's custom user photos still override its built-in artwork, and Reset Photos restores the built-in defaults.

The Devices screen uses the selected theme's individual character/stage assets instead of a combined theme-sheet/card image.

Open 24 Display ST remains the app font.
