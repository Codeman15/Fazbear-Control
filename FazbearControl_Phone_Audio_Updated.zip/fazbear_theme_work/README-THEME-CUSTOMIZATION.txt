FAZBEAR CONTROL — THEME AND IMAGE CUSTOMIZATION UPDATE

Changes in this package:
- App is locked to portrait orientation.
- Expanded accent themes: Classic Fazbear Green, Neon Purple, Cyan, Amber,
  Alert Red, Ice Blue, Sunset Orange, Pink, Monochrome, and Toxic Lime.
- Theme choices are saved between launches.
- CRT scanlines and glitch transitions remain configurable.
- Custom background image selection remains available.
- Freddy, Bonnie, Chica, and Stage artwork can each be replaced with an image
  from the phone and are saved between launches.
- The clock/time display remains app-generated and is not replaced by artwork.
- Existing animation names/images, ESP32 UDP communication, Bottango polling,
  audio controls, and read-only ESP32 volume display are retained.

Build:
1. Extract this ZIP.
2. Open the fazbear_theme_work folder in Android Studio.
3. Sync Gradle and build the debug APK.
4. In the app, open Settings > Themes / Images / Effects.

Note: The source has been updated, but an Android Gradle build has not been run
in this environment. Verify the build in Android Studio or GitHub Actions.
