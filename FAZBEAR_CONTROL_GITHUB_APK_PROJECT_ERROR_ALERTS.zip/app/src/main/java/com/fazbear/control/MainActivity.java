package com.fazbear.control;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.InputType;
import android.widget.EditText;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.*;
import android.view.*;
import android.content.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    FazbearView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 9001);
        }
        view = new FazbearView(this);
        setContentView(view);
        if (getIntent() != null && getIntent().getBooleanExtra("OPEN_FAZBEAR_DEBUG", false)) view.openDebugFromNotification();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (view != null && intent.getBooleanExtra("OPEN_FAZBEAR_DEBUG", false)) view.openDebugFromNotification();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (view != null) view.handleImageResult(requestCode, resultCode, data);
    }

    @Override protected void onDestroy() {
        if (view != null) view.shutdown();
        super.onDestroy();
    }
}

class FazbearView extends View {
    final Context appContext;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService net = Executors.newCachedThreadPool();
    final DatagramSocket rxSocket;
    final SharedPreferences prefs;

    final String[] names = {"FREDDY", "BONNIE", "CHICA", "STAGE"};
    final String[] defaultIPs = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
    final String[] ips = new String[4];
    final String[] animNames = {"Idle", "Welcome Show", "Song 1", "Song 2", "Wave", "Point", "Laugh", "Custom"};
    final Bitmap[] chars = new Bitmap[4];
    final Bitmap[] customAnimImages = new Bitmap[8];
    final String[] customAnimUris = new String[8];
    int pendingImageSlot = -1;
    static final int PICK_ANIMATION_IMAGE = 4208;
    Movie menuGif;
    long menuGifStartedAt = -1;

    static final int HOME = 0, DEVICES = 1, TIMELINE = 2, CONTROL = 3, SETTINGS = 4, DEBUG = 5, DEVICE_DETAIL = 6, ANIMATIONS = 7;

    int screen = HOME;
    int page = 0;
    int selectedAnimation = 1;
    boolean autoplay = false;
    boolean loop = false;
    boolean[] online = new boolean[4];
    long[] lastSeen = new long[4];
    String[] playing = {"Idle", "Idle", "Idle", "Stage Lights"};
    int[] progress = {0, 0, 0, 0};
    int syncedVolume = -1;
    ArrayList<String> log = new ArrayList<>();
    String status = "SYSTEM READY";
    String errorTitle = "";
    String errorMessage = "";
    String errorDetails = "";
    boolean errorPopup = false;
    int theme = 0;

    FazbearView(Context c) {
        super(c);
        appContext = c;
        setFocusable(true);
        try {
            menuGif = Movie.decodeStream(c.getAssets().open("menu.gif"));
        } catch (Exception ignored) {
            menuGif = null;
        }
        prefs = c.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        for (int i = 0; i < 4; i++) ips[i] = prefs.getString("ip" + i, defaultIPs[i]);
        theme = prefs.getInt("theme", 0);
        for (int i = 0; i < 8; i++) {
            customAnimUris[i] = prefs.getString("animImage" + i, null);
            if (customAnimUris[i] != null) loadCustomAnimationImage(i, android.net.Uri.parse(customAnimUris[i]));
        }

        chars[0] = load(c, "freddy");
        chars[1] = load(c, "bonnie");
        chars[2] = load(c, "chica");
        chars[3] = load(c, "stage");

        DatagramSocket s = null;
        try {
            s = new DatagramSocket(4211);
            s.setBroadcast(true);
            addLog("UDP RX READY  //  PORT 4211");
        } catch (Exception e) {
            addLog("UDP RX ERROR: " + e.getMessage());
            showError("NETWORK ERROR", "Unable to open UDP 4211", String.valueOf(e.getMessage()));
        }
        rxSocket = s;
        if (rxSocket != null) startReceiver();
        addLog("FAZBEAR CONTROL ONLINE");

        main.postDelayed(() -> {
            for (int i = 0; i < 4; i++) {
                if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
            }
            invalidate();
            main.postDelayed(this::tick, 1000);
        }, 1000);
    }

    void tick() {
        for (int i = 0; i < 4; i++) {
            if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
        }
        invalidate();
        main.postDelayed(this::tick, 1000);
    }

    Bitmap load(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(getResources(), id);
    }

    void startReceiver() {
        net.execute(() -> {
            byte[] buf = new byte[2048];
            while (rxSocket != null && !rxSocket.isClosed()) {
                try {
                    DatagramPacket d = new DatagramPacket(buf, buf.length);
                    rxSocket.receive(d);
                    String msg = new String(d.getData(), d.getOffset(), d.getLength()).trim();
                    final String host = d.getAddress().getHostAddress();
                    main.post(() -> handlePacket(host, msg));
                } catch (Exception ignored) {}
            }
        });
    }

    void handlePacket(String host, String msg) {
        int idx = indexForHost(host);
        if (idx >= 0) {
            online[idx] = true;
            lastSeen[idx] = System.currentTimeMillis();
        }
        addLog(host + " > " + msg);

        int v = parseVolume(msg);
        if (v >= 0) {
            syncedVolume = v;
            status = "VOLUME " + v + "%  //  ESP32 POT";
        }

        if (msg.toUpperCase(Locale.US).contains("ANIM_DONE")) {
            if (idx >= 0) {
                progress[idx] = 100;
                if (autoplay) {
                    int next = selectedAnimation >= 8 ? 1 : selectedAnimation + 1;
                    selectedAnimation = next;
                    playing[idx] = animNames[next - 1];
                    send(idx, "[START " + next + "]");
                }
            }
        }
        invalidate();
    }

    int indexForHost(String host) {
        for (int i = 0; i < 4; i++) if (ips[i].equals(host)) return i;
        return -1;
    }

    int parseVolume(String msg) {
        String u = msg.toUpperCase(Locale.US);
        int i = u.indexOf("VOLUME");
        if (i < 0) return -1;
        i += 6;
        while (i < u.length() && !Character.isDigit(u.charAt(i))) i++;
        if (i >= u.length()) return -1;
        int start = i;
        while (i < u.length() && Character.isDigit(u.charAt(i))) i++;
        try { return Math.max(0, Math.min(100, Integer.parseInt(u.substring(start, i)))); }
        catch (Exception e) { return -1; }
    }

    void addLog(String s) {
        log.add(timeStamp() + "  " + s);
        while (log.size() > 160) log.remove(0);
        invalidate();
    }

    String timeStamp() {
        long n = System.currentTimeMillis() / 1000;
        return String.format(Locale.US, "%02d:%02d:%02d", (n / 3600) % 24, (n / 60) % 60, n % 60);
    }

    void send(int which, String cmd) {
        if (which < 0 || which > 3) return;
        final String ip = ips[which];
        addLog(ip + " < " + cmd);
        net.execute(() -> {
            try {
                byte[] data = cmd.getBytes("UTF-8");
                DatagramPacket dp = new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210);
                DatagramSocket s = new DatagramSocket();
                s.setBroadcast(true);
                s.send(dp);
                s.close();
                main.post(() -> {
                    online[which] = true;
                    lastSeen[which] = System.currentTimeMillis();
                    invalidate();
                });
            } catch (Exception e) {
                main.post(() -> {
                    addLog("SEND ERROR " + ip + ": " + e.getMessage());
                    showError("COMMAND FAILED", "Could not reach ESP32 " + names[which],
                            "Target: " + ip + "\nUDP command port: 4210\n" + e.getMessage());
                });
            }
        });
    }

    void broadcast(String cmd) { for (int i = 0; i < 4; i++) send(i, cmd); }

    void play(int i, int anim) {
        selectedAnimation = anim;
        playing[i] = animNames[anim - 1];
        progress[i] = 0;
        send(i, "[START " + anim + "]");
        status = names[i] + "  //  PLAYING " + animNames[anim - 1];
    }

    void playAll() {
        for (int i = 0; i < 4; i++) {
            if (i == 3) playing[i] = "Stage Lights";
            else playing[i] = animNames[selectedAnimation - 1];
            progress[i] = 0;
        }
        broadcast("[START " + selectedAnimation + "]");
        status = "PLAY ALL  //  " + animNames[selectedAnimation - 1];
    }

    void showError(String title, String message, String details) {
        errorTitle = title;
        errorMessage = message;
        errorDetails = details == null ? "" : details;
        errorPopup = false;
        screen = DEBUG;
        addLog("ERROR: " + title + " - " + message + (errorDetails.isEmpty() ? "" : " | " + errorDetails));
        postErrorNotification(title, message);
        invalidate();
    }

    void openDebugFromNotification() {
        screen = DEBUG;
        errorPopup = false;
        invalidate();
    }

    void postErrorNotification(String title, String message) {
        try {
            Context context = appContext.getApplicationContext();
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            String channelId = "fazbear_errors";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(channelId, "Fazbear Control errors", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Alerts when Fazbear Control encounters an error");
                manager.createNotificationChannel(channel);
            }
            Intent intent = new Intent(context, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.putExtra("OPEN_FAZBEAR_DEBUG", true);
            PendingIntent pending = PendingIntent.getActivity(context, 9002, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, channelId) : new Notification.Builder(context);
            Notification notification = builder.setSmallIcon(android.R.drawable.stat_notify_error)
                    .setContentTitle("Fazbear Control — " + title)
                    .setContentText(message)
                    .setStyle(new Notification.BigTextStyle().bigText(message + "\nTap to open Advanced Debug."))
                    .setContentIntent(pending).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).build();
            if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                manager.notify(9003, notification);
            }
        } catch (Exception ignored) { }
    }

    void retryError() {
        errorPopup = false;
        send(page, "[STATUS]");
        status = "STATUS REQUEST SENT";
        invalidate();
    }

    void shutdown() {
        try { if (rxSocket != null) rxSocket.close(); } catch (Exception ignored) {}
        net.shutdownNow();
    }

    int accent() { return theme == 1 ? Color.CYAN : (theme == 2 ? Color.YELLOW : 0xFFB000FF); }
    int red() { return 0xFFFF1744; }
    int panel() { return 0xFF090B14; }
    int panel2() { return 0xFF111525; }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(size); p.setColor(color); p.setTextAlign(a); p.setStyle(Paint.Style.FILL);
        c.drawText(s, x, y, p);
    }

    void rect(Canvas c, float l, float t, float r, float b, int color, boolean stroke) {
        p.setColor(color); p.setStyle(stroke ? Paint.Style.STROKE : Paint.Style.FILL); p.setStrokeWidth(stroke ? 1.5f : 1);
        c.drawRect(l, t, r, b, p); p.setStyle(Paint.Style.FILL);
    }

    void button(Canvas c, int x, int y, int w, int h, String label, int color) {
        p.setColor(panel2()); c.drawRoundRect(x, y, x + w, y + h, 7, 7, p);
        rect(c, x, y, x + w, y + h, color, true);
        text(c, label, x + w / 2f, y + h / 2f + 4, 7, Color.WHITE, Paint.Align.CENTER);
    }

    void background(Canvas c) {
        c.drawColor(Color.BLACK);
        for (int y = 0; y < 320; y += 20) {
            p.setColor((y / 20) % 2 == 0 ? 0xFF070711 : 0xFF0A0810);
            c.drawRect(0, y, 480, y + 20, p);
        }
        rect(c, 2, 2, 478, 318, accent(), true);
    }

    void title(Canvas c, String s, String sub) {
        text(c, "FAZBEAR CONTROL", 12, 18, 10, Color.WHITE, Paint.Align.LEFT);
        text(c, s, 240, 20, 14, accent(), Paint.Align.CENTER);
        if (sub != null) text(c, sub, 240, 34, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, syncedVolume >= 0 ? (syncedVolume + "%") : "--%", 468, 16, 7, Color.WHITE, Paint.Align.RIGHT);
        text(c, "VOL SYNC", 468, 28, 5, Color.LTGRAY, Paint.Align.RIGHT);
        rect(c, 8, 40, 472, 41, accent(), false);
    }

    void nav(Canvas c, int selected) {
        rect(c, 0, 276, 480, 320, 0xFF05060B, false);
        String[] n = {"HOME", "DEVICES", "TIMELINE", "CONTROL", "SETTINGS", "DEBUG"};
        for (int i = 0; i < 6; i++) {
            int x = i * 80;
            int col = i == selected ? accent() : Color.LTGRAY;
            text(c, navIcon(i), x + 40, 292, 11, col, Paint.Align.CENTER);
            text(c, n[i], x + 40, 309, 5.5f, col, Paint.Align.CENTER);
        }
    }

    String navIcon(int i) { return new String[]{"⌂", "▣", "≋", "▶", "⚙", "!"}[i]; }

    @Override protected void onDraw(Canvas real) {
        float scale = Math.min(getWidth() / 360f, getHeight() / 800f);
        float ox = (getWidth() - 360f * scale) / 2f;
        float oy = (getHeight() - 800f * scale) / 2f;
        real.drawColor(Color.BLACK);
        real.save();
        real.translate(ox, oy);
        real.scale(scale, scale);
        Canvas c = real;
        portraitBackground(c);
        switch (screen) {
            case HOME: portraitHome(c); break;
            case DEVICES: portraitDevices(c); break;
            case ANIMATIONS: portraitAnimations(c); break;
            case TIMELINE: portraitTimeline(c); break;
            case CONTROL: portraitControl(c); break;
            case SETTINGS: portraitSettings(c); break;
            case DEBUG: portraitDebug(c); break;
            case DEVICE_DETAIL: portraitDeviceDetail(c); break;
        }
        if (screen != DEVICE_DETAIL) portraitNav(c, screen);
        if (errorPopup) portraitErrorPopup(c);
        real.restore();
    }

    void portraitBackground(Canvas c) {
        c.drawColor(0xFF080611);
        for (int y = 0; y < 800; y += 24) {
            p.setColor((y / 24) % 2 == 0 ? 0xFF10091B : 0xFF0A0712);
            c.drawRect(0, y, 360, y + 24, p);
        }
        rect(c, 7, 7, 353, 793, 0xFF30203D, true);
        rect(c, 11, 11, 349, 789, red(), true);
    }

    void portraitHeader(Canvas c, String heading, String sub) {
        rect(c, 12, 14, 348, 94, 0xFF100A1A, false);
        text(c, "FAZBEAR CONTROL", 180, 42, 20, Color.WHITE, Paint.Align.CENTER);
        text(c, heading, 180, 68, 15, accent(), Paint.Align.CENTER);
        text(c, sub, 180, 84, 8, Color.LTGRAY, Paint.Align.CENTER);
    }

    void pButton(Canvas c, int x, int y, int w, int h, String label, int color) {
        button(c, x, y, w, h, label, color);
    }

    void portraitNav(Canvas c, int selected) {
        rect(c, 12, 720, 348, 786, 0xFF090711, false);
        String[] labels = {"HOME", "DEVICES", "ANIMATIONS", "CONTROL", "SETTINGS"};
        int[] screens = {HOME, DEVICES, ANIMATIONS, CONTROL, SETTINGS};
        for (int i = 0; i < labels.length; i++) {
            int x = 14 + i * 66;
            int col = selected == screens[i] ? accent() : 0xFF9B91AA;
            text(c, new String[]{"⌂", "▣", "▤", "▶", "⚙"}[i], x + 31, 750, 15, col, Paint.Align.CENTER);
            text(c, labels[i], x + 31, 770, 6.5f, col, Paint.Align.CENTER);
            if (selected == screens[i]) rect(c, x + 8, 778, x + 54, 781, col, false);
        }
    }

    void portraitAnimations(Canvas c) {
        portraitHeader(c, "ANIMATIONS", "8 SHOW SLOTS  •  SELECT TO PLAY");
        for (int i = 0; i < 8; i++) {
            int col = i % 2, row = i / 2;
            int x = 20 + col * 164, y = 112 + row * 145;
            rect(c, x, y, x + 156, y + 132, panel2(), false);
            rect(c, x, y, x + 156, y + 132, i + 1 == selectedAnimation ? accent() : 0xFF3B2D50, true);
            Bitmap thumb = customAnimImages[i] != null ? customAnimImages[i] : chars[i == 0 ? 1 : i == 1 ? 0 : i == 2 ? 2 : i == 4 ? 3 : i % 4];
            image(c, thumb, new RectF(x + 6, y + 6, x + 150, y + 91));
            text(c, (i + 1) + ". " + animNames[i], x + 8, y + 108, 8, Color.WHITE, Paint.Align.LEFT);
            pButton(c, x + 62, y + 96, 44, 28, "IMG", 0xFF303444);
            pButton(c, x + 112, y + 96, 36, 28, "▶", accent());
        }
    }

    void chooseAnimationImage(int slot) {
        pendingImageSlot = slot;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_ANIMATION_IMAGE); }
        catch (Exception ex) { addLog("IMAGE PICKER ERROR: " + ex.getMessage()); }
    }

    void handleImageResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PICK_ANIMATION_IMAGE || resultCode != Activity.RESULT_OK || data == null || data.getData() == null || pendingImageSlot < 0) return;
        android.net.Uri uri = data.getData();
        try {
            appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        loadCustomAnimationImage(pendingImageSlot, uri);
        customAnimUris[pendingImageSlot] = uri.toString();
        prefs.edit().putString("animImage" + pendingImageSlot, uri.toString()).apply();
        addLog("CUSTOM IMAGE SET FOR ANIMATION " + (pendingImageSlot + 1));
        pendingImageSlot = -1;
        invalidate();
    }

    void loadCustomAnimationImage(int slot, android.net.Uri uri) {
        try (java.io.InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) customAnimImages[slot] = BitmapFactory.decodeStream(in);
        } catch (Exception ex) { addLog("IMAGE LOAD ERROR: SLOT " + (slot + 1)); }
    }

    void portraitHome(Canvas c) {
        portraitHeader(c, "SECURITY TERMINAL", "WIRELESS SHOW CONTROL");
        RectF gifBox = new RectF(24, 112, 336, 342);
        if (menuGif != null) {
            int duration = Math.max(1, menuGif.duration());
            if (menuGifStartedAt < 0) menuGifStartedAt = android.os.SystemClock.uptimeMillis();
            int frameTime = (int)((android.os.SystemClock.uptimeMillis() - menuGifStartedAt) % duration);
            menuGif.setTime(frameTime);
            float fit = Math.min(gifBox.width() / menuGif.width(), gifBox.height() / menuGif.height());
            float dw = menuGif.width() * fit, dh = menuGif.height() * fit;
            c.save();
            c.translate(gifBox.centerX() - dw / 2f, gifBox.centerY() - dh / 2f);
            c.scale(fit, fit);
            menuGif.draw(c, 0, 0);
            c.restore();
            if (screen == HOME) postInvalidateDelayed(40);
        } else {
            image(c, chars[0], gifBox);
        }
        text(c, "LET'S PUT ON A SHOW!", 180, 366, 17, red(), Paint.Align.CENTER);
        int on = 0; for (boolean b : online) if (b) on++;
        rect(c, 24, 382, 336, 444, panel2(), false);
        text(c, "CONTROLLERS ONLINE", 40, 406, 10, Color.LTGRAY, Paint.Align.LEFT);
        text(c, on + " / 4", 320, 426, 22, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.RIGHT);
        pButton(c, 24, 460, 312, 56, "▶  START SHOW", accent());
        pButton(c, 24, 530, 312, 48, "MANAGE DEVICES", 0xFF252039);
        pButton(c, 24, 590, 312, 48, "TIMELINE", 0xFF252039);
        pButton(c, 24, 650, 312, 48, "SHOW CONTROL", 0xFF252039);
        text(c, "Volume is controlled by the ESP32 potentiometer", 180, 706, 7, Color.LTGRAY, Paint.Align.CENTER);
    }

    void portraitDevices(Canvas c) {
        portraitHeader(c, "DEVICES", "SELECT A CONTROLLER");
        for (int i = 0; i < 4; i++) {
            int y = 112 + i * 142;
            rect(c, 22, y, 338, y + 128, panel2(), false);
            rect(c, 22, y, 338, y + 128, i == page ? accent() : 0xFF354056, true);
            image(c, chars[i], new RectF(32, y + 12, 130, y + 94));
            text(c, "ESP32 — " + names[i], 143, y + 28, 12, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "● ONLINE" : "● OFFLINE", 143, y + 48, 9, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, ips[i], 143, y + 66, 8, Color.LTGRAY, Paint.Align.LEFT);
            text(c, "Playing: " + playing[i], 143, y + 84, 8, accent(), Paint.Align.LEFT);
            pButton(c, 34, y + 98, 292, 24, "OPEN CONTROLLER  ›", accent());
        }
    }

    void portraitDeviceDetail(Canvas c) {
        portraitHeader(c, "ESP32 — " + names[page], ips[page]);
        pButton(c, 22, 105, 82, 34, "‹ BACK", accent());
        image(c, chars[page], new RectF(22, 153, 150, 253));
        text(c, online[page] ? "● ONLINE" : "● OFFLINE", 170, 178, 10, online[page] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "NOW PLAYING", 170, 201, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, playing[page], 170, 222, 12, Color.WHITE, Paint.Align.LEFT);
        text(c, "VOLUME  " + (syncedVolume >= 0 ? syncedVolume + "%" : "--%"), 170, 244, 9, accent(), Paint.Align.LEFT);
        text(c, "CHOOSE ANIMATION", 24, 286, 11, Color.WHITE, Paint.Align.LEFT);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 2, row = (i - 1) / 2;
            int x = 24 + col * 160, y = 304 + row * 48;
            pButton(c, x, y, 152, 39, String.format(Locale.US, "%02d  %s", i, animNames[i-1]), i == selectedAnimation ? accent() : 0xFF303444);
        }
        pButton(c, 24, 510, 150, 44, "▶ PLAY", Color.GREEN);
        pButton(c, 186, 510, 150, 44, "Ⅱ PAUSE", 0xFF8A6B00);
        pButton(c, 24, 566, 150, 44, "■ STOP", red());
        pButton(c, 186, 566, 150, 44, "↻ RESTART", accent());
        pButton(c, 24, 626, 312, 42, autoplay ? "AUTO NEXT: ON" : "AUTO NEXT: OFF", autoplay ? Color.GREEN : 0xFF303444);
    }

    void portraitTimeline(Canvas c) {
        portraitHeader(c, "TIMELINE", "AUDIO PLAYBACK");
        text(c, "NOW PLAYING", 26, 126, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "Five Nights at Freddy's — Show", 26, 153, 14, Color.WHITE, Paint.Align.LEFT);
        rect(c, 24, 180, 336, 330, panel2(), false);
        rect(c, 24, 180, 336, 330, accent(), true);
        for (int x = 32; x < 328; x += 4) {
            double wave = Math.sin(x * 0.12) * 35 + Math.sin(x * 0.31) * 15 + Math.sin(x * 0.61) * 7;
            p.setColor(x % 24 < 8 ? 0xFFFF1744 : accent());
            c.drawLine(x, 255, x, (float)(255 + wave), p);
        }
        rect(c, 174, 188, 176, 322, Color.WHITE, false);
        text(c, "1:24  /  3:45", 180, 356, 12, Color.WHITE, Paint.Align.CENTER);
        text(c, "STEREO VU METER", 24, 402, 10, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 18; i++) {
            int w = 14, x = 28 + i * 17;
            int h = 15 + (int)(Math.abs(Math.sin(i * 1.7)) * 68);
            int color = i > 14 ? red() : i > 10 ? Color.YELLOW : Color.GREEN;
            rect(c, x, 500 - h, x + w, 500, color, false);
            rect(c, x, 512 - h, x + w, 512, color, false);
        }
        text(c, "L", 18, 478, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, "R", 18, 526, 8, Color.WHITE, Paint.Align.LEFT);
        pButton(c, 24, 550, 94, 44, "−5 SEC", accent());
        pButton(c, 132, 542, 96, 58, "Ⅱ", accent());
        pButton(c, 242, 550, 94, 44, "+5 SEC", accent());
        pButton(c, 24, 614, 312, 44, "■ STOP AUDIO", red());
        text(c, "VOLUME FROM ESP32 POT: " + (syncedVolume >= 0 ? syncedVolume + "%" : "WAITING"), 180, 686, 9, Color.LTGRAY, Paint.Align.CENTER);
    }

    void portraitControl(Canvas c) {
        portraitHeader(c, "SHOW CONTROL", "MULTI-CONTROLLER");
        text(c, "SELECTED ANIMATION", 26, 126, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation-1]), 26, 154, 15, Color.WHITE, Paint.Align.LEFT);
        pButton(c, 24, 184, 150, 56, "▶ PLAY ALL", Color.GREEN);
        pButton(c, 186, 184, 150, 56, "Ⅱ PAUSE ALL", 0xFF8A6B00);
        pButton(c, 24, 254, 150, 56, "■ STOP ALL", red());
        pButton(c, 186, 254, 150, 56, "↻ RESTART", accent());
        for (int i = 0; i < 4; i++) {
            int y = 334 + i * 76;
            rect(c, 24, y, 336, y + 62, panel2(), false);
            image(c, chars[i], new RectF(32, y + 6, 90, y + 56));
            text(c, names[i], 104, y + 24, 11, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "ONLINE" : "OFFLINE", 104, y + 44, 8, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, playing[i], 220, y + 34, 8, accent(), Paint.Align.LEFT);
        }
        pButton(c, 24, 650, 150, 42, loop ? "LOOP: ON" : "LOOP: OFF", loop ? Color.GREEN : 0xFF303444);
        pButton(c, 186, 650, 150, 42, autoplay ? "AUTO NEXT: ON" : "AUTO NEXT: OFF", autoplay ? Color.GREEN : 0xFF303444);
    }

    void editControllerAddress(int which) {
        if (which < 0 || which >= 4) return;
        EditText input = new EditText(appContext);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("e.g. 192.168.1.101");
        input.setText(ips[which]);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(appContext)
                .setTitle("ESP32 — " + names[which] + " IP Address")
                .setMessage("Enter the controller's IPv4 address.")
                .setView(input)
                .setNegativeButton("CANCEL", (dialog, id) -> dialog.dismiss())
                .setNeutralButton("DEFAULT", (dialog, id) -> {
                    ips[which] = defaultIPs[which];
                    prefs.edit().putString("ip" + which, ips[which]).apply();
                    addLog("IP UPDATED: " + names[which] + " = " + ips[which]);
                    invalidate();
                })
                .setPositiveButton("SAVE", (dialog, id) -> {
                    String candidate = input.getText().toString().trim();
                    if (isValidIPv4(candidate)) {
                        ips[which] = candidate;
                        prefs.edit().putString("ip" + which, candidate).apply();
                        addLog("IP UPDATED: " + names[which] + " = " + candidate);
                        invalidate();
                    } else {
                        new AlertDialog.Builder(appContext)
                                .setTitle("Invalid IP address")
                                .setMessage("Enter an IPv4 address such as 192.168.1.101.")
                                .setPositiveButton("OK", null)
                                .show();
                    }
                })
                .show();
    }

    boolean isValidIPv4(String value) {
        String[] parts = value.split("\\\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) return false;
            for (int i = 0; i < part.length(); i++) {
                if (!Character.isDigit(part.charAt(i))) return false;
            }
            try {
                int n = Integer.parseInt(part);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    void portraitSettings(Canvas c) {
        portraitHeader(c, "SETTINGS", "NETWORK + STATUS");
        text(c, "TAP ADDRESS TO EDIT  •  TEST TO PING", 24, 124, 9, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            int y = 140 + i * 82;
            rect(c, 24, y, 336, y + 68, panel2(), false);
            text(c, names[i], 36, y + 24, 11, Color.WHITE, Paint.Align.LEFT);
            text(c, ips[i], 36, y + 45, 9, Color.LTGRAY, Paint.Align.LEFT);
            pButton(c, 242, y + 16, 80, 36, "TEST", accent());
        }
        text(c, "VOLUME IS READ-ONLY", 24, 510, 10, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "% — SYNCED FROM ESP32" : "WAITING FOR ESP32", 24, 536, 11, Color.WHITE, Paint.Align.LEFT);
        pButton(c, 24, 566, 312, 44, theme == 0 ? "THEME: NEON PURPLE" : "THEME: CYAN", accent());
        pButton(c, 24, 622, 150, 44, "ADVANCED DEBUG", 0xFF303444);
        pButton(c, 186, 622, 150, 44, "CLEAR LOG", red());
    }

    void portraitDebug(Canvas c) {
        portraitHeader(c, "DEBUG", "WIRELESS SERIAL MONITOR");
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, "RX 4211  •  TX 4210  •  " + on + "/4 ONLINE", 24, 120, 9, Color.LTGRAY, Paint.Align.LEFT);
        rect(c, 22, 138, 338, 640, panel2(), false);
        int start = Math.max(0, log.size() - 24), y = 158;
        for (int i = start; i < log.size(); i++) {
            String line = log.get(i);
            if (line.length() > 46) line = line.substring(0, 46);
            text(c, line, 30, y, 7, Color.LTGRAY, Paint.Align.LEFT);
            y += 19;
        }
        pButton(c, 24, 660, 96, 42, "CLEAR", red());
        pButton(c, 132, 660, 96, 42, "STATUS", accent());
        pButton(c, 240, 660, 96, 42, "TEST ALL", Color.GREEN);
    }

    void portraitErrorPopup(Canvas c) {
        rect(c, 0, 0, 360, 800, 0xDD000000, false);
        rect(c, 22, 270, 338, 530, 0xFF10050A, false);
        rect(c, 22, 270, 338, 530, red(), true);
        text(c, "⚠ SYSTEM ERROR", 180, 310, 17, red(), Paint.Align.CENTER);
        text(c, errorTitle, 180, 350, 12, Color.WHITE, Paint.Align.CENTER);
        text(c, errorMessage, 180, 385, 10, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "Open DEBUG for details", 180, 420, 9, Color.LTGRAY, Paint.Align.CENTER);
        pButton(c, 34, 455, 90, 44, "RETRY", accent());
        pButton(c, 135, 455, 90, 44, "DETAILS", Color.WHITE);
        pButton(c, 236, 455, 90, 44, "CLOSE", red());
    }

    void image(Canvas c, Bitmap b, RectF dst) {
        if (b == null) return;
        Rect src = new Rect(0, 0, b.getWidth(), b.getHeight());
        c.drawBitmap(b, src, dst, p);
    }

    void drawHome(Canvas c) {
        title(c, "HOME", "WIRELESS SHOW CONTROL");
        image(c, chars[0], new RectF(15, 50, 230, 178));
        text(c, "FAZBEAR", 245, 74, 22, Color.WHITE, Paint.Align.LEFT);
        text(c, "CONTROL", 245, 98, 22, red(), Paint.Align.LEFT);
        text(c, "4 ESP32 CONTROLLERS", 245, 119, 7, Color.LTGRAY, Paint.Align.LEFT);
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, on + " / 4 ONLINE", 245, 137, 12, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        button(c, 245, 148, 105, 31, "START SHOW", accent());
        button(c, 360, 148, 105, 31, "DEBUG", Color.DKGRAY);

        button(c, 15, 190, 106, 42, "DEVICES", accent());
        button(c, 130, 190, 106, 42, "TIMELINE", accent());
        button(c, 245, 190, 106, 42, "CONTROL", accent());
        button(c, 360, 190, 105, 42, "SETTINGS", accent());
        text(c, "PHYSICAL ESP32 POTENTIOMETER = VOLUME SOURCE", 240, 250, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, status, 240, 265, 6, Color.WHITE, Paint.Align.CENTER);
        nav(c, HOME);
    }

    void deviceCard(Canvas c, int i, int y) {
        int a = i == page ? accent() : 0xFF263044;
        rect(c, 10, y, 470, y + 48, panel2(), false);
        rect(c, 10, y, 470, y + 48, a, true);
        image(c, chars[i], new RectF(16, y + 4, 68, y + 44));
        text(c, "ESP32 - " + names[i], 78, y + 15, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, ips[i], 78, y + 28, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, online[i] ? "● ONLINE" : "● OFFLINE", 78, y + 40, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "Playing: " + playing[i], 205, y + 16, 6.5f, Color.WHITE, Paint.Align.LEFT);
        text(c, "Animation " + String.format(Locale.US, "%02d", i == 3 ? 5 : selectedAnimation), 205, y + 29, 6, accent(), Paint.Align.LEFT);
        button(c, 372, y + 7, 45, 30, "PLAY", Color.GREEN);
        button(c, 423, y + 7, 40, 30, "…", a);
    }

    void drawDevices(Canvas c) {
        title(c, "DEVICES", "4 ESP32 CONTROLLERS");
        for (int i = 0; i < 4; i++) deviceCard(c, i, 47 + i * 51);
        text(c, "TAP A DEVICE FOR ANIMATIONS + PLAYBACK", 240, 262, 5.5f, Color.LTGRAY, Paint.Align.CENTER);
        nav(c, DEVICES);
    }

    void drawDeviceDetail(Canvas c) {
        title(c, "ESP32 - " + names[page], ips[page]);
        button(c, 10, 48, 55, 26, "BACK", accent());
        image(c, chars[page], new RectF(75, 48, 175, 112));
        text(c, online[page] ? "● ONLINE" : "● OFFLINE", 190, 61, 7, online[page] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "NOW PLAYING", 190, 78, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, playing[page], 190, 94, 11, Color.WHITE, Paint.Align.LEFT);
        text(c, "VOLUME  " + (syncedVolume >= 0 ? syncedVolume + "%" : "--%") + "  •  ESP32 POT", 190, 108, 6, Color.LTGRAY, Paint.Align.LEFT);

        text(c, "ANIMATIONS", 12, 132, 8, accent(), Paint.Align.LEFT);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 4, row = (i - 1) / 4;
            int x = 12 + col * 116, y = 140 + row * 30;
            button(c, x, y, 105, 23, String.format(Locale.US, "%02d  %s", i, animNames[i - 1]), i == selectedAnimation ? accent() : 0xFF303444);
        }
        button(c, 12, 205, 92, 29, "PLAY", Color.GREEN);
        button(c, 112, 205, 92, 29, "PAUSE", Color.YELLOW);
        button(c, 212, 205, 92, 29, "STOP", red());
        button(c, 312, 205, 92, 29, "RESTART", accent());
        button(c, 412, 205, 56, 29, "BACK", 0xFF303444);
        text(c, "AUTOPLAY NEXT", 15, 252, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, autoplay ? "ON" : "OFF", 110, 252, 7, autoplay ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "UDP 4210", 470, 252, 6, Color.LTGRAY, Paint.Align.RIGHT);
    }

    void drawTimeline(Canvas c) {
        title(c, "TIMELINE", "AUDIO PLAYBACK");
        text(c, "NOW PLAYING", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "Five Nights at Freddy's - Show", 15, 73, 9, Color.WHITE, Paint.Align.LEFT);
        rect(c, 12, 84, 392, 146, panel2(), false);
        rect(c, 12, 84, 392, 146, accent(), true);
        p.setStrokeWidth(2);
        for (int x = 16; x < 390; x += 4) {
            double wave = Math.sin(x * 0.12) * 13 + Math.sin(x * 0.31) * 6 + Math.sin(x * 0.61) * 3;
            p.setColor(x % 24 < 8 ? 0xFFFF1744 : accent());
            c.drawLine(x, 115, x, (float)(115 + wave), p);
        }
        rect(c, 188, 86, 190, 144, Color.WHITE, false);
        text(c, "1:24 / 3:45", 202, 160, 7, Color.WHITE, Paint.Align.CENTER);
        text(c, "L", 420, 92, 6, Color.WHITE, Paint.Align.CENTER);
        text(c, "R", 458, 92, 6, Color.WHITE, Paint.Align.CENTER);
        for (int i = 0; i < 8; i++) {
            int h = 12 + (i % 5) * 5;
            rect(c, 415, 142 - h, 430, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
            rect(c, 448, 142 - h, 463, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
        }
        button(c, 35, 170, 65, 30, "-5s", accent());
        button(c, 108, 170, 80, 30, "◀◀", accent());
        button(c, 198, 166, 44, 38, "Ⅱ", accent());
        button(c, 252, 170, 80, 30, "▶▶", accent());
        button(c, 340, 170, 65, 30, "+5s", accent());
        text(c, "CURRENT EVENT", 15, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "Freddy Move", 15, 238, 9, Color.WHITE, Paint.Align.LEFT);
        text(c, "00:45", 120, 238, 7, accent(), Paint.Align.LEFT);
        text(c, "PHYSICAL VOLUME", 280, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%" : "WAITING", 280, 238, 10, Color.WHITE, Paint.Align.LEFT);
        nav(c, TIMELINE);
    }

    void drawControl(Canvas c) {
        title(c, "SHOW CONTROL", "MULTI-ESP32");
        text(c, "SELECTED ANIMATION", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation - 1]), 15, 76, 12, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 92, 106, 40, "PLAY ALL", Color.GREEN);
        button(c, 129, 92, 106, 40, "PAUSE ALL", Color.YELLOW);
        button(c, 243, 92, 106, 40, "STOP ALL", red());
        button(c, 357, 92, 108, 40, "RESTART", accent());
        for (int i = 0; i < 4; i++) {
            int x = 15 + (i % 2) * 230, y = 145 + (i / 2) * 48;
            rect(c, x, y, x + 215, y + 40, panel2(), false);
            text(c, names[i], x + 10, y + 15, 7, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "ONLINE" : "OFFLINE", x + 10, y + 29, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, playing[i], x + 85, y + 22, 7, accent(), Paint.Align.LEFT);
        }
        button(c, 15, 243, 140, 25, loop ? "LOOP ON" : "LOOP OFF", loop ? Color.GREEN : Color.DKGRAY);
        button(c, 165, 243, 140, 25, autoplay ? "AUTO NEXT ON" : "AUTO NEXT OFF", autoplay ? Color.GREEN : Color.DKGRAY);
        nav(c, CONTROL);
    }

    void drawSettings(Canvas c) {
        title(c, "SETTINGS", "APP + CONTROLLER STATUS");
        text(c, "CONTROLLER IP ADDRESSES", 15, 57, 7, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            int y = 65 + i * 40;
            text(c, names[i], 15, y + 17, 7, Color.WHITE, Paint.Align.LEFT);
            rect(c, 92, y, 280, y + 27, panel2(), false);
            text(c, ips[i], 102, y + 18, 7, Color.WHITE, Paint.Align.LEFT);
            button(c, 292, y, 75, 27, "TEST", accent());
            text(c, online[i] ? "ONLINE" : "OFFLINE", 382, y + 17, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        }
        text(c, "VOLUME IS READ-ONLY", 15, 239, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%  •  SYNCED FROM ESP32 POT" : "WAITING FOR ESP32", 160, 239, 6, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 250, 110, 25, theme == 0 ? "NEON PURPLE" : "CYAN THEME", accent());
        button(c, 135, 250, 110, 25, "DEBUG", Color.DKGRAY);
        button(c, 255, 250, 110, 25, "CLEAR LOG", red());
        nav(c, SETTINGS);
    }

    void drawDebug(Canvas c) {
        title(c, "DEBUG", "WIRELESS SERIAL + DIAGNOSTICS");
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, "UDP RX 4211", 12, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "UDP TX 4210", 110, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, on + "/4 ONLINE", 220, 56, 7, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "VOLUME " + (syncedVolume >= 0 ? syncedVolume + "%" : "WAITING"), 330, 56, 7, Color.WHITE, Paint.Align.LEFT);
        rect(c, 10, 64, 470, 242, panel2(), false);
        int start = Math.max(0, log.size() - 11), y = 80;
        for (int i = start; i < log.size(); i++) {
            String s = log.get(i);
            if (s.length() > 74) s = s.substring(0, 74);
            text(c, s, 16, y, 5.5f, Color.LTGRAY, Paint.Align.LEFT);
            y += 15;
        }
        button(c, 12, 248, 95, 25, "CLEAR", red());
        button(c, 115, 248, 95, 25, "STATUS", accent());
        button(c, 218, 248, 110, 25, "TEST ALL", Color.GREEN);
        text(c, "ERROR POPUP: READY", 345, 264, 5.5f, errorPopup ? red() : Color.GREEN, Paint.Align.CENTER);
        nav(c, DEBUG);
    }

    void drawErrorPopup(Canvas c) {
        rect(c, 0, 0, 480, 320, 0x99000000, false);
        int l = 42, t = 67, r = 438, b = 252;
        rect(c, l, t, r, b, 0xFF10050A, false);
        rect(c, l, t, r, b, red(), true);
        text(c, "⚠  SYSTEM ERROR", 240, 92, 13, red(), Paint.Align.CENTER);
        text(c, errorTitle, 240, 116, 9, Color.WHITE, Paint.Align.CENTER);
        text(c, errorMessage, 240, 139, 8, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "Details are available in DEBUG.", 240, 160, 6, Color.LTGRAY, Paint.Align.CENTER);
        button(c, 62, 191, 100, 34, "RETRY", accent());
        button(c, 190, 191, 100, 34, "DETAILS", Color.WHITE);
        button(c, 318, 191, 100, 34, "CLOSE", red());
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;
        float scale = Math.min(getWidth() / 360f, getHeight() / 800f);
        float ox = (getWidth() - 360f * scale) / 2f;
        float oy = (getHeight() - 800f * scale) / 2f;
        float x = (e.getX() - ox) / scale;
        float y = (e.getY() - oy) / scale;
        if (x < 0 || x > 360 || y < 0 || y > 800) return true;

        if (errorPopup) {
            if (y >= 450 && y <= 510) {
                if (x < 130) retryError();
                else if (x < 230) { errorPopup = false; screen = DEBUG; }
                else errorPopup = false;
            }
            invalidate(); return true;
        }

        if (screen == DEVICE_DETAIL) {
            if (y >= 100 && y < 145) { screen = DEVICES; invalidate(); return true; }
            if (y >= 300 && y < 500) {
                int col = x < 180 ? 0 : 1;
                int row = (int)((y - 304) / 48);
                int a = row * 2 + col + 1;
                if (a >= 1 && a <= 8) { selectedAnimation = a; invalidate(); return true; }
            }
            if (y >= 505 && y < 560) {
                if (x < 180) play(page, selectedAnimation);
                else { send(page, "[PAUSE]"); status = "PAUSED"; }
            } else if (y >= 560 && y < 615) {
                if (x < 180) { send(page, "[STOP]"); status = "STOPPED"; }
                else { send(page, "[RESTART]"); status = "RESTARTED"; }
            } else if (y >= 620 && y < 680) autoplay = !autoplay;
            invalidate(); return true;
        }

        if (y >= 720) {
            int n = Math.max(0, Math.min(4, (int)((x - 14) / 66)));
            int[] screens = {HOME, DEVICES, ANIMATIONS, CONTROL, SETTINGS};
            screen = screens[n]; invalidate(); return true;
        }

        if (screen == HOME) {
            if (y >= 450 && y < 520) { playAll(); screen = CONTROL; }
            else if (y >= 525 && y < 580) screen = DEVICES;
            else if (y >= 585 && y < 640) screen = TIMELINE;
            else if (y >= 645 && y < 705) screen = CONTROL;
        } else if (screen == DEVICES) {
            if (y >= 112 && y < 680) {
                int i = (int)((y - 112) / 142);
                if (i >= 0 && i < 4) { page = i; screen = DEVICE_DETAIL; }
            }
        } else if (screen == ANIMATIONS) {
            if (y >= 112 && y < 692) {
                int col = x < 180 ? 0 : 1;
                int row = (int)((y - 112) / 145);
                int a = row * 2 + col + 1;
                if (a >= 1 && a <= 8) {
                    selectedAnimation = a;
                    int cardX = col == 0 ? 20 : 184;
                    float localX = x - cardX;
                    if (localX >= 108) playAll();
                    else if (localX >= 58 && localX < 108) chooseAnimationImage(a - 1);
                }
            }
        } else if (screen == TIMELINE) {
            if (y >= 540 && y < 605) {
                if (x < 125) status = "SEEK -5s";
                else if (x < 235) { broadcast("[PAUSE]"); status = "PAUSED"; }
                else status = "SEEK +5s";
            } else if (y >= 610 && y < 670) { broadcast("[STOP]"); status = "STOPPED"; }
        } else if (screen == CONTROL) {
            if (y >= 180 && y < 245) {
                if (x < 180) playAll();
                else { broadcast("[PAUSE]"); status = "PAUSE ALL"; }
            } else if (y >= 250 && y < 315) {
                if (x < 180) { broadcast("[STOP]"); status = "STOP ALL"; }
                else { broadcast("[RESTART]"); status = "RESTART ALL"; }
            } else if (y >= 645 && y < 705) {
                if (x < 180) loop = !loop; else autoplay = !autoplay;
            }
        } else if (screen == SETTINGS) {
            if (y >= 140 && y < 468) {
                int i = (int)((y - 140) / 82);
                if (i >= 0 && i < 4) {
                    if (x >= 225) send(i, "[STATUS]");
                    else editControllerAddress(i);
                }
            } else if (y >= 560 && y < 615) theme = 1 - theme;
            else if (y >= 620 && y < 680) {
                if (x < 180) screen = DEBUG; else log.clear();
            }
        } else if (screen == DEBUG) {
            if (y >= 655 && y < 710) {
                if (x < 125) log.clear();
                else if (x < 235) for (int i = 0; i < 4; i++) send(i, "[STATUS]");
                else broadcast("[STATUS]");
            }
        }
        invalidate(); return true;
    }

    boolean touchDeviceDetail(float x, float y) {
        if (y >= 48 && y <= 78 && x < 70) { screen = DEVICES; invalidate(); return true; }
        if (y >= 140 && y < 200) {
            int col = (int)((x - 12) / 116), row = (int)((y - 140) / 30);
            if (col >= 0 && col < 4 && row >= 0 && row < 2) {
                int a = row * 4 + col + 1;
                selectedAnimation = a;
                play(page, a);
                invalidate(); return true;
            }
        }
        if (y >= 205 && y < 240) {
            if (x < 104) { play(page, selectedAnimation); }
            else if (x < 204) { send(page, "[PAUSE]"); status = "PAUSED " + names[page]; }
            else if (x < 304) { send(page, "[STOP]"); status = "STOPPED " + names[page]; }
            else if (x < 404) { send(page, "[RESTART]"); progress[page] = 0; status = "RESTARTED " + names[page]; }
            else { screen = DEVICES; }
            invalidate(); return true;
        }
        if (y >= 240 && y < 270 && x < 160) { autoplay = !autoplay; invalidate(); return true; }
        return true;
    }
}
