FAZBEAR CONTROL — 33 CLEAN PNG ASSETS

These PNGs contain artwork only. No PLAY, STOP, RESTART, OPEN CONTROLLER,
or other app buttons are embedded in the artwork.

Structure:
- themes/: 24 files = 6 themes × 4 device images (Freddy, Bonnie, Chica, Stage)
- animations/: 8 clean animation artwork thumbnails
- home/: 1 combined character image (Bonnie left, Freddy center, Chica right)

Themes:
1. FNAF Dark
2. Security Night
3. Arcade Stage
4. Halloween
5. CCTV Green
6. Glitch Purple
