FAZBEAR CONTROL - 2.5 SECOND ANIMATION DELAY

Added a 2.5 second delay between animations during scheduled shows.

Behavior:
- Applies to scheduled shows in Bottango timing mode.
- Applies to scheduled shows in Manual timing mode.
- When an animation completes, its phone/background WAV is stopped.
- A silent 2.5 second gap occurs before the next animation starts.
- Duplicate ANIM_DONE packets during the gap are ignored.
- The next animation is checked for a detectable WAV before starting.
- If no detectable WAVs remain, the scheduled show is ended and the original repeat countdown is restarted.
- The delay callback is cancelled when the scheduled show is stopped/exited.
- Normal non-scheduled manual playback behavior is unchanged.
