ARTWORK COUNTDOWN UPDATE

All active scheduled countdown/intermission screens now use the uploaded
show_timer_background artwork, including the portrait scheduled-show fallback.
The black code-rendered intro/outro screens remain unchanged and are the only
intentional black-screen transitions.

Landscape countdown already uses show_timer_background and remains unchanged.
