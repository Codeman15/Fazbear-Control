RESTORED LANDSCAPE COUNTDOWN ARTWORK
- Restored the full show_timer_background.webp artwork behind the landscape scheduled-show countdown.
- Preserves the uploaded artwork aspect ratio with center-crop.
- Reduced the dark overlay so Freddy, Bonnie, Chica, and the stage remain clearly visible.
- UI remains code-drawn on top and countdown remains live.
