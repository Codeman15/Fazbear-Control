MP4 2 CODE-RENDERED OUTRO UPDATE

The uploaded Videoleap MP4 for the scheduled outro was recreated as a lightweight Android Canvas animation.

Visual:
- Black background
- Thanks for
- stopping by
- Happy Halloween
- Large text (140 logical px) matching the large code-rendered black-screen treatment
- Fade in and fade out

Timing:
- 18.2 seconds, matching the uploaded video's ~18.18 second visual duration

Audio:
- The uploaded MP4's AAC soundtrack is extracted and bundled as scheduled_outro_audio.mp3.
- MP4 2 uses this audio instead of the intro soundtrack.

There is no video decoder, TextureView, Surface, or MP4 playback for MP4 2.
