FAZBEAR CONTROL - 55 SEPARATE THEME IMAGES

This version keeps 55 individual theme artwork files:
11 themes x Freddy, Bonnie, Chica, Stage, Background UI.

The files are separate JPEG assets and are optimized for Android rather than stored as 4K masters. They are 1920px wide (preserving each image's aspect ratio) to keep the project upload size reasonable while retaining high quality on a phone/tablet.

The Devices artwork uses aspect-fit so character/stage images are not aggressively cropped.
