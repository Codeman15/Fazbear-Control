package com.fazbear.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Locale;

/** Receives background show alarms and dispatches the existing ESP32 UDP start command. */
public final class ScheduledShowReceiver extends BroadcastReceiver {
    private static MediaPlayer scheduledPlayer;

    /** Stop audio started by this background receiver (called by the main app). */
    public static synchronized void stopPhoneAudio() {
        MediaPlayer player = scheduledPlayer;
        scheduledPlayer = null;
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) { }
            try { player.reset(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        int animation = intent != null ? intent.getIntExtra("animation", prefs.getInt("schedule_animation", 1)) : prefs.getInt("schedule_animation", 1);
        animation = Math.max(1, Math.min(8, animation));
        final int selected = animation;
        final PendingResult result = goAsync();
        new Thread(() -> {
            try {
                String[] defaults = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
                for (int i = 0; i < 4; i++) {
                    String ip = prefs.getString("ip" + i, defaults[i]);
                    byte[] data = ("[START " + selected + "]").getBytes("UTF-8");
                    try (DatagramSocket socket = new DatagramSocket()) {
                        socket.send(new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210));
                    } catch (Exception ignored) { }
                }
                // Play the animation's assigned local WAV in the phone when the saved mode requests it.
                int mode = prefs.getInt("audio_output_mode", 0);
                String uri = prefs.getString("animWavUri" + (selected - 1), null);
                // When Fazbear Control is visible, its in-app scheduler owns WAV
                // playback. Do not start a second player for the same show.
                if (mode != 0 && uri != null && !MainActivity.isAppVisible()) {
                    try {
                        stopPhoneAudio();
                        MediaPlayer player = new MediaPlayer();
                        synchronized (ScheduledShowReceiver.class) { scheduledPlayer = player; }
                        player.setDataSource(context, Uri.parse(uri));
                        player.setOnCompletionListener(mp -> { mp.release(); synchronized (ScheduledShowReceiver.class) { if (scheduledPlayer == mp) scheduledPlayer = null; } });
                        player.setOnErrorListener((mp, what, extra) -> { mp.release(); synchronized (ScheduledShowReceiver.class) { if (scheduledPlayer == mp) scheduledPlayer = null; } return true; });
                        player.prepare(); player.start();
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) {
            } finally {
                // Re-arm the next recurring occurrence using current saved schedule settings.
                if (prefs.getBoolean("schedule_enabled", false)) {
                    ScheduleAlarm.schedule(context, true, prefs.getInt("schedule_hour", 19),
                            prefs.getInt("schedule_minute", 0), prefs.getInt("schedule_days", 0),
                            prefs.getInt("schedule_animation", selected));
                }
                result.finish();
            }
        }, "Fazbear-Scheduled-Show").start();
    }
}
