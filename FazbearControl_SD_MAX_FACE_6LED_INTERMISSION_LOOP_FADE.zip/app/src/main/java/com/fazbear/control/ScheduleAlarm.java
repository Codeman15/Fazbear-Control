package com.fazbear.control;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

/** Alarm scheduling helper for recurring Fazbear shows. */
public final class ScheduleAlarm {
    private static final int REQUEST_CODE = 7814;
    private ScheduleAlarm() {}

    static PendingIntent pending(Context context, int animation) {
        Intent intent = new Intent(context, ScheduledShowReceiver.class);
        intent.setAction("com.fazbear.control.SCHEDULED_SHOW");
        intent.putExtra("animation", animation);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }

    public static void schedule(Context context, boolean enabled, int hour, int minute, int days, int animation) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(context, animation);
        alarms.cancel(pi);
        if (!enabled) return;
        long next = nextTime(hour, minute, days, System.currentTimeMillis());
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT >= 31 && !alarms.canScheduleExactAlarms()) {
                alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
            } else {
                alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
            }
        } else if (Build.VERSION.SDK_INT >= 19) {
            alarms.setExact(AlarmManager.RTC_WAKEUP, next, pi);
        } else {
            alarms.set(AlarmManager.RTC_WAKEUP, next, pi);
        }
    }

    static long nextTime(int hour, int minute, int days, long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        for (int i = 0; i <= 7; i++) {
            Calendar candidate = (Calendar) c.clone();
            candidate.add(Calendar.DAY_OF_YEAR, i);
            int dow = candidate.get(Calendar.DAY_OF_WEEK);
            boolean allowed = days == 0 || (days == 1 && dow >= Calendar.MONDAY && dow <= Calendar.FRIDAY)
                    || (days == 2 && (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY));
            if (allowed && candidate.getTimeInMillis() > now) return candidate.getTimeInMillis();
        }
        c.add(Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    public static void fireNow(Context context, int animation) {
        Intent i = new Intent(context, ScheduledShowReceiver.class);
        i.setAction("com.fazbear.control.SCHEDULED_SHOW");
        i.putExtra("animation", animation);
        context.sendBroadcast(i);
    }
}
