CUSTOM TIMER IMAGE

The scheduled-show/timer screen now supports a user-selected custom image.
Open SHOW SCHEDULE and tap CUSTOM TIMER IMAGE • SELECT. Pick any image from the phone.
The selected image is persisted and shown on the scheduled-show timer screen.
If no custom image is selected, the selected theme's Bonnie/Freddy/Chica group image is used.
Tapping the button again lets the user replace the custom image.
Open 24 Display ST and the larger/final-10-second timer sizing are preserved.
