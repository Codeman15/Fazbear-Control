Timer update:
- Scheduled-show intermission countdown is now larger.
- Show-start countdown is larger in normal mode.
- Final 10 seconds are dramatically larger and change to red with FINAL COUNTDOWN text.
- All timer text continues to use Open 24 Display ST through the existing app font renderer.
