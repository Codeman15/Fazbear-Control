# FAZBEAR CONTROL Android App

Open this extracted folder directly in Android Studio (the folder containing settings.gradle and app/).

## Updates in this version
- Portrait-only orientation (declared in app/src/main/AndroidManifest.xml).
- Eight selectable themes: Neon Purple, Arcade Cyan, Golden Freddy, Security Green, Fazbear Orange, Glitch Pink, Midnight Blue, and Classic Pizzeria.
- Custom image picker for the app background, Home hero image, Freddy, Bonnie, Chica, Stage, and all eight animation thumbnails.
- Custom image choices are saved on the phone. Each image slot has a Reset option.
- The clock/time display is not an image and is not customizable through the image picker.
- Existing controller UDP features and the included menu GIF are preserved.

## GitHub Actions
The repository's existing workflow extracts this ZIP into the repository root and builds the Android project.
