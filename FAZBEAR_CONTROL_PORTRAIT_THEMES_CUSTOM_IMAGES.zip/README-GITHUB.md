# Fazbear Control — GitHub build

The repository workflow extracts the app project ZIP into the repository root and builds the root Android project with Gradle. The debug APK is uploaded as the `Fazbear-Control-debug-apk` artifact.

This project is portrait-only. It supports eight themes and custom images for the app background, Home hero, four controller portraits, and eight animation thumbnails. Clock/time remains text and is not part of image customization.
