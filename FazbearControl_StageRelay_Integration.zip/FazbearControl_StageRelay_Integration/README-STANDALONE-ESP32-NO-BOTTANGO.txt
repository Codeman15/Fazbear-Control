FAZBEAR CONTROL — STANDALONE ESP32 PLAYBACK PATCH
=================================================

This version removes the Android app's dependency on the Bottango Windows
PlaybackState REST API. The app no longer polls or sends HTTP requests to
the Bottango PC, and the diagnostics UI now describes direct ESP32 control.

Playback commands are sent directly to the configured controller IP addresses
over UDP port 4210. The existing command protocol documented in this project
is used, including [START n], [STOP], and [STATUS].

Animation slot mapping:
  App Animation 1 -> [START 1] -> exported ESP32 animation named "1"
  App Animation 2 -> [START 2] -> exported ESP32 animation named "2"
  and so on.

Standalone scheduled-show timing is forced to Manual/Standalone mode and uses
the saved per-animation durations in the app, rather than waiting for Bottango
to report playback progress. The app's existing WAV selection/playback logic
is retained.

Important:
- This ZIP contains the Android app project, not Freddy's ESP32 firmware.
- Freddy's firmware must be flashed/configured to listen on UDP port 4210 and
  accept [START n], [STOP], and [STATUS] commands, and the exported animation
  files must already be on Freddy's SD card.
- UDP sends do not guarantee that a command was accepted. The ESP32 should
  broadcast status/debug replies on UDP port 4211 for diagnostics.
- The project build could not be verified in this environment because Gradle
  attempted to download its distribution and network access was unavailable.
  Open the project in Android Studio and run Build > Make Project / Build APK(s).

Changes made:
- Removed Bottango PlaybackState HTTP polling and REST command calls.
- Routed play/restart/skip/auto-next/stop and idle-slot requests to direct UDP.
- Changed diagnostics labels to direct ESP32/UDP wording.
- Defaulted scheduled shows to standalone manual timing.
