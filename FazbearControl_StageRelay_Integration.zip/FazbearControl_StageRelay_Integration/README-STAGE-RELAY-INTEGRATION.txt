STAGE RELAY INTEGRATION PATCH

MainActivity.java has been updated to send Stage HTTP events when standalone animations start, on SHOW_STOP, and at manual SHOW_END. Configure Stage IP and API token in Settings > Show Timing • Standalone.

This source has not been built or tested in Android Studio in this environment. Build before installing. The Stage firmware/API must be installed and configured with the same token, and the trigger map must reference real saved sequence IDs. If no token is configured, the main app logs that Stage relay integration is not configured and existing ESP32 UDP playback continues.

This patch does not yet implement a Stage-owned calendar scheduler or precise shared start timestamps. See the separate Fazbear Relay Animator README for details.
