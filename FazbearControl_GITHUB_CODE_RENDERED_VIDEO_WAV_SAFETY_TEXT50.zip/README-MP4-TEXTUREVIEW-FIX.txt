MP4 playback update
- Replaced the scheduled in-app VideoView renderer with TextureView + MediaPlayer.
- Video remains inside Fazbear Control; no external player/activity is opened.
- Uses the selected content:// MP4 URI directly.
- Landscape full-screen playback with center-crop.
- Intro MP4 starts at 1 second remaining, stops all countdown/music audio, and after completion the video surface is removed before the scheduled show begins.
- Outro MP4 starts after the show, and after completion the video surface is removed and the app returns to the normal countdown screen for the next scheduled run.
- Scheduled video state remains part of the existing scheduler so it repeats on every scheduled show.
