FAZBEAR CONTROL — SECURITY DIAGNOSTICS UPDATE

This update adds a Security Diagnostics screen to the existing Theme Customization project.

How to access:
1. Open Fazbear Control on the phone.
2. Go to Settings.
3. Tap DIAGNOSTICS.

Screen information:
- Number of ESP32 controllers currently online (based on recent UDP status packets)
- Phone Wi-Fi RSSI when Android reports it
- Bottango playback-state status and last poll age
- Per-controller online state, configured IP, last received packet age, and reported ESP32 Wi-Fi RSSI when available
- A button to request status from the configured ESP32 controllers
- A button to refresh Bottango playback state
- A shortcut to the existing debug/event log

The diagnostics screen is observational and does not issue show playback commands. Existing theme preferences, custom artwork, animation settings, controller settings, and volume reporting remain in the same MainActivity implementation.

To update an existing Android Studio checkout, replace:
app/src/main/java/com/fazbear/control/MainActivity.java
with the included updated MainActivity.java, then Sync/Build/Run as usual.

Build note: this source was not compiled in this environment. Build it in Android Studio and share any new error text if one appears.
