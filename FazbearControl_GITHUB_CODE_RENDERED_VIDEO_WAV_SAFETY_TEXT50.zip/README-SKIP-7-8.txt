Animation 7 and 8 are optional in scheduled shows.
If their WAV assignment is empty or undetectable, the show skips them.
The app checks again at every animation transition, so assigning/uploading
a WAV makes the slot playable without changing the code or restarting the app.
