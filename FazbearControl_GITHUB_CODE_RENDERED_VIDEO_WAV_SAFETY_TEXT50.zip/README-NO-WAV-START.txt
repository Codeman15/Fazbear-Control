FAZBEAR CONTROL — NO WAV AT SHOW START

If the scheduled show reaches showtime and no assigned animation WAV can be
detected:
- The show does not enter the running state.
- All audio/controllers/Bottango are stopped.
- The app displays "WAV ERROR" and "NO DETECTABLE WAV FILES" in the landscape
  countdown for about 3.5 seconds.
- The scheduled countdown immediately restarts using the original interval.
  Example: 11:00 -> 11:30 was a 30-minute countdown, so after the error the
  timer starts again from 30:00.
- The Idle A-pose is restored.
- If at least one assigned WAV exists, the show skips missing animations and
  starts at the first detectable WAV instead.
