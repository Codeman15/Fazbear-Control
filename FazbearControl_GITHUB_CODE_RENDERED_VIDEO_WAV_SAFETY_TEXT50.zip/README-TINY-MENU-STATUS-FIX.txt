TINY MENU STATUS FIX

The live diagnostic text has been added to portraitHome(), which is the Home screen layout shown on the phone.
It displays the online controller count, strongest recently reported controller Wi-Fi RSSI, Bottango state, and age of the most recent ESP32 status packet.

Open this project folder in Android Studio and run/build as usual. This source change has not been compiled in this environment.
