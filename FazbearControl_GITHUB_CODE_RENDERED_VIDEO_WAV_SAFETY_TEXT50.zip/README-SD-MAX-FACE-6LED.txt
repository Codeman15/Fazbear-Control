FAZBEAR CONTROL - SD MAX + FACE 6-LED PATCH

Based on the existing Duplicate Audio and Bottango Stop Fix project.

ANDROID AUDIO
- PHONE mode: existing local phone WAV playback only.
- MAX mode: no local phone WAV player; sends the assigned numbered WAV filename to Freddy.
- BOTH mode: keeps local phone playback and also sends the assigned numbered WAV filename to Freddy.
- Freddy command: [AUDIO FILE 0001.wav]
- Freddy maps that command to /audio/0001.wav on its SD card.
- Only filenames matching 0001.wav, 0002.wav, etc. are sent to Freddy.

FACE LIGHTING
- Bottango identifier: FACE
- Data GPIO: 14
- Addressable LED count: 6
- FACE color events apply the Bottango RGB value to all 6 FACE LEDs.

The existing Phone audio and Bottango stop/duplicate-audio fixes are preserved.
