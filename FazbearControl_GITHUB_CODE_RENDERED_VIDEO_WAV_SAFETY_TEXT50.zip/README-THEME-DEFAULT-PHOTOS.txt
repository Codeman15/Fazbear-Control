FAZBEAR CONTROL - THEME DEFAULT PHOTOS

This version includes built-in default artwork for all 11 themes:
0 Neon Purple
1 Cyan
2 Amber
3 Classic Fazbear Green
4 Alert Red
5 Ice Blue
6 Sunset Orange
7 Pink
8 Monochrome
9 Toxic Lime
10 Halloween - Haunted Fazbear

Each theme has default Freddy, Bonnie, Chica, Stage, and background artwork derived from the existing bundled artwork and styled for that theme.

CUSTOM PHOTOS:
- Existing per-theme photo picker still works.
- A selected custom photo overrides that theme's default photo.
- Custom photos are stored independently per theme and persist across restarts.
- Theme Customization > More Options > RESET PHOTOS TO THEME DEFAULTS restores the current theme's built-in Freddy, Bonnie, Chica, Stage, and background artwork.

The Open 24 Display ST font and the existing scheduling/Bottango/audio work from the current project are retained.

Build note: local Gradle compilation could not be completed in this environment because the Gradle 9.3.0 distribution was not cached and network access to services.gradle.org was unavailable. The source/resources were patched and packaged for GitHub Actions build.
