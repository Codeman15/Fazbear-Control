# Fazbear Control Android App

This project builds a native Android APK for the Fazbear Control system.

## Updated UI

The phone app mirrors the ESP32 480x320 FNAF security-terminal touchscreen layout:

- Freddy / Bonnie / Chica / Stage controller pages
- Matching character artwork
- Matching header, status panel, footer and navigation
- Advanced screen
- Looks screen
- Debug screen
- Wireless serial monitor
- 8 Bottango animation slots
- Play All / Pause / Stop / Restart
- Autoplay next animation
- Reset and controller status commands

The phone **does not include a volume controller**. Audio volume remains controlled by the ESP32/audio hardware.

## Network

Controller UDP port: `4210`

Phone wireless debug/serial receive port: `4211`

Default controller IPs:

- Freddy: `10.0.0.28`
- Bonnie: `10.0.0.102`
- Chica: `10.0.0.103`
- Stage: `10.0.0.104`

## GitHub Actions

The repository workflow extracts this project ZIP, builds a debug APK with Java 17 and Gradle 8.7, and uploads `app-debug.apk` as the `Fazbear-Control-debug-apk` artifact.


## ESP32 Wi-Fi signal indicators

The app reads actual ESP32 RSSI from the separate UDP packet `CTOUCH,WIFI,<ID>,<RSSI>` on port 4211. The ESP32 firmware must send this packet. Controllers without a recent RSSI report show gray/unknown bars; the app does not invent signal strength for controllers that have not been built or configured. The phone Wi-Fi bars are measured separately from the phone's Wi-Fi connection.
