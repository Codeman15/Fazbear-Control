FAZBEAR CONTROL - COMPREHENSIVE PLAYBACK FIX PASS

Fixed in this build:
- Bottango PAUSE is no longer treated as an animation-completion event.
- Bottango RESUME starts/resumes the matching phone WAV when phone/BOTH output is selected.
- A pause that happens while a WAV is still preparing is remembered, so the WAV does not start unexpectedly.
- Bottango STOP/seek-back can invalidate the current phone WAV instead of leaving stale audio running.
- Bottango polling responses are invalidated after scheduled-show shutdown, preventing stale HTTP responses from changing playback state.
- Bottango PUT command timeout reduced to avoid long network stalls.
- Scheduled-show intermission fade now runs from 30 seconds before showtime to 10 seconds before showtime, leaving the final 10-second warning silent.
- Actual Bottango animation completion uses reported playback time/duration for auto-next; a normal pause does not advance the show.
- Phone WAV completion remains available as the completion source when no ESP32 completion is available.

Build note:
The included source was checked for balanced Java syntax. A full Gradle build could not be run in this environment because the Gradle 8.7 distribution host was unreachable.
