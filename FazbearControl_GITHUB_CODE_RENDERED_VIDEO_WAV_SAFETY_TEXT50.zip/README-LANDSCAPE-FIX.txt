Landscape Show Timer fix

Fixed the landscape drawing transform so the portrait 360x800 canvas is not applied before the wide 1000x462 timer canvas. This removes the large black area on the left and keeps the uploaded 1536x709 Show Timer artwork centered correctly.

Also uses Gradle 8.7 with Android Gradle Plugin 8.6.1.
