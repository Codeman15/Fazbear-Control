FAZBEAR CONTROL — SECURITY CONSOLE + SHOW SCHEDULE

What's changed:
- Added a SCHEDULE tab to the portrait navigation.
- Added a schedule screen with enable/pause, time picker, daily/weekdays/weekends repeat, and animation selection.
- Added Android AlarmManager scheduling, exact-alarm access prompt on Android 12+, and a fallback inexact alarm if exact access is not granted.
- Added boot/app-update rescheduling so an enabled schedule is restored after reboot/update.
- Scheduled trigger sends [START N] to all four configured controller IPs over the existing UDP command port 4210.
- The scheduled animation's assigned WAV is played on the phone when saved audio output mode is PHONE or BOTH. MAX ONLY continues to depend on the existing ESP32/Bottango audio setup; this app does not stream local WAV files to MAX hardware.
- Added a 6-item bottom navigation while retaining Home, Devices, Animations, Control, and Settings.

Important:
- Android exact alarm access may need to be enabled in system settings. Without it, the system uses an inexact idle-friendly alarm and can run late.
- The phone must be powered on, not force-stopped, and able to reach the ESP32 controllers over Wi-Fi. Android battery restrictions can still delay background work.
- Scheduled shows use the existing UDP [START N] command. Confirm that your current ESP32 firmware recognizes that command and that animation numbering matches the app.
- The source archive was updated, but a Gradle build could not be completed in this environment because services.gradle.org was unreachable. Build and test in Android Studio before relying on scheduled performances.
