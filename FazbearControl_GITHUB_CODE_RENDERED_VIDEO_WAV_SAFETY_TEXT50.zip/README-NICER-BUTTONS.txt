FAZBEAR CONTROL — PREMIUM THEME BUTTONS

All button visuals are still drawn by Java code. No button artwork is baked
into the background images.

Each theme now has:
- its own material/color palette
- theme-specific texture
- beveled shell and recessed face
- glass highlight
- inner accent border
- tiny hardware details
- stronger text readability
- subtle depth/shadow

Touch geometry is unchanged.
