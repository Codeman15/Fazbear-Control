FAZBEAR CONTROL - TIMER / THEME PATCH

This patch is code-based; no generated UI image is used.

1. Landscape Show Timer background
- Keeps the uploaded high-resolution stage artwork.
- Preserves the source aspect ratio (no stretching).
- Uses a small composition adjustment and lower HUD placement so more of Bonnie, Freddy, and Chica remain visible.

2. Show Timer customization
Open SETTINGS -> THEMES • IMAGES • EFFECTS -> SHOW TIMER CUSTOMIZATION.
- Size: Small / Medium / Large
- Color: Theme color / Gold / Cyan / Red / White
- Countdown effect: None / Pulse / Flash at 10 seconds / Neon glow / Shake
Selections are persisted in the app preferences.

3. Theme-based button appearance
Buttons are still drawn by Java code. The selected theme changes the button palette and adds a theme-specific texture pattern (retro stripes, worn metal lines, party/halloween diagonal texture, etc.). Button geometry/touch targets remain unchanged.

4. Photo aspect ratio
The shared Java image() helper now preserves aspect ratio for character/device photos instead of stretching bitmaps into arbitrary rectangles.

Build note:
The project was not APK-built in this environment because the Gradle wrapper could not download Gradle 8.7 due network DNS restrictions. The source and Gradle project were packaged and the ZIP was integrity-checked.
