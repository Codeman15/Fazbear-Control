ANIMATION WAV ASSIGNMENTS

In the ANIMATIONS tab, each animation card has NAME, IMG, and WAV buttons.
Tap WAV to assign a WAV file to that animation. The WAV assignment is saved
on the phone and remains associated with that animation across app restarts.

When you press the main Play / Start Show control, the selected animation's
assigned WAV starts automatically in PHONE or BOTH output mode. Starting a
new animation replaces the currently playing phone WAV.

Important audio routing note:
- PHONE: assigned WAV plays from the phone.
- BOTH: assigned WAV plays from the phone while the existing ESP32-to-phone
  audio receiver remains enabled. The assigned file is not sent to MAX98357.
- MAX ONLY: app does not play the assigned phone WAV. MAX playback continues
  to depend on audio already provided by Bottango/ESP32. Sending a phone WAV
  file to MAX98357 would require compatible firmware/audio streaming support.

The global Timeline WAV picker remains available as before.
