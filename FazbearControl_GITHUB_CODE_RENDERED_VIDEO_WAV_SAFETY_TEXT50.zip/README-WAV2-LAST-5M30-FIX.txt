FAZBEAR CONTROL — WAV 2 LAST 5:30 FIX

Countdown behavior is now:
- WAV 1 plays from countdown start until 5:30 remaining.
- WAV 1 loops automatically.
- WAV 1 fades out during the final 10 seconds before 5:30 (from 5:40 to 5:30 remaining).
- WAV 2 starts exactly when 5:30 remains.
- WAV 2 loops automatically for the final 5 minutes 30 seconds.
- WAV 2 fades out during the final 20 seconds before the show.
- If a countdown is shorter than 5:30, WAV 2 starts immediately.
- Foreground and background scheduled-show countdown paths use the same timing.

The rest of the working project behavior is unchanged.

Build note: this environment could not run Gradle because the Gradle 8.7 distribution was unavailable offline/network access was unavailable. The project ZIP itself was created from the working baseline and the Java source changes were applied.
