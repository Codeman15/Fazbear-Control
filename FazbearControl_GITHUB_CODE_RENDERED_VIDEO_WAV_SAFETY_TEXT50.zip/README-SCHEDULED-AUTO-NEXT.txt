Scheduled shows always auto-advance.
ANIM_DONE advances to the next detectable assigned WAV.
Missing WAV assignments are skipped.
If no remaining detectable WAV exists, the show ends and the original
countdown interval restarts.
Manual scheduled durations remain supported.
