package com.fazbear.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Locale;

/** Receives background show alarms and dispatches the existing ESP32 UDP start command. */
public final class ScheduledShowReceiver extends BroadcastReceiver {
    private static MediaPlayer scheduledPlayer;

    /** Stop audio started by this background receiver (called by the main app). */
    public static synchronized void stopPhoneAudio() {
        MediaPlayer player = scheduledPlayer;
        scheduledPlayer = null;
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) { }
            try { player.reset(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("schedule_enabled", false)) return;
        // AlarmManager is now only the wake-up mechanism. The foreground service
        // owns the complete countdown, intermission, fade, animation sequencing,
        // WAV validation, and repeat timing. This prevents two independent audio
        // players/state machines from fighting each other.
        if (MainActivity.isAppVisible()) return;
        int animation = intent != null
                ? intent.getIntExtra("animation", prefs.getInt("schedule_animation", 1))
                : prefs.getInt("schedule_animation", 1);
        long target = intent != null ? intent.getLongExtra("show_target_ms", 0L) : 0L;
        if (target <= 0L) target = System.currentTimeMillis();

        Intent service = new Intent(context, BackgroundScheduledShowService.class);
        service.putExtra("animation", animation);
        service.putExtra("show_target_ms", target);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception ignored) { }
    }

}
