package com.fazbear.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Restores the user's recurring schedule after device reboot or app update. */
public final class ScheduleBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        if (prefs.getBoolean("schedule_enabled", false)) {
            ScheduleAlarm.schedule(context, true, prefs.getInt("schedule_hour", 19),
                    prefs.getInt("schedule_minute", 0), prefs.getInt("schedule_days", 0),
                    prefs.getInt("schedule_animation", 1));
        }
    }
}
