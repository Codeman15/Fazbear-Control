FAZBEAR CONTROL — THEME / WAV FIX

1. Removed all bundled theme background photos. Portrait theme backgrounds are
   rendered in Java code; the separate high-quality show-timer artwork remains.

2. Button textures are now visibly different for each theme and are drawn in
   Java code. No generated replacement images are used.

3. Added duplicate WAV-start protection. If the same animation WAV is requested
   twice within 1.5 seconds, the second request is ignored. This prevents a
   scheduled-show/Bottango double callback from starting the same WAV twice.

4. Existing character photos, timer artwork, schedule, and audio features remain.
