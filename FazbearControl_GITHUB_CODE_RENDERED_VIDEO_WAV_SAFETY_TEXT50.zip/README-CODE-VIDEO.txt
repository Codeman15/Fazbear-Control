FAZBEAR CONTROL - CODE RENDERED SHOW INTRO/OUTRO

This build replaces the scheduled MP4 video decoder with a Canvas-rendered animation.

Source video analyzed:
- 3840x2160 H.264, 60 FPS
- ~57.3 seconds
- Black background title sequence

Code animation:
- Starts at 1 second remaining in a scheduled show.
- Stops countdown/intermission audio.
- Switches to landscape.
- Draws 0:01 -> 0:00, 9055 Eldorado ave Presents, A Game Inspired Performance,
  and Five Nights at Freddy's directly with Android Canvas.
- Uses a bundled MP3 soundtrack extracted from the uploaded video's audio track.
- No MP4 file, TextureView, Surface, or video decoder is used.
- After the intro completes, the scheduled show starts.
- The same code-rendered sequence is available as the built-in outro after the show.
- After the outro completes, the app returns to the normal scheduled countdown.

The local Gradle build could not be executed in this environment because Gradle 8.7
was not cached and services.gradle.org is unreachable. The project ZIP itself was
created and then checked with unzip -t.


UPDATE: NO-WAV SAFETY + 50% LARGER TEXT
- If a scheduled show starts with no detectable assigned animation WAV files, the show is ended and the original repeat countdown is restarted.
- If all detectable animation WAV files disappear or become unreadable while a scheduled show is already running, the show is ended immediately and the repeat countdown is restarted.
- The code-rendered black-screen title text is 50% larger than the previous version.
