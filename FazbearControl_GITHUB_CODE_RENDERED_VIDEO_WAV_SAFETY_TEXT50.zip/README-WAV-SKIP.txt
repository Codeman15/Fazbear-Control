FAZBEAR CONTROL — WAV ASSIGNMENT SKIP

- When a show reaches an animation, the assigned WAV is checked.
- If that WAV is missing/unreadable, the app skips forward to the next animation
  with a detectable assigned WAV.
- The selected animation/controller command is updated to the skipped-to animation.
- If no assigned WAV is detectable anywhere in the 8 animation slots, a running
  scheduled/manual show is ended, audio/controllers are stopped, and the normal
  scheduled-show completion path resets the countdown to the next scheduled run.
- The existing duplicate WAV-start protection remains enabled.
