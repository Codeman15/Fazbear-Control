INTERMISSION LOOP + COUNTDOWN FADE

Updated MainActivity.java so scheduled-show intermission music:
- loops continuously until showtime (including a single-track playlist);
- remains playing through the final 10-second countdown;
- fades smoothly from full volume to silence over the final 30 seconds;
- stops exactly when the countdown reaches 0, immediately before the show starts;
- keeps the existing stop/exit behavior so no stale MediaPlayer callback can restart it.

The existing SD MAX / BOTH / FACE 6-LED changes in this project are preserved.
