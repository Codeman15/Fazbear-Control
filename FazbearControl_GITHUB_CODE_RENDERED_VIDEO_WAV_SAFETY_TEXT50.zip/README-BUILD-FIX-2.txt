BUILD FIX 2

Fixed the Java compile error caused by the invalid 32-bit color literal:
    0x337FFFFFFF

It has been replaced with the valid ARGB literal:
    0x337FFFFF

This removes the javac "integer number too large" error.
