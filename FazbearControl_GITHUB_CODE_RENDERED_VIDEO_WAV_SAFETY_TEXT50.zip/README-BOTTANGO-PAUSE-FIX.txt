BOTTANGO PAUSE FIX

The Bottango playback poll now mirrors an observed isPlaying=false immediately instead of requiring a detected playing->paused transition. This prevents a pause from being missed when the REST endpoint briefly reports the previous state. Playback-time backward jumps still use stop/reset behavior, while ordinary pause keeps the phone WAV paused.
