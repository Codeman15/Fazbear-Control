Background scheduled show cleanup

- AlarmManager is now only a wake-up trigger 45 minutes before the configured show time.
- ScheduledShowReceiver no longer owns MediaPlayer or starts individual animations.
- BackgroundScheduledShowService owns the complete closed-app state machine:
  intermission playlist -> 30/20 second fade -> show start -> WAV validation/skip ->
  animation sequencing -> repeat interval reset.
- Animation 7/8 remain optional until a detectable WAV is assigned.
- Phone/MAX/Both modes no longer create a second background player when the app is visible.
- Background timing uses WAV duration when available, with saved manual duration as fallback.
- Exact alarm rescheduling still uses the configured daily/weekday/weekend schedule.
