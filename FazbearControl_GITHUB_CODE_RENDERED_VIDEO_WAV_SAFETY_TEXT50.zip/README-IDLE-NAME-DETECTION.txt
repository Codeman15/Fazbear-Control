FAZBEAR CONTROL — BOTTANGO IDLE NAME DETECTION

The scheduled-show Idle A-pose is now identified by the Bottango animation
name "idle", not by a fixed animation slot number.

Before/at scheduled countdown start the app queries Bottango's /Animations/
REST endpoint, confirms whether an animation named "idle" exists, and uses
selectedAnimationName="idle" when requesting the pose.

This means the Idle animation can move to a different Bottango index when the
project is exported/transferred without breaking the scheduled Idle behavior.

Schedule behavior:
- Idle A-pose starts with the scheduled countdown.
- Intermission music starts only when 45 minutes or less remain.
- If the schedule begins with 45 minutes or less remaining, music starts
  immediately.
- Music loops and fades during the final 30 seconds.
- At 0:00 music stops and the first show animation starts, ending Idle.
- When the scheduled show completes, the app requests Bottango animation
  "idle" again.
