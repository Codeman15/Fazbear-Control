FAZBEAR CONTROL — PHONE AUDIO RECEIVER PROTOTYPE

This update adds a PHONE AUDIO / MAX98357 selector to Settings and an experimental
raw-PCM UDP receiver on port 4212. MAX98357 remains the default. Selecting PHONE
starts Android AudioTrack playback and waits for a stream. Selecting MAX stops the
phone receiver.

IMPORTANT: This is only the Android-side prototype. The matching ESP32 Wi-Fi audio
sender and firmware output-switch command are NOT included in this update. Therefore,
selecting PHONE will show LISTENING ON UDP 4212, but no show audio will be heard until
the firmware sends compatible PCM packets.

Receiver protocol currently expected by WifiAudioReceiver.java:
- UDP port 4212
- 44,100 Hz
- signed 16-bit little-endian stereo PCM
- datagrams contain raw PCM only, without a packet header
- payload lengths should be multiples of 4 bytes

MAX98357 stays the default on app launch. The app does not send an unsupported audio
mode command to the ESP32. This project has not been built or hardware-tested here.

To use: open this folder in Android Studio and build the app. On the phone, open
Settings and select PHONE AUDIO to start the receiver. Pair your Bluetooth speaker
with Android as usual; Android routes media playback to the selected audio device.
