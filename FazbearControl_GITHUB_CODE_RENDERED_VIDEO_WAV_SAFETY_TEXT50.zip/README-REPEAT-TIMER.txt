FAZBEAR CONTROL — ORIGINAL SCHEDULE INTERVAL REPEAT

Scheduled-show countdown behavior:
- When a scheduled show is started, the app captures the countdown interval.
- Example: current time 11:00, scheduled show time 11:30 -> interval = 30 minutes.
- When the show finishes, the next countdown starts at 30:00 again.
- It no longer waits until the next calendar occurrence, which could otherwise
  make the timer jump to almost 24 hours.
- The same original interval is also used when a scheduled show ends because
  no detectable assigned WAV files remain.
- If no valid interval was captured, the existing scheduled-time calculation
  is used as a fallback.
