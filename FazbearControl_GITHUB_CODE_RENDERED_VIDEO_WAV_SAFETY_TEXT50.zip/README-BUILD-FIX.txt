BUILD FIX

Fixed MainActivity.java: FazbearView is an inner view class, so the WAV
detection helper now calls appContext.getContentResolver() instead of
getContentResolver() directly.

This fixes the javac error:
  cannot find symbol: method getContentResolver()
