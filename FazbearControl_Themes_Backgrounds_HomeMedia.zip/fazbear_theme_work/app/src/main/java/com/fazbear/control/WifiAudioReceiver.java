package com.fazbear.control;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Process;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Experimental raw-PCM UDP receiver for Fazbear Control.
 * Protocol: UDP port 4212, 44,100 Hz, signed 16-bit little-endian, stereo PCM.
 * Each datagram contains only PCM bytes (no header); payload length must be even
 * and ideally a multiple of 4 bytes (one stereo sample frame).
 */
public final class WifiAudioReceiver implements AutoCloseable {
    public static final int DEFAULT_PORT = 4212;
    public static final int SAMPLE_RATE = 44100;
    private static final int CHANNEL_MASK = AudioFormat.CHANNEL_OUT_STEREO;
    private static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;
    private static final int MAX_PACKET_BYTES = 4096;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private DatagramSocket socket;
    private AudioTrack track;
    private Thread worker;

    public synchronized void start() throws IOException {
        if (running.get()) return;
        int minBuffer = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_MASK, ENCODING);
        if (minBuffer <= 0) throw new IOException("AudioTrack does not support the requested PCM format (" + minBuffer + ")");

        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        AudioFormat format = new AudioFormat.Builder()
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(CHANNEL_MASK)
                .setEncoding(ENCODING)
                .build();
        track = new AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(Math.max(minBuffer * 2, 16384))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        if (track.getState() != AudioTrack.STATE_INITIALIZED) {
            track.release();
            track = null;
            throw new IOException("Could not initialize Android audio output");
        }

        socket = new DatagramSocket(null);
        socket.setReuseAddress(true);
        socket.bind(new InetSocketAddress(DEFAULT_PORT));
        socket.setSoTimeout(1000);
        running.set(true);
        track.play();
        worker = new Thread(this::receiveLoop, "Fazbear-WiFi-Audio");
        worker.setPriority(Process.THREAD_PRIORITY_AUDIO);
        worker.start();
    }

    private void receiveLoop() {
        byte[] buffer = new byte[MAX_PACKET_BYTES];
        while (running.get()) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            try {
                socket.receive(packet);
                int length = packet.getLength();
                // PCM16 stereo frames are 4 bytes. Ignore malformed/truncated payloads.
                length -= length % 4;
                if (length > 0 && track != null && track.getState() == AudioTrack.STATE_INITIALIZED) {
                    track.write(packet.getData(), packet.getOffset(), length, AudioTrack.WRITE_BLOCKING);
                }
            } catch (java.net.SocketTimeoutException ignored) {
                // Allows the loop to notice stop requests.
            } catch (SocketException e) {
                if (running.get()) stopQuietly();
            } catch (IOException ignored) {
                // A transient packet/network error should not crash the app.
            } catch (IllegalStateException ignored) {
                if (running.get()) stopQuietly();
            }
        }
    }

    public boolean isRunning() { return running.get(); }

    @Override public synchronized void close() { stopQuietly(); }

    private synchronized void stopQuietly() {
        running.set(false);
        if (socket != null) {
            socket.close();
            socket = null;
        }
        if (track != null) {
            try { track.pause(); } catch (IllegalStateException ignored) {}
            try { track.flush(); } catch (IllegalStateException ignored) {}
            track.release();
            track = null;
        }
        if (worker != null && worker != Thread.currentThread()) {
            worker.interrupt();
            try { worker.join(300); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            worker = null;
        }
    }
}
