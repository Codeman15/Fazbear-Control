package com.fazbear.control;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.*;
import android.view.*;
import android.content.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    FazbearView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        view = new FazbearView(this);
        setContentView(view);
    }

    @Override protected void onDestroy() {
        if (view != null) view.shutdown();
        super.onDestroy();
    }
}

class FazbearView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService net = Executors.newCachedThreadPool();
    final DatagramSocket rxSocket;
    final SharedPreferences prefs;

    final String[] names = {"FREDDY", "BONNIE", "CHICA", "STAGE"};
    final String[] defaultIPs = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
    final String[] ips = new String[4];
    final String[] animNames = {"Idle", "Welcome Show", "Song 1", "Song 2", "Wave", "Point", "Laugh", "Custom"};
    final Bitmap[] chars = new Bitmap[4];
    Movie homeGif;
    long homeGifStart = 0;

    static final int HOME = 0, DEVICES = 1, TIMELINE = 2, CONTROL = 3, SETTINGS = 4, DEBUG = 5, DEVICE_DETAIL = 6;

    int screen = HOME;
    int page = 0;
    int selectedAnimation = 1;
    boolean autoplay = false;
    boolean loop = false;
    boolean[] online = new boolean[4];
    long[] lastSeen = new long[4];
    String[] playing = {"Idle", "Idle", "Idle", "Stage Lights"};
    int[] progress = {0, 0, 0, 0};
    int syncedVolume = -1;
    ArrayList<String> log = new ArrayList<>();
    String status = "SYSTEM READY";
    String errorTitle = "";
    String errorMessage = "";
    String errorDetails = "";
    boolean errorPopup = false;
    int theme = 0;

    FazbearView(Context c) {
        super(c);
        setFocusable(true);
        prefs = c.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        for (int i = 0; i < 4; i++) ips[i] = prefs.getString("ip" + i, defaultIPs[i]);
        theme = prefs.getInt("theme", 0);
        bluetoothAudio = prefs.getBoolean("bluetoothAudio", false);

        chars[0] = load(c, "freddy");
        chars[1] = load(c, "bonnie");
        chars[2] = load(c, "chica");
        chars[3] = load(c, "stage");
        homeGif = loadGif(c, "home");
        homeGifStart = System.currentTimeMillis();

        DatagramSocket s = null;
        try {
            s = new DatagramSocket(4211);
            s.setBroadcast(true);
            addLog("UDP RX READY  //  PORT 4211");
        } catch (Exception e) {
            addLog("UDP RX ERROR: " + e.getMessage());
            showError("NETWORK ERROR", "Unable to open UDP 4211", String.valueOf(e.getMessage()));
        }
        rxSocket = s;
        if (rxSocket != null) startReceiver();
        addLog("FAZBEAR CONTROL ONLINE");

        main.postDelayed(() -> {
            for (int i = 0; i < 4; i++) {
                if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
            }
            invalidate();
            main.postDelayed(this::tick, 1000);
        }, 1000);
    }

    void tick() {
        for (int i = 0; i < 4; i++) {
            if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
        }
        invalidate();
        main.postDelayed(this::tick, 1000);
    }

    Bitmap load(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(getResources(), id);
    }

    Movie loadGif(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        if (id == 0) return null;
        try {
            return Movie.decodeStream(c.getResources().openRawResource(id));
        } catch (Exception e) {
            addLog("HOME GIF ERROR: " + e.getMessage());
            return null;
        }
    }

    void startReceiver() {
        net.execute(() -> {
            byte[] buf = new byte[2048];
            while (rxSocket != null && !rxSocket.isClosed()) {
                try {
                    DatagramPacket d = new DatagramPacket(buf, buf.length);
                    rxSocket.receive(d);
                    String msg = new String(d.getData(), d.getOffset(), d.getLength()).trim();
                    final String host = d.getAddress().getHostAddress();
                    main.post(() -> handlePacket(host, msg));
                } catch (Exception ignored) {}
            }
        });
    }

    void handlePacket(String host, String msg) {
        int idx = indexForHost(host);
        if (idx >= 0) {
            online[idx] = true;
            lastSeen[idx] = System.currentTimeMillis();
        }
        addLog(host + " > " + msg);

        int v = parseVolume(msg);
        if (v >= 0) {
            syncedVolume = v;
            status = "VOLUME " + v + "%  //  ESP32 POT";
        }

        if (msg.toUpperCase(Locale.US).contains("ANIM_DONE")) {
            if (idx >= 0) {
                progress[idx] = 100;
                if (autoplay) {
                    int next = selectedAnimation >= 8 ? 1 : selectedAnimation + 1;
                    selectedAnimation = next;
                    playing[idx] = animNames[next - 1];
                    send(idx, "[START " + next + "]");
                }
            }
        }
        invalidate();
    }

    int indexForHost(String host) {
        for (int i = 0; i < 4; i++) if (ips[i].equals(host)) return i;
        return -1;
    }

    int parseVolume(String msg) {
        String u = msg.toUpperCase(Locale.US);
        int i = u.indexOf("VOLUME");
        if (i < 0) return -1;
        i += 6;
        while (i < u.length() && !Character.isDigit(u.charAt(i))) i++;
        if (i >= u.length()) return -1;
        int start = i;
        while (i < u.length() && Character.isDigit(u.charAt(i))) i++;
        try { return Math.max(0, Math.min(100, Integer.parseInt(u.substring(start, i)))); }
        catch (Exception e) { return -1; }
    }

    void addLog(String s) {
        log.add(timeStamp() + "  " + s);
        while (log.size() > 160) log.remove(0);
        invalidate();
    }

    String timeStamp() {
        long n = System.currentTimeMillis() / 1000;
        return String.format(Locale.US, "%02d:%02d:%02d", (n / 3600) % 24, (n / 60) % 60, n % 60);
    }

    void send(int which, String cmd) {
        if (which < 0 || which > 3) return;
        final String ip = ips[which];
        addLog(ip + " < " + cmd);
        net.execute(() -> {
            try {
                byte[] data = cmd.getBytes("UTF-8");
                DatagramPacket dp = new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210);
                DatagramSocket s = new DatagramSocket();
                s.setBroadcast(true);
                s.send(dp);
                s.close();
                main.post(() -> {
                    online[which] = true;
                    lastSeen[which] = System.currentTimeMillis();
                    invalidate();
                });
            } catch (Exception e) {
                main.post(() -> {
                    addLog("SEND ERROR " + ip + ": " + e.getMessage());
                    showError("COMMAND FAILED", "Could not reach ESP32 " + names[which],
                            "Target: " + ip + "\nUDP command port: 4210\n" + e.getMessage());
                });
            }
        });
    }

    void broadcast(String cmd) { for (int i = 0; i < 4; i++) send(i, cmd); }

    void play(int i, int anim) {
        selectedAnimation = anim;
        playing[i] = animNames[anim - 1];
        progress[i] = 0;
        send(i, "[START " + anim + "]");
        status = names[i] + "  //  PLAYING " + animNames[anim - 1];
    }

    void playAll() {
        for (int i = 0; i < 4; i++) {
            if (i == 3) playing[i] = "Stage Lights";
            else playing[i] = animNames[selectedAnimation - 1];
            progress[i] = 0;
        }
        broadcast("[START " + selectedAnimation + "]");
        status = "PLAY ALL  //  " + animNames[selectedAnimation - 1];
    }

    void showError(String title, String message, String details) {
        errorTitle = title;
        errorMessage = message;
        errorDetails = details == null ? "" : details;
        errorPopup = true;
        invalidate();
    }

    void retryError() {
        errorPopup = false;
        send(page, "[STATUS]");
        status = "STATUS REQUEST SENT";
        invalidate();
    }

    void shutdown() {
        try { if (rxSocket != null) rxSocket.close(); } catch (Exception ignored) {}
        net.shutdownNow();
    }


    boolean bluetoothAudio = false;

    int accent() { return theme == 1 ? Color.CYAN : (theme == 2 ? Color.YELLOW : 0xFFB000FF); }
    int red() { return 0xFFFF1744; }
    int panel() { return 0xFF090B14; }
    int panel2() { return 0xFF111525; }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(size); p.setColor(color); p.setTextAlign(a); p.setStyle(Paint.Style.FILL);
        c.drawText(s, x, y, p);
    }

    void rect(Canvas c, float l, float t, float r, float b, int color, boolean stroke) {
        p.setColor(color); p.setStyle(stroke ? Paint.Style.STROKE : Paint.Style.FILL);
        p.setStrokeWidth(stroke ? 1.5f : 1); c.drawRect(l,t,r,b,p); p.setStyle(Paint.Style.FILL);
    }

    void button(Canvas c, int x, int y, int w, int h, String label, int color) {
        p.setColor(panel2()); c.drawRoundRect(x,y,x+w,y+h,9,9,p);
        rect(c,x,y,x+w,y+h,color,true);
        text(c,label,x+w/2f,y+h/2f+4,8,Color.WHITE,Paint.Align.CENTER);
    }

    void background(Canvas c) {
        c.drawColor(Color.BLACK);
        for (int y=0;y<720;y+=24) {
            p.setColor((y/24)%2==0 ? 0xFF070711 : 0xFF0A0810);
            c.drawRect(0,y,360,y+24,p);
        }
        rect(c,2,2,358,718,accent(),true);
    }

    void title(Canvas c, String s, String sub) {
        // Portrait header: keep the app name, screen title, IP/status, and POT
        // readout in separate areas so they never overlap on narrow screens.
        text(c,"FAZBEAR CONTROL",12,22,9,Color.WHITE,Paint.Align.LEFT);
        text(c,s,12,43,14,accent(),Paint.Align.LEFT);
        if(sub!=null) text(c,sub,180,57,6,Color.LTGRAY,Paint.Align.CENTER);
        text(c,syncedVolume>=0 ? syncedVolume+"%" : "--%",348,22,7,Color.WHITE,Paint.Align.RIGHT);
        text(c,"POT",348,34,5,Color.LTGRAY,Paint.Align.RIGHT);
        rect(c,10,62,350,63,accent(),false);
    }

    void nav(Canvas c, int selected) {
        rect(c,4,610,356,700,0xFF05060B,false);
        String[] n={"HOME","DEVICES","TIMELINE","CONTROL","SETTINGS","DEBUG"};
        for(int i=0;i<6;i++){
            int col=i%3, row=i/3, x=col*120, y=612+row*42;
            int color=i==selected?accent():Color.LTGRAY;
            text(c,navIcon(i),x+60,y+14,10,color,Paint.Align.CENTER);
            text(c,n[i],x+60,y+30,6,color,Paint.Align.CENTER);
        }
    }

    String navIcon(int i) { return new String[]{"⌂","▣","≋","▶","⚙","!"}[i]; }

    @Override protected void onDraw(Canvas real) {
        float scale=Math.min(getWidth()/360f,getHeight()/720f);
        float drawW=360f*scale, drawH=720f*scale;
        float ox=(getWidth()-drawW)/2f, oy=(getHeight()-drawH)/2f;
        real.drawColor(Color.BLACK);
        real.save();
        real.translate(ox,oy); real.scale(scale,scale);
        Canvas c=real;
        background(c);
        switch(screen){
            case HOME: drawHome(c); break;
            case DEVICES: drawDevices(c); break;
            case TIMELINE: drawTimeline(c); break;
            case CONTROL: drawControl(c); break;
            case SETTINGS: drawSettings(c); break;
            case DEBUG: drawDebug(c); break;
            case DEVICE_DETAIL: drawDeviceDetail(c); break;
        }
        if(screen!=DEVICE_DETAIL) nav(c,screen);
        if(errorPopup) drawErrorPopup(c);
        real.restore();
    }

    void image(Canvas c, Bitmap b, RectF dst) {
        if(b==null) return;
        Rect src=new Rect(0,0,b.getWidth(),b.getHeight());
        c.drawBitmap(b,src,dst,p);
    }

    void drawHome(Canvas c) {
        title(c,"HOME","WIRELESS SHOW CONTROL");
        drawHomeGif(c,new RectF(35,68,325,235));
        text(c,"FAZBEAR CONTROL",180,260,18,Color.WHITE,Paint.Align.CENTER);
        text(c,"4 ESP32 CONTROLLERS",180,280,7,Color.LTGRAY,Paint.Align.CENTER);
        int on=0; for(boolean b:online) if(b) on++;
        text(c,on+" / 4 ONLINE",180,301,12,on==4?Color.GREEN:Color.YELLOW,Paint.Align.CENTER);
        button(c,25,320,150,42,"START SHOW",accent());
        button(c,185,320,150,42,"DEBUG",Color.DKGRAY);
        button(c,20,385,150,48,"DEVICES",accent());
        button(c,190,385,150,48,"TIMELINE",accent());
        button(c,20,445,150,48,"CONTROL",accent());
        button(c,190,445,150,48,"SETTINGS",accent());
        text(c,bluetoothAudio?"AUDIO: BLUETOOTH":"AUDIO: MAX98357",180,525,8,Color.WHITE,Paint.Align.CENTER);
        text(c,"PHYSICAL ESP32 POTENTIOMETER = VOLUME SOURCE",180,543,6,Color.LTGRAY,Paint.Align.CENTER);
        text(c,status,180,575,6,Color.WHITE,Paint.Align.CENTER);
    }

    void drawHomeGif(Canvas c, RectF dst) {
        if (homeGif == null) {
            image(c, chars[0], dst);
            return;
        }
        int duration = homeGif.duration();
        if (duration <= 0) duration = 1000;
        int rel = (int)((System.currentTimeMillis() - homeGifStart) % duration);
        homeGif.setTime(rel);
        float sx = dst.width() / homeGif.width();
        float sy = dst.height() / homeGif.height();
        c.save();
        c.translate(dst.left, dst.top);
        c.scale(sx, sy);
        homeGif.draw(c, 0, 0);
        c.restore();
        main.postDelayed(this::invalidate, 50);
    }

    void deviceCard(Canvas c,int i,int y){
        int a=i==page?accent():0xFF263044;
        rect(c,10,y,350,y+105,panel2(),false);
        rect(c,10,y,350,y+105,a,true);
        image(c,chars[i],new RectF(18,y+8,92,y+95));
        text(c,"ESP32 - "+names[i],103,y+22,9,Color.WHITE,Paint.Align.LEFT);
        text(c,ips[i],103,y+38,6,Color.LTGRAY,Paint.Align.LEFT);
        text(c,online[i]?"● ONLINE":"● OFFLINE",103,y+54,7,online[i]?Color.GREEN:red(),Paint.Align.LEFT);
        text(c,"Playing: "+playing[i],103,y+72,7,Color.WHITE,Paint.Align.LEFT);
        text(c,"ANIM "+String.format(Locale.US,"%02d",i==3?5:selectedAnimation),103,y+88,6,accent(),Paint.Align.LEFT);
        button(c,270,y+65,70,30,"PLAY",Color.GREEN);
    }

    void drawDevices(Canvas c){
        title(c,"DEVICES","4 ESP32 CONTROLLERS");
        for(int i=0;i<4;i++) deviceCard(c,i,65+i*137);
        text(c,"TAP A DEVICE FOR ANIMATIONS + PLAYBACK",180,620,6,Color.LTGRAY,Paint.Align.CENTER);
    }

    void drawDeviceDetail(Canvas c){
        title(c,"ESP32 - "+names[page],ips[page]);
        button(c,12,65,70,32,"BACK",accent());
        image(c,chars[page],new RectF(100,65,260,165));
        text(c,online[page]?"● ONLINE":"● OFFLINE",180,185,8,online[page]?Color.GREEN:red(),Paint.Align.CENTER);
        text(c,"NOW PLAYING: "+playing[page],180,201,8,Color.WHITE,Paint.Align.CENTER);
        text(c,"VOLUME "+(syncedVolume>=0?syncedVolume+"%":"--%")+" • ESP32 POT",180,216,6,Color.LTGRAY,Paint.Align.CENTER);
        text(c,"ANIMATIONS",15,242,8,accent(),Paint.Align.LEFT);
        for(int i=1;i<=8;i++){
            int col=(i-1)%2,row=(i-1)/2,x=15+col*170,y=250+row*43;
            button(c,x,y,160,34,String.format(Locale.US,"%02d  %s",i,animNames[i-1]),i==selectedAnimation?accent():0xFF303444);
        }
        button(c,12,435,78,34,"PLAY",Color.GREEN);
        button(c,96,435,78,34,"PAUSE",Color.YELLOW);
        button(c,180,435,78,34,"STOP",red());
        button(c,264,435,84,34,"RESTART",accent());
        button(c,110,485,140,32,autoplay?"AUTO ON":"AUTO OFF",autoplay?Color.GREEN:Color.DKGRAY);
    }

    void drawTimeline(Canvas c){
        title(c,"TIMELINE","AUDIO PLAYBACK");
        text(c,"NOW PLAYING",15,75,7,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"Five Nights at Freddy's - Show",15,94,10,Color.WHITE,Paint.Align.LEFT);
        rect(c,15,108,345,190,panel2(),false);
        rect(c,15,108,345,190,accent(),true);
        p.setStrokeWidth(2);
        for(int x=20;x<340;x+=4){
            double wave=Math.sin(x*.12)*20+Math.sin(x*.31)*8+Math.sin(x*.61)*4;
            p.setColor(x%24<8?0xFFFF1744:accent());
            c.drawLine(x,149,x,(float)(149+wave),p);
        }
        rect(c,178,110,181,188,Color.WHITE,false);
        text(c,"1:24 / 3:45",180,207,8,Color.WHITE,Paint.Align.CENTER);
        button(c,15,225,70,36,"-5s",accent());
        button(c,95,225,70,36,"◀◀",accent());
        button(c,175,222,45,42,"Ⅱ",accent());
        button(c,230,225,70,36,"▶▶",accent());
        button(c,310,225,35,36,"+5s",accent());
        text(c,"CURRENT EVENT",15,300,7,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"Freddy Move",15,320,10,Color.WHITE,Paint.Align.LEFT);
        text(c,"00:45",110,320,7,accent(),Paint.Align.LEFT);
        text(c,"PHYSICAL VOLUME",15,350,7,Color.LTGRAY,Paint.Align.LEFT);
        text(c,syncedVolume>=0?syncedVolume+"%":"WAITING",15,370,12,Color.WHITE,Paint.Align.LEFT);
        text(c,bluetoothAudio?"OUTPUT: BLUETOOTH":"OUTPUT: MAX98357",180,370,7,accent(),Paint.Align.LEFT);
    }

    void drawControl(Canvas c){
        title(c,"SHOW CONTROL","MULTI-ESP32");
        text(c,"SELECTED ANIMATION",15,75,7,Color.LTGRAY,Paint.Align.LEFT);
        text(c,String.format(Locale.US,"%02d  %s",selectedAnimation,animNames[selectedAnimation-1]),15,96,13,Color.WHITE,Paint.Align.LEFT);
        button(c,15,115,160,44,"PLAY ALL",Color.GREEN);
        button(c,185,115,160,44,"PAUSE ALL",Color.YELLOW);
        button(c,15,170,160,44,"STOP ALL",red());
        button(c,185,170,160,44,"RESTART",accent());
        for(int i=0;i<4;i++){
            int x=15+(i%2)*170,y=235+(i/2)*60;
            rect(c,x,y,x+160,y+48,panel2(),false);
            text(c,names[i],x+10,y+18,8,Color.WHITE,Paint.Align.LEFT);
            text(c,online[i]?"ONLINE":"OFFLINE",x+10,y+34,6,online[i]?Color.GREEN:red(),Paint.Align.LEFT);
            text(c,playing[i],x+75,y+26,6,accent(),Paint.Align.LEFT);
        }
        button(c,15,370,155,34,loop?"LOOP ON":"LOOP OFF",loop?Color.GREEN:Color.DKGRAY);
        button(c,190,370,155,34,autoplay?"AUTO NEXT ON":"AUTO NEXT OFF",autoplay?Color.GREEN:Color.DKGRAY);
    }

    void drawSettings(Canvas c){
        title(c,"SETTINGS","APP + CONTROLLER STATUS");
        text(c,"AUDIO OUTPUT",15,72,8,accent(),Paint.Align.LEFT);
        button(c,15,82,160,38,bluetoothAudio?"MAX98357":"MAX98357",bluetoothAudio?Color.DKGRAY:Color.GREEN);
        button(c,185,82,160,38,"BLUETOOTH",bluetoothAudio?Color.CYAN:Color.DKGRAY);
        text(c,"Default: ESP32 amplifier / MAX98357 I2S",15,135,6,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"Selected output is saved on this phone.",15,149,6,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"CONTROLLER IP ADDRESSES",15,180,8,Color.WHITE,Paint.Align.LEFT);
        for(int i=0;i<4;i++){
            int y=190+i*48;
            text(c,names[i],15,y+17,7,Color.WHITE,Paint.Align.LEFT);
            rect(c,92,y,235,y+30,panel2(),false);
            text(c,ips[i],102,y+19,7,Color.WHITE,Paint.Align.LEFT);
            button(c,245,y,55,30,"TEST",accent());
            text(c,online[i]?"ON":"OFF",335,y+19,6,online[i]?Color.GREEN:red(),Paint.Align.RIGHT);
        }
        text(c,"VOLUME IS READ-ONLY • ESP32 PHYSICAL POT",15,400,7,Color.LTGRAY,Paint.Align.LEFT);
        text(c,syncedVolume>=0?syncedVolume+"% SYNCED":"WAITING",15,417,9,Color.WHITE,Paint.Align.LEFT);
        button(c,15,450,155,36,theme==0?"NEON PURPLE":"CYAN THEME",accent());
        button(c,185,450,75,36,"DEBUG",Color.DKGRAY);
        button(c,275,450,70,36,"CLEAR",red());
    }

    void drawDebug(Canvas c){
        title(c,"DEBUG","WIRELESS SERIAL + DIAGNOSTICS");
        int on=0; for(boolean b:online) if(b) on++;
        text(c,"UDP RX 4211",12,72,7,Color.LTGRAY,Paint.Align.LEFT);
        text(c,"UDP TX 4210",12,88,7,Color.LTGRAY,Paint.Align.LEFT);
        text(c,on+"/4 ONLINE",180,72,7,on==4?Color.GREEN:Color.YELLOW,Paint.Align.CENTER);
        text(c,"VOL "+(syncedVolume>=0?syncedVolume+"%":"WAITING"),348,72,7,Color.WHITE,Paint.Align.RIGHT);
        rect(c,10,105,350,590,panel2(),false);
        int start=Math.max(0,log.size()-27),y=122;
        for(int i=start;i<log.size();i++){
            String s=log.get(i);
            if(s.length()>48) s=s.substring(0,48);
            text(c,s,15,y,5.5f,Color.LTGRAY,Paint.Align.LEFT); y+=17;
        }
        button(c,12,605,90,30,"CLEAR",red());
        button(c,110,605,90,30,"STATUS",accent());
        button(c,208,605,110,30,"TEST ALL",Color.GREEN);
    }

    void drawErrorPopup(Canvas c){
        rect(c,0,0,360,720,0xCC000000,false);
        int l=20,t=205,r=340,b=505;
        rect(c,l,t,r,b,0xFF10050A,false);
        rect(c,l,t,r,b,red(),true);
        text(c,"⚠ SYSTEM ERROR",180,240,15,red(),Paint.Align.CENTER);
        text(c,errorTitle,180,270,10,Color.WHITE,Paint.Align.CENTER);
        text(c,errorMessage,180,300,8,Color.LTGRAY,Paint.Align.CENTER);
        text(c,"Details are available in DEBUG.",180,325,7,Color.LTGRAY,Paint.Align.CENTER);
        button(c,35,430,85,38,"RETRY",accent());
        button(c,137,430,85,38,"DETAILS",Color.WHITE);
        button(c,240,430,85,38,"CLOSE",red());
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float scale=Math.min(getWidth()/360f,getHeight()/720f);
        float drawW=360f*scale,drawH=720f*scale;
        float ox=(getWidth()-drawW)/2f,oy=(getHeight()-drawH)/2f;
        float x=(e.getX()-ox)/scale,y=(e.getY()-oy)/scale;
        if(x<0||x>360||y<0||y>720) return true;

        if(errorPopup){
            if(y>=420&&y<=480){
                if(x<130) retryError();
                else if(x<235){errorPopup=false;screen=DEBUG;invalidate();}
                else {errorPopup=false;invalidate();}
            }
            return true;
        }

        if(screen==DEVICE_DETAIL){
            return touchDeviceDetail(x,y);
        }

        if(y>=608){
            int col=(int)(x/120),row=(int)((y-608)/46);
            int n=row*3+col;
            if(n>=0&&n<6){screen=n;invalidate();return true;}
        }

        if(screen==HOME){
            if(y>=315&&y<370&&x<180){playAll();invalidate();return true;}
            if(y>=315&&y<370&&x>=180){screen=DEBUG;invalidate();return true;}
            if(y>=380&&y<440){screen=x<180?DEVICES:TIMELINE;invalidate();return true;}
            if(y>=440&&y<510){screen=x<180?CONTROL:SETTINGS;invalidate();return true;}
        }else if(screen==DEVICES){
            if(y>=65&&y<613){int i=(int)((y-65)/137);if(i>=0&&i<4){page=i;screen=DEVICE_DETAIL;invalidate();return true;}}
        }else if(screen==TIMELINE){
            if(y>=220&&y<270){
                if(x<85){status="SEEK -5s";}
                else if(x<175){broadcast("[PAUSE]");status="PAUSED";}
                else if(x<225){broadcast("[PAUSE]");status="PLAY/PAUSE";}
                else if(x<305){status="SEEK +5s";}
                invalidate();return true;
            }
        }else if(screen==CONTROL){
            if(y>=110&&y<225){
                if(y<165){if(x<180)playAll();else{broadcast("[PAUSE]");status="PAUSE ALL";}}
                else {if(x<180){broadcast("[STOP]");status="STOP ALL";}else{broadcast("[RESTART]");status="RESTART ALL";}}
                invalidate();return true;
            }
            if(y>=365&&y<420){if(x<180)loop=!loop;else autoplay=!autoplay;invalidate();return true;}
        }else if(screen==SETTINGS){
            if(y>=80&&y<130){
                if(x<180){bluetoothAudio=false;prefs.edit().putBoolean("bluetoothAudio",false).apply();broadcast("[AUDIO_OUTPUT MAX98357]");status="AUDIO OUTPUT: MAX98357";invalidate();return true;}
                else {bluetoothAudio=true;prefs.edit().putBoolean("bluetoothAudio",true).apply();broadcast("[AUDIO_OUTPUT BLUETOOTH]");status="AUDIO OUTPUT: BLUETOOTH";invalidate();return true;}
            }
            for(int i=0;i<4;i++){int yy=190+i*48;if(y>=yy&&y<=yy+30&&x>=245&&x<=310){send(i,"[STATUS]");status="STATUS TEST "+names[i];invalidate();return true;}}
            if(y>=445&&y<495){
                if(x<175){theme=(theme+1)%3;prefs.edit().putInt("theme",theme).apply();}
                else if(x<270)screen=DEBUG;
                else {log.clear();}
                invalidate();return true;
            }
        }else if(screen==DEBUG){
            if(y>=595){if(x<105)log.clear();else if(x<205)send(page,"[STATUS]");else if(x<325)for(int i=0;i<4;i++)send(i,"[STATUS]");invalidate();return true;}
        }
        return true;
    }

    boolean touchDeviceDetail(float x,float y){
        if(y>=60&&y<105&&x<90){screen=DEVICES;invalidate();return true;}
        if(y>=245&&y<420){
            int col=(int)(x/180),row=(int)((y-250)/43);
            if(col>=0&&col<2&&row>=0&&row<4){
                int a=row*2+col+1;
                selectedAnimation=a;play(page,a);invalidate();return true;
            }
        }
        if(y>=430&&y<480){
            if(x<90)play(page,selectedAnimation);
            else if(x<180)send(page,"[PAUSE]");
            else if(x<265)send(page,"[STOP]");
            else send(page,"[RESTART]");
            invalidate();return true;
        }
        if(y>=480&&y<530&&x>=100&&x<=260){autoplay=!autoplay;invalidate();return true;}
        return true;
    }
}
