package com.fazbear.control;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;

/** Full-screen scheduled-show MP4 player. Uses MediaPlayer directly so Android can
 * open persisted content:// document URIs reliably. Audio comes exclusively from the MP4. */
public class VideoActivity extends Activity implements SurfaceHolder.Callback {
    private static volatile VideoActivity current;
    private SurfaceView surfaceView;
    private SurfaceHolder holder;
    private MediaPlayer player;
    private Uri videoUri;
    private int kind;
    private boolean completed;
    private boolean prepared;
    private boolean surfaceReady;

    public static void stopCurrent() {
        VideoActivity v = current;
        if (v != null) v.finishWithoutCallback();
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        current = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); } catch (Exception ignored) { }

        surfaceView = new SurfaceView(this);
        surfaceView.setBackgroundColor(Color.BLACK);
        holder = surfaceView.getHolder();
        holder.addCallback(this);
        setContentView(surfaceView);

        String uriString = getIntent().getStringExtra("VIDEO_URI");
        kind = getIntent().getIntExtra("VIDEO_KIND", 0);
        if (uriString == null || uriString.isEmpty()) {
            fail("MP4 URI EMPTY");
            return;
        }
        videoUri = Uri.parse(uriString);
        preparePlayer();
    }

    private void preparePlayer() {
        try {
            player = new MediaPlayer();
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setScreenOnWhilePlaying(true);
            player.setOnPreparedListener(mp -> {
                prepared = true;
                mp.setVolume(1f, 1f);
                if (surfaceReady && holder != null) {
                    try { mp.setDisplay(holder); } catch (Exception ignored) { }
                }
                try { mp.start(); }
                catch (Exception e) { fail("MP4 START FAILED: " + e.getMessage()); }
            });
            player.setOnCompletionListener(mp -> complete());
            player.setOnErrorListener((mp, what, extra) -> {
                fail("MP4 PLAYBACK ERROR " + what + "/" + extra);
                return true;
            });
            // Direct Context+Uri access is important for Storage Access Framework
            // document URIs and persisted permissions.
            player.setDataSource(this, videoUri);
            player.prepareAsync();
        } catch (Exception e) {
            fail("MP4 OPEN FAILED: " + e.getMessage());
        }
    }

    @Override public void surfaceCreated(SurfaceHolder h) {
        surfaceReady = true;
        holder = h;
        if (player != null) {
            try { player.setDisplay(h); } catch (Exception ignored) { }
        }
    }

    @Override public void surfaceChanged(SurfaceHolder h, int format, int width, int height) {
        holder = h;
        if (player != null) {
            try { player.setDisplay(h); } catch (Exception ignored) { }
        }
    }

    @Override public void surfaceDestroyed(SurfaceHolder h) {
        surfaceReady = false;
        if (player != null) {
            try { player.setDisplay(null); } catch (Exception ignored) { }
        }
    }

    private void complete() {
        if (completed) return;
        completed = true;
        stopAndReleasePlayer();
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("FAZBEAR_VIDEO_COMPLETE", true);
        i.putExtra("VIDEO_KIND", kind);
        try { startActivity(i); } catch (Exception ignored) { }
        finish();
    }

    private void fail(String reason) {
        if (completed) return;
        completed = true;
        stopAndReleasePlayer();
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("FAZBEAR_VIDEO_ERROR", true);
        i.putExtra("VIDEO_KIND", kind);
        i.putExtra("VIDEO_ERROR_TEXT", reason == null ? "MP4 PLAYBACK FAILED" : reason);
        try { startActivity(i); } catch (Exception ignored) { }
        finish();
    }

    private void finishWithoutCallback() {
        completed = true;
        stopAndReleasePlayer();
        finish();
    }

    private void stopAndReleasePlayer() {
        MediaPlayer mp = player;
        player = null;
        if (mp != null) {
            try { if (mp.isPlaying()) mp.stop(); } catch (Exception ignored) { }
            try { mp.reset(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
        }
    }

    @Override protected void onDestroy() {
        stopAndReleasePlayer();
        if (current == this) current = null;
        super.onDestroy();
    }
}
