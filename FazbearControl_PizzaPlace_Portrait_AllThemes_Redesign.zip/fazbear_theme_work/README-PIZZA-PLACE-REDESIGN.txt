FAZBEAR CONTROL — PORTRAIT PIZZA PLACE VISUAL REDESIGN

This pass updates the Canvas-based UI styling for theme 3:
- Warm pizzeria palette, checkerboard trim, marquee header, arcade buttons.
- Home dashboard includes the existing home media plus the four existing character bitmaps.
- Existing touch target bands and controller actions were kept in place.
- The 10 theme choices remain available; theme 3 is labeled Pizza Place.
- Existing source image assets were not replaced.

Important:
- This is a visual redesign pass only.
- The uploaded source did not include a Show Schedule screen or background scheduler;
  those are not added by this ZIP.
- No successful Gradle build has been run in this environment. Build and test in Android Studio,
  especially home-screen touch actions and all theme choices, before relying on the app.
