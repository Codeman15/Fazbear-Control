package com.fazbear.control;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.InputType;
import android.widget.EditText;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import org.json.JSONObject;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.net.wifi.WifiManager;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    FazbearView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 9001);
        }
        view = new FazbearView(this);
        setContentView(view);
        if (getIntent() != null && getIntent().getBooleanExtra("OPEN_FAZBEAR_DEBUG", false)) view.openDebugFromNotification();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (view != null && intent.getBooleanExtra("OPEN_FAZBEAR_DEBUG", false)) view.openDebugFromNotification();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (view != null) {
            view.handleImageResult(requestCode, resultCode, data);
            view.handleWavResult(requestCode, resultCode, data);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (view != null && requestCode == 9002) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            view.onAudioPermissionResult(granted);
        }
    }

    @Override protected void onDestroy() {
        if (view != null) view.shutdown();
        super.onDestroy();
    }
}

class FazbearView extends View {
    final Context appContext;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService net = Executors.newCachedThreadPool();
    final DatagramSocket rxSocket;
    final SharedPreferences prefs;

    final String[] names = {"FREDDY", "BONNIE", "CHICA", "STAGE"};
    final String[] defaultIPs = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
    final String[] ips = new String[4];
    final String[] animNames = {"Animation 1", "Welcome Show", "Song 1", "Song 2", "Wave", "Point", "Laugh", "Custom"};
    final Bitmap[] chars = new Bitmap[4];
    final String[] customCharUris = new String[4];
    int pendingCharacterSlot = -1;
    static final int PICK_CHARACTER_IMAGE = 4211;
    final Bitmap[] customAnimImages = new Bitmap[8];
    final String[] customAnimUris = new String[8];
    int pendingImageSlot = -1;
    static final int PICK_ANIMATION_IMAGE = 4208;
    Movie menuGif;
    Bitmap customBackground;
    String customBackgroundUri;
    Bitmap[] themeBackgrounds = new Bitmap[10];
    String[] themeBackgroundUris = new String[10];
    int[] themeEffects = new int[10]; // 0=default, 1=CRT, 2=glitch, 3=static, 4=neon, 5=none
    boolean scanlinesEnabled = true;
    boolean glitchEnabled = true;
    static final int PICK_THEME_BACKGROUND = 4210;
    static final int PICK_HOME_MEDIA = 4213;
    static final int PICK_WAV_AUDIO = 4214;
    MediaPlayer localWavPlayer;
    String selectedWavUri;
    String selectedWavName = "NO WAV SELECTED";
    boolean localWavPlaying = false;
    Bitmap homeCustomBitmap;
    Movie homeCustomMovie;
    String homeCustomMediaUri;
    long homeCustomMovieStartedAt = -1;
    long menuGifStartedAt = -1;

    static final int HOME = 0, DEVICES = 1, TIMELINE = 2, CONTROL = 3, SETTINGS = 4, DEBUG = 5, DEVICE_DETAIL = 6, ANIMATIONS = 7, DIAGNOSTICS = 8;

    int screen = HOME;
    int page = 0;
    int selectedAnimation = 1;
    boolean autoplay = false;
    boolean loop = false;
    boolean[] online = new boolean[4];
    long[] lastSeen = new long[4];
    // Actual ESP32 Wi-Fi RSSI, populated by CTOUCH,WIFI,<ID>,<dBm> packets.
    int[] controllerWifiRssi = {-127, -127, -127, -127};
    long[] lastWifiSeen = new long[4];
    String[] playing = {"Stopped", "Stopped", "Stopped", "Stage Lights"};
    int[] progress = {0, 0, 0, 0};
    int syncedVolume = -1;
    volatile boolean vuCaptureRequested = false;
    // Mic-based VU telemetry: normalized RMS level, peak hold, dBFS readout, and clip warning.
    volatile float vuLevel = 0f;
    volatile float vuPeak = 0f;
    volatile float vuDbfs = -60f;
    volatile float vuPeakDbfs = -60f;
    volatile boolean vuClip = false;
    volatile long vuPeakHoldUntil = 0L;
    volatile boolean vuPermissionDenied = false;
    AudioRecord audioRecord;
    int playbackTimeMs = 0;
    int durationMs = -1;
    boolean bottangoPlaying = false;
    boolean playbackStateKnown = false;
    boolean playbackPollInFlight = false;
    boolean lastPlaybackWasPlaying = false;
    int lastAutoAdvanceIndex = -1;
    boolean playbackPollErrorLogged = false;
    long lastPlaybackPollAt = 0L;
    String lastPlaybackError = "";
    String currentTrackName = "BOTTANGO PLAYBACK";
    ArrayList<String> log = new ArrayList<>();
    String status = "SYSTEM READY";
    String errorTitle = "";
    String errorMessage = "";
    String errorDetails = "";
    boolean errorPopup = false;
    int theme = 0;
    volatile int phoneWifiRssi = -127;

    // Audio output: 0 = MAX98357 only, 1 = BOTH, 2 = PHONE only.
    WifiAudioReceiver phoneAudioReceiver;
    int audioOutputMode = 0;
    String phoneAudioStatus = "MAX98357 ONLY";

    FazbearView(Context c) {
        super(c);
        appContext = c;
        setFocusable(true);
        try {
            menuGif = Movie.decodeStream(c.getAssets().open("menu.gif"));
        } catch (Exception ignored) {
            menuGif = null;
        }
        prefs = c.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        selectedWavUri = prefs.getString("selected_wav_uri", null);
        selectedWavName = prefs.getString("selected_wav_name", "NO WAV SELECTED");
        for (int i = 0; i < 4; i++) ips[i] = prefs.getString("ip" + i, defaultIPs[i]);
        theme = prefs.getInt("theme", 3);
        if (!prefs.contains("theme")) prefs.edit().putInt("theme", 3).apply();
        scanlinesEnabled = prefs.getBoolean("theme_scanlines", true);
        glitchEnabled = prefs.getBoolean("theme_glitch", true);
        customBackgroundUri = prefs.getString("theme_background", null);
        if (customBackgroundUri != null && prefs.getString("theme_bg_" + theme, null) == null) {
            themeBackgroundUris[theme] = customBackgroundUri;
            loadThemeBackground(theme, android.net.Uri.parse(customBackgroundUri));
        }
        for (int i = 0; i < 10; i++) {
            themeBackgroundUris[i] = prefs.getString("theme_bg_" + i, themeBackgroundUris[i]);
            themeEffects[i] = prefs.getInt("theme_effect_" + i, 0);
            if (themeBackgroundUris[i] != null) loadThemeBackground(i, android.net.Uri.parse(themeBackgroundUris[i]));
        }
        homeCustomMediaUri = prefs.getString("home_custom_media", null);
        if (homeCustomMediaUri != null) loadHomeMedia(android.net.Uri.parse(homeCustomMediaUri));
        for (int i = 0; i < 8; i++) {
            animNames[i] = prefs.getString("animName" + i, animNames[i]);
            customAnimUris[i] = prefs.getString("animImage" + i, null);
            if (customAnimUris[i] != null) loadCustomAnimationImage(i, android.net.Uri.parse(customAnimUris[i]));
        }

        chars[0] = load(c, "freddy");
        chars[1] = load(c, "bonnie");
        chars[2] = load(c, "chica");
        chars[3] = load(c, "stage");
        for (int i = 0; i < 4; i++) {
            customCharUris[i] = prefs.getString("charImage" + i, null);
            if (customCharUris[i] != null) loadCustomCharacterImage(i, android.net.Uri.parse(customCharUris[i]));
        }

        DatagramSocket s = null;
        try {
            s = new DatagramSocket(4211);
            s.setBroadcast(true);
            addLog("UDP RX READY  //  PORT 4211");
        } catch (Exception e) {
            addLog("UDP RX ERROR: " + e.getMessage());
            showError("NETWORK ERROR", "Unable to open UDP 4211", String.valueOf(e.getMessage()));
        }
        rxSocket = s;
        if (rxSocket != null) startReceiver();
        addLog("FAZBEAR CONTROL ONLINE");

        main.postDelayed(() -> {
            for (int i = 0; i < 4; i++) {
                if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
            }
            invalidate();
            main.postDelayed(this::tick, 1000);
            main.postDelayed(this::pollBottangoState, 400);
        }, 1000);
    }

    void tick() {
        updatePhoneWifiRssi();
        for (int i = 0; i < 4; i++) {
            if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
        }
        invalidate();
        main.postDelayed(this::tick, 1000);
        if (screen == TIMELINE) ensureVuCaptureIfPermitted();
    }

    void updatePhoneWifiRssi() {
        try {
            WifiManager wm = (WifiManager) appContext.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm != null && wm.getConnectionInfo() != null) {
                phoneWifiRssi = wm.getConnectionInfo().getRssi();
            } else {
                phoneWifiRssi = -127;
            }
        } catch (Exception ignored) {
            phoneWifiRssi = -127;
        }
    }

    int phoneWifiBars() {
        int rssi = phoneWifiRssi;
        if (rssi <= -100 || rssi == 0) return 0;
        if (rssi >= -55) return 5;
        if (rssi >= -65) return 4;
        if (rssi >= -75) return 3;
        if (rssi >= -85) return 2;
        return 1;
    }

    // Controller bars use measured ESP32 Wi-Fi RSSI, not packet freshness.
    // A controller without an RSSI packet stays unknown (all gray bars).
    int controllerWifiBars(int i) {
        if (i < 0 || i >= 4 || !online[i]) return 0;
        if (lastWifiSeen[i] == 0 || System.currentTimeMillis() - lastWifiSeen[i] > 6000) return 0;
        int rssi = controllerWifiRssi[i];
        if (rssi >= -55) return 5;
        if (rssi >= -65) return 4;
        if (rssi >= -75) return 3;
        if (rssi >= -85) return 2;
        if (rssi >= -100) return 1;
        return 0;
    }

    int controllerIndexForId(String id) {
        if (id == null) return -1;
        for (int i = 0; i < names.length; i++) {
            if (names[i].equalsIgnoreCase(id.trim())) return i;
        }
        return -1;
    }

    void signalBars(Canvas c, float x, float baseline, int bars, int color, float barWidth, float gap, float maxHeight) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 5; i++) {
            float h = maxHeight * (i + 1) / 5f;
            p.setColor(i < bars ? color : 0xFF454754);
            c.drawRoundRect(x + i * (barWidth + gap), baseline - h,
                    x + i * (barWidth + gap) + barWidth, baseline, 1.5f, 1.5f, p);
        }
    }

    Bitmap load(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(getResources(), id);
    }

    void startReceiver() {
        net.execute(() -> {
            byte[] buf = new byte[2048];
            while (rxSocket != null && !rxSocket.isClosed()) {
                try {
                    DatagramPacket d = new DatagramPacket(buf, buf.length);
                    rxSocket.receive(d);
                    String msg = new String(d.getData(), d.getOffset(), d.getLength()).trim();
                    final String host = d.getAddress().getHostAddress();
                    main.post(() -> handlePacket(host, msg));
                } catch (Exception ignored) {}
            }
        });
    }

    void handlePacket(String host, String msg) {
        int idx = indexForHost(host);
        String[] fields = msg.split(",");
        // New firmware reports actual radio strength separately from the legacy status packet.
        if (fields.length >= 4 && "CTOUCH".equalsIgnoreCase(fields[0].trim())
                && "WIFI".equalsIgnoreCase(fields[1].trim())) {
            int idIndex = controllerIndexForId(fields[2]);
            try {
                int rssi = Integer.parseInt(fields[3].trim());
                if (idIndex >= 0 && rssi >= -127 && rssi <= 0) {
                    controllerWifiRssi[idIndex] = rssi;
                    lastWifiSeen[idIndex] = System.currentTimeMillis();
                    online[idIndex] = true;
                    lastSeen[idIndex] = System.currentTimeMillis();
                    addLog(names[idIndex] + " WI-FI RSSI " + rssi + " dBm");
                }
            } catch (NumberFormatException ignored) { }
        }
        if (idx >= 0 && !msg.toUpperCase(Locale.US).startsWith("CTOUCH,WIFI,")) {
            online[idx] = true;
            lastSeen[idx] = System.currentTimeMillis();
        }
        addLog(host + " > " + msg);

        int v = parseVolume(msg);
        if (v >= 0) {
            syncedVolume = v;
            status = "VOLUME " + v + "%  //  ESP32 POT";
        }

        if (msg.toUpperCase(Locale.US).contains("ANIM_DONE")) {
            if (idx >= 0) {
                progress[idx] = 100;
                if (autoplay) {
                    int next = selectedAnimation >= 8 ? 1 : selectedAnimation + 1;
                    selectedAnimation = next;
                    playing[idx] = animNames[next - 1];
                    send(idx, "[START " + next + "]");
                }
            }
        }
        invalidate();
    }

    int indexForHost(String host) {
        for (int i = 0; i < 4; i++) if (ips[i].equals(host)) return i;
        return -1;
    }

    int parseVolume(String msg) {
        // Accept the explicit status suffix: ...,VOLUME,<0..100>.
        // Do not mistake unrelated numbers (file offsets, CPU data, etc.) for volume.
        String[] fields = msg.split(",");
        for (int i = 0; i < fields.length - 1; i++) {
            if ("VOLUME".equalsIgnoreCase(fields[i].trim())) {
                try {
                    int value = Integer.parseInt(fields[i + 1].trim());
                    return value >= 0 && value <= 100 ? value : -1;
                } catch (NumberFormatException ignored) {
                    return -1;
                }
            }
        }
        // Also accept a standalone legacy message such as "VOLUME 75".
        String u = msg.trim().toUpperCase(Locale.US);
        if (u.matches("VOLUME\\s+\\d{1,3}%?")) {
            try {
                String digits = u.replaceAll("[^0-9]", "");
                int value = Integer.parseInt(digits);
                return value >= 0 && value <= 100 ? value : -1;
            } catch (NumberFormatException ignored) { return -1; }
        }
        return -1;
    }

    void addLog(String s) {
        log.add(timeStamp() + "  " + s);
        while (log.size() > 160) log.remove(0);
        invalidate();
    }

    String timeStamp() {
        long n = System.currentTimeMillis() / 1000;
        return String.format(Locale.US, "%02d:%02d:%02d", (n / 3600) % 24, (n / 60) % 60, n % 60);
    }

    void send(int which, String cmd) {
        if (which < 0 || which > 3) return;
        final String ip = ips[which];
        addLog(ip + " < " + cmd);
        net.execute(() -> {
            try {
                byte[] data = cmd.getBytes("UTF-8");
                DatagramPacket dp = new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210);
                DatagramSocket s = new DatagramSocket();
                s.setBroadcast(true);
                s.send(dp);
                s.close();
                main.post(this::invalidate);
            } catch (Exception e) {
                main.post(() -> {
                    addLog("SEND ERROR " + ip + ": " + e.getMessage());
                    showError("COMMAND FAILED", "Could not reach ESP32 " + names[which],
                            "Target: " + ip + "\nUDP command port: 4210\n" + e.getMessage());
                });
            }
        });
    }

    void broadcast(String cmd) { for (int i = 0; i < 4; i++) send(i, cmd); }

    void play(int i, int anim) {
        selectedAnimation = anim;
        playing[i] = animNames[anim - 1];
        progress[i] = 0;
        send(i, "[START " + anim + "]");
        status = names[i] + "  //  PLAYING " + animNames[anim - 1];
    }

    // Bottango Windows REST API (configured for this show's PC).
    // Bottango API Access must be enabled in the Hardware menu.
    static final String BOTTANGO_PLAYBACK_URL = "http://10.0.0.226:59224/PlaybackState/";

    void sendBottangoPlayback(String json, String successStatus) {
        status = "BOT TANGO // SENDING";
        addLog("BOT TANGO PUT " + BOTTANGO_PLAYBACK_URL + " BODY " + json);
        invalidate();
        net.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(BOTTANGO_PLAYBACK_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("PUT");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] body = json.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream os = connection.getOutputStream()) { os.write(body); }
                int code = connection.getResponseCode();
                if (code >= 200 && code < 300) {
                    main.post(() -> {
                        status = successStatus;
                        addLog("BOTTANGO API OK // HTTP " + code);
                        invalidate();
                    });
                } else {
                    String response = "";
                    InputStream es = connection.getErrorStream();
                    if (es != null) {
                        try (InputStream in = es; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                            byte[] buf = new byte[512]; int count;
                            while ((count = in.read(buf)) != -1) out.write(buf, 0, count);
                            response = out.toString("UTF-8");
                        }
                    }
                    final String detail = "HTTP " + code + (response.isEmpty() ? "" : " // " + response);
                    main.post(() -> {
                        status = "BOTTANGO API ERROR";
                        addLog("BOTTANGO API ERROR // " + detail);
                        showError("BOTTANGO COMMAND FAILED", "The PC rejected the playback request", detail + "\nURL: " + BOTTANGO_PLAYBACK_URL);
                    });
                }
            } catch (Exception e) {
                final String detail = e.getClass().getSimpleName() + ": " + e.getMessage();
                main.post(() -> {
                    status = "BOTTANGO OFFLINE";
                    addLog("BOTTANGO CONNECTION ERROR // " + detail);
                    showError("BOTTANGO CONNECTION FAILED", "Could not connect to Bottango on the Windows PC", detail + "\nURL: " + BOTTANGO_PLAYBACK_URL + "\nCheck that the phone can reach the PC and Windows Firewall allows Bottango on the local network.");
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    void playAll() {
        lastAutoAdvanceIndex = -1;
        lastPlaybackWasPlaying = false;
        for (int i = 0; i < 4; i++) {
            if (i == 3) playing[i] = "Stage Lights";
            else playing[i] = animNames[selectedAnimation - 1];
            progress[i] = 0;
        }
        // Bottango animation indexes are zero-based; the app's slots are 1–8.
        sendBottangoPlayback("{\"selectedAnimationIndex\":" + (selectedAnimation - 1) + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "PLAY ALL  //  " + animNames[selectedAnimation - 1]);
    }

    void restartShow() {
        // Restart means return to the beginning of the show, not merely seek the
        // currently selected animation back to zero. Bottango animation indexes are zero-based.
        selectedAnimation = 1;
        lastAutoAdvanceIndex = -1;
        lastPlaybackWasPlaying = false;
        currentTrackName = animNames[0];
        playbackTimeMs = 0;
        for (int i = 0; i < 4; i++) progress[i] = 0;
        for (int i = 0; i < 3; i++) playing[i] = animNames[0];
        playing[3] = "Stage Lights";
        sendBottangoPlayback("{\"selectedAnimationIndex\":0,\"playbackTimeInMS\":0,\"isPlaying\":true}", "RESTART SHOW  //  " + animNames[0]);
        invalidate();
    }

    void skipAnimation() {
        int nextIndex = selectedAnimation; // selectedAnimation is 1-based; this is the next 0-based index.
        if (nextIndex >= animNames.length) {
            if (loop) nextIndex = 0;
            else {
                status = "SHOW COMPLETE  //  LAST ANIMATION";
                addLog("SKIP // ALREADY AT LAST ANIMATION");
                invalidate();
                return;
            }
        }
        selectedAnimation = nextIndex + 1;
        lastAutoAdvanceIndex = -1;
        lastPlaybackWasPlaying = false;
        currentTrackName = animNames[nextIndex];
        playbackTimeMs = 0;
        for (int i = 0; i < 3; i++) {
            playing[i] = animNames[nextIndex];
            progress[i] = 0;
        }
        playing[3] = "Stage Lights";
        addLog("SKIP ANIMATION // " + animNames[nextIndex]);
        sendBottangoPlayback("{\"selectedAnimationIndex\":" + nextIndex + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "SKIP  //  " + animNames[nextIndex]);
        invalidate();
    }

    void advanceAfterCurrentAnimation(int completedZeroBasedIndex) {
        if (!autoplay || completedZeroBasedIndex < 0 || completedZeroBasedIndex >= animNames.length) return;
        if (lastAutoAdvanceIndex == completedZeroBasedIndex) return;
        lastAutoAdvanceIndex = completedZeroBasedIndex;

        int nextIndex = completedZeroBasedIndex + 1;
        if (nextIndex >= animNames.length) {
            if (loop) nextIndex = 0;
            else {
                status = "SHOW COMPLETE  //  AUTOPLAY ON";
                addLog("AUTOPLAY // LAST ANIMATION FINISHED");
                invalidate();
                return;
            }
        }

        selectedAnimation = nextIndex + 1;
        currentTrackName = animNames[nextIndex];
        playbackTimeMs = 0;
        for (int i = 0; i < 3; i++) {
            playing[i] = animNames[nextIndex];
            progress[i] = 0;
        }
        addLog("AUTOPLAY // NEXT: " + animNames[nextIndex]);
        sendBottangoPlayback("{\"selectedAnimationIndex\":" + nextIndex + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "AUTO NEXT  //  " + animNames[nextIndex]);
        invalidate();
    }

    void pollBottangoState() {
        if (playbackPollInFlight) {
            main.postDelayed(this::pollBottangoState, 1500);
            return;
        }
        playbackPollInFlight = true;
        net.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(BOTTANGO_PLAYBACK_URL).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(2500);
                connection.setReadTimeout(2500);
                int code = connection.getResponseCode();
                if (code >= 200 && code < 300) {
                    StringBuilder body = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = reader.readLine()) != null) body.append(line);
                    }
                    JSONObject json = new JSONObject(body.toString());
                    long time = jsonLong(json, -1, "playbackTimeInMS", "playbackTimeMs", "currentTimeInMS", "currentTimeMs");
                    long duration = jsonLong(json, -1, "durationInMS", "playbackDurationInMS", "animationDurationInMS", "totalDurationInMS", "durationMs");
                    long index = jsonLong(json, -1, "selectedAnimationIndex", "animationIndex");
                    boolean playingNow = jsonBoolean(json, bottangoPlaying, "isPlaying", "playing");
                    final long parsedTime = time;
                    final long parsedDuration = duration;
                    final long parsedIndex = index;
                    final boolean parsedPlaying = playingNow;
                    main.post(() -> {
                        int priorIndex = selectedAnimation - 1;
                        boolean wasPlaying = lastPlaybackWasPlaying;
                        if (parsedTime >= 0 && parsedTime <= Integer.MAX_VALUE) playbackTimeMs = (int) parsedTime;
                        if (parsedDuration > 0 && parsedDuration <= Integer.MAX_VALUE) durationMs = (int) parsedDuration;
                        if (parsedIndex >= 0 && parsedIndex < animNames.length) {
                            selectedAnimation = (int) parsedIndex + 1;
                            currentTrackName = animNames[selectedAnimation - 1];
                            if ((int) parsedIndex != lastAutoAdvanceIndex) lastAutoAdvanceIndex = -1;
                        }
                        int observedIndex = parsedIndex >= 0 && parsedIndex < animNames.length
                                ? (int) parsedIndex : priorIndex;
                        boolean reachedEnd = parsedDuration > 0 && parsedTime >= 0
                                && parsedTime >= parsedDuration - 250;
                        boolean stoppedAfterPlaying = wasPlaying && !parsedPlaying;
                        bottangoPlaying = parsedPlaying;
                        lastPlaybackWasPlaying = parsedPlaying;
                        playbackStateKnown = true;
                        lastPlaybackPollAt = System.currentTimeMillis();
                        lastPlaybackError = "";
                        playbackPollErrorLogged = false;
                        if (autoplay && observedIndex >= 0 && observedIndex < animNames.length
                                && (reachedEnd || stoppedAfterPlaying)) {
                            advanceAfterCurrentAnimation(observedIndex);
                        }
                        invalidate();
                    });
                } else if (!playbackPollErrorLogged) {
                    main.post(() -> { lastPlaybackError = "HTTP " + code; addLog("BOTTANGO STATE GET // HTTP " + code); playbackPollErrorLogged = true; invalidate(); });
                }
            } catch (Exception e) {
                if (!playbackPollErrorLogged) {
                    String detail = e.getClass().getSimpleName() + ": " + e.getMessage();
                    main.post(() -> { lastPlaybackError = detail; addLog("BOTTANGO STATE POLL UNAVAILABLE // " + detail); playbackPollErrorLogged = true; invalidate(); });
                }
            } finally {
                if (connection != null) connection.disconnect();
                playbackPollInFlight = false;
                main.postDelayed(this::pollBottangoState, 1500);
            }
        });
    }

    long jsonLong(JSONObject json, long fallback, String... keys) {
        for (String key : keys) {
            Object value = json.opt(key);
            if (value instanceof Number) return ((Number) value).longValue();
            if (value instanceof String) {
                try { return Long.parseLong(((String) value).trim()); } catch (Exception ignored) {}
            }
        }
        return fallback;
    }

    boolean jsonBoolean(JSONObject json, boolean fallback, String... keys) {
        for (String key : keys) {
            Object value = json.opt(key);
            if (value instanceof Boolean) return (Boolean) value;
            if (value instanceof Number) return ((Number) value).intValue() != 0;
            if (value instanceof String) {
                String v = ((String) value).trim();
                if ("true".equalsIgnoreCase(v) || "1".equals(v)) return true;
                if ("false".equalsIgnoreCase(v) || "0".equals(v)) return false;
            }
        }
        return fallback;
    }

    void seekBy(int deltaMs) {
        int target = Math.max(0, playbackTimeMs + deltaMs);
        if (durationMs > 0) target = Math.min(target, durationMs);
        seekTo(target);
    }

    void seekTo(int targetMs) {
        targetMs = Math.max(0, targetMs);
        if (durationMs > 0) targetMs = Math.min(targetMs, durationMs);
        playbackTimeMs = targetMs;
        String body = "{\"selectedAnimationIndex\":" + (selectedAnimation - 1) + ",\"playbackTimeInMS\":" + targetMs + (bottangoPlaying ? ",\"isPlaying\":true" : "") + "}";
        sendBottangoPlayback(body, "SEEK  //  " + formatTime(targetMs));
        invalidate();
    }

    String formatTime(int ms) {
        int seconds = Math.max(0, ms / 1000);
        return String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60);
    }

    void ensureVuPermission() {
        if (Build.VERSION.SDK_INT >= 23 && appContext.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ((Activity) appContext).requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 9002);
        } else {
            vuPermissionDenied = false;
            startVuCapture();
        }
    }

    void onAudioPermissionResult(boolean granted) {
        vuPermissionDenied = !granted;
        if (granted && screen == TIMELINE) startVuCapture();
        else if (!granted) stopVuCapture();
        invalidate();
    }

    void ensureVuCaptureIfPermitted() {
        if (appContext.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVuCapture();
    }

    synchronized void startVuCapture() {
        if (vuCaptureRequested) return;
        vuCaptureRequested = true;
        net.execute(() -> {
            AudioRecord recorder = null;
            try {
                int min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) min = 4096;
                recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 4096));
                audioRecord = recorder;
                recorder.startRecording();
                short[] samples = new short[512];
                while (vuCaptureRequested && recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    int count = recorder.read(samples, 0, samples.length);
                    if (count > 0) {
                        double sum = 0;
                        double samplePeak = 0;
                        for (int i = 0; i < count; i++) {
                            double v = samples[i] / 32768.0;
                            double abs = Math.abs(v);
                            sum += v * v;
                            if (abs > samplePeak) samplePeak = abs;
                        }
                        float rms = (float) Math.sqrt(sum / count);
                        float dbfs = (float) (20.0 * Math.log10(Math.max(rms, 0.000001)));
                        float peakDbfs = (float) (20.0 * Math.log10(Math.max(samplePeak, 0.000001)));
                        dbfs = Math.max(-60f, Math.min(0f, dbfs));
                        peakDbfs = Math.max(-60f, Math.min(0f, peakDbfs));
                        float level = (dbfs + 60f) / 60f;
                        float instantPeak = (peakDbfs + 60f) / 60f;
                        vuLevel = vuLevel * 0.68f + level * 0.32f;
                        long now = System.currentTimeMillis();
                        if (instantPeak >= vuPeak || now > vuPeakHoldUntil) {
                            vuPeak = Math.max(instantPeak, vuPeak * 0.985f);
                            if (instantPeak >= vuPeak) {
                                vuPeakDbfs = peakDbfs;
                                vuPeakHoldUntil = now + 900;
                            } else {
                                vuPeakDbfs = -60f + vuPeak * 60f;
                            }
                        }
                        vuDbfs = dbfs;
                        if (samplePeak >= 0.985) vuClip = true;
                        main.post(this::invalidate);
                    }
                }
            } catch (Exception e) {
                main.post(() -> addLog("VU MIC ERROR // " + e.getMessage()));
            } finally {
                if (recorder != null) {
                    try { recorder.stop(); } catch (Exception ignored) {}
                    recorder.release();
                }
                if (audioRecord == recorder) audioRecord = null;
            }
        });
    }

    synchronized void stopVuCapture() {
        vuCaptureRequested = false;
        AudioRecord r = audioRecord;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) {}
        }
        vuLevel = 0f;
        vuPeak = 0f;
        vuDbfs = -60f;
        vuPeakDbfs = -60f;
        vuClip = false;
        vuPeakHoldUntil = 0L;
    }

    void showError(String title, String message, String details) {
        errorTitle = title;
        errorMessage = message;
        errorDetails = details == null ? "" : details;
        errorPopup = false;
        screen = DEBUG;
        addLog("ERROR: " + title + " - " + message + (errorDetails.isEmpty() ? "" : " | " + errorDetails));
        postErrorNotification(title, message);
        invalidate();
    }

    void openDebugFromNotification() {
        screen = DEBUG;
        errorPopup = false;
        invalidate();
    }

    void postErrorNotification(String title, String message) {
        try {
            Context context = appContext.getApplicationContext();
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            String channelId = "fazbear_errors";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(channelId, "Fazbear Control errors", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Alerts when Fazbear Control encounters an error");
                manager.createNotificationChannel(channel);
            }
            Intent intent = new Intent(context, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.putExtra("OPEN_FAZBEAR_DEBUG", true);
            PendingIntent pending = PendingIntent.getActivity(context, 9002, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, channelId) : new Notification.Builder(context);
            Notification notification = builder.setSmallIcon(android.R.drawable.stat_notify_error)
                    .setContentTitle("Fazbear Control — " + title)
                    .setContentText(message)
                    .setStyle(new Notification.BigTextStyle().bigText(message + "\nTap to open Advanced Debug."))
                    .setContentIntent(pending).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).build();
            if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                manager.notify(9003, notification);
            }
        } catch (Exception ignored) { }
    }

    void retryError() {
        errorPopup = false;
        send(page, "[STATUS]");
        status = "STATUS REQUEST SENT";
        invalidate();
    }

    void shutdown() {
        stopLocalWav();
        stopVuCapture();
        stopPhoneAudioReceiver();
        try { if (rxSocket != null) rxSocket.close(); } catch (Exception ignored) {}
        net.shutdownNow();
    }

    void selectAudioOutput(int mode) {
        if (mode < 0 || mode > 2) return;

        // Phone receiver is needed for BOTH and PHONE-only modes.
        boolean needsPhone = (mode == 1 || mode == 2);
        stopPhoneAudioReceiver();

        if (!needsPhone) {
            send(0, "[AUDIO MAX]");
            audioOutputMode = 0;
            phoneAudioStatus = "MAX98357 ONLY SELECTED";
            status = "MAX98357 OUTPUT SELECTED";
            addLog("AUDIO OUTPUT // MAX98357 ONLY");
            invalidate();
            return;
        }

        WifiAudioReceiver receiver = new WifiAudioReceiver();
        try {
            // Start the phone receiver before requesting the ESP32 stream.
            receiver.start();
            phoneAudioReceiver = receiver;
            audioOutputMode = mode;
            if (mode == 1) {
                send(0, "[AUDIO BOTH]");
                phoneAudioStatus = "BOTH OUTPUTS • UDP 4212";
                status = "AUDIO OUTPUT // MAX98357 + PHONE";
                addLog("AUDIO OUTPUT // BOTH REQUESTED");
            } else {
                send(0, "[AUDIO PHONE]");
                phoneAudioStatus = "PHONE ONLY • UDP 4212";
                status = "AUDIO OUTPUT // PHONE ONLY";
                addLog("AUDIO OUTPUT // PHONE ONLY REQUESTED");
            }
        } catch (Exception ex) {
            audioOutputMode = 0;
            phoneAudioStatus = "PHONE RECEIVER START FAILED";
            status = "PHONE AUDIO RECEIVER FAILED";
            addLog("PHONE AUDIO START ERROR: " + ex.getMessage());
            try { receiver.close(); } catch (Exception ignored) {}
            send(0, "[AUDIO MAX]");
            showError("PHONE AUDIO ERROR", "Could not start audio receiver", String.valueOf(ex.getMessage()));
        }
        invalidate();
    }

    void stopPhoneAudioReceiver() {
        if (phoneAudioReceiver != null) {
            try { phoneAudioReceiver.close(); } catch (Exception ignored) {}
            phoneAudioReceiver = null;
        }
    }

    int accent() {
        switch (theme) {
            case 0: return 0xFFB000FF; // Neon purple
            case 1: return Color.CYAN;
            case 2: return Color.YELLOW;
            case 3: return 0xFFFFC45A; // Pizza Place marquee gold
            case 4: return 0xFFFF3B30; // Alert red
            case 5: return 0xFF66BFFF; // Ice blue
            case 6: return 0xFFFF8C42; // Sunset orange
            case 7: return 0xFFFF66B3; // Pink
            case 8: return 0xFFE6E6E6; // Monochrome
            case 9: return 0xFFB7FF00; // Toxic lime
            default: return 0xFF52FF91;
        }
    }
    int red() { return 0xFFFF1744; }
    int panel() { return theme == 3 ? 0xFF21130F : 0xFF090B14; }
    int panel2() { return theme == 3 ? 0xFF382019 : 0xFF111525; }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(size); p.setColor(color); p.setTextAlign(a); p.setStyle(Paint.Style.FILL);
        c.drawText(s, x, y, p);
    }

    void rect(Canvas c, float l, float t, float r, float b, int color, boolean stroke) {
        p.setColor(color); p.setStyle(stroke ? Paint.Style.STROKE : Paint.Style.FILL); p.setStrokeWidth(stroke ? 1.5f : 1);
        c.drawRect(l, t, r, b, p); p.setStyle(Paint.Style.FILL);
    }

    // Read-only volume indicator. The ESP32 potentiometer remains the only control.
    void volumeIndicator(Canvas c, float x, float y, float w, float h) {
        rect(c, x, y, x + w, y + h, 0xFF303747, false);
        rect(c, x, y, x + w, y + h, 0xFF596174, true);
        if (syncedVolume >= 0) {
            float filled = w * (Math.max(0, Math.min(100, syncedVolume)) / 100f);
            int color = syncedVolume >= 85 ? red() : syncedVolume >= 60 ? Color.YELLOW : Color.GREEN;
            if (filled > 0) rect(c, x + 1, y + 1, x + Math.max(1, filled - 1), y + h - 1, color, false);
        }
        text(c, syncedVolume >= 0 ? syncedVolume + "%" : "--%", x + w + 8, y + h, 9, Color.WHITE, Paint.Align.LEFT);
    }

    void button(Canvas c, int x, int y, int w, int h, String label, int color) {
        // Layered, tactile console button. Geometry remains unchanged so existing taps still line up.
        if (theme == 3) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF130907);
            c.drawRoundRect(x + 1, y + 4, x + w + 1, y + h + 4, 8, 8, p);
            p.setColor(0xFF4A2118);
            c.drawRoundRect(x, y, x + w, y + h, 8, 8, p);
            p.setColor(0xFF6A3320);
            c.drawRoundRect(x + 2, y + 2, x + w - 2, y + h - 2, 6, 6, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(0xFFFFC45A);
            c.drawRoundRect(x + 1, y + 1, x + w - 1, y + h - 1, 8, 8, p);
            p.setStyle(Paint.Style.FILL);
            float fs = h >= 50 ? 11f : h >= 38 ? 9f : h >= 29 ? 8f : 7f;
            text(c, label, x + w / 2f, y + h / 2f + fs * 0.34f, fs, 0xFFFFF0D1, Paint.Align.CENTER);
            return;
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF080A12);
        c.drawRoundRect(x + 1, y + 3, x + w + 1, y + h + 3, 9, 9, p);
        p.setColor(panel2());
        c.drawRoundRect(x, y, x + w, y + h, 9, 9, p);
        p.setColor(0xFF202638);
        c.drawRoundRect(x + 2, y + 2, x + w - 2, y + h - 2, 7, 7, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.25f);
        p.setColor(color);
        c.drawRoundRect(x + 0.7f, y + 0.7f, x + w - 0.7f, y + h - 0.7f, 9, 9, p);
        p.setStyle(Paint.Style.FILL);
        float font = h >= 50 ? 11f : h >= 38 ? 9f : h >= 29 ? 8f : 7f;
        text(c, label, x + w / 2f, y + h / 2f + font * 0.34f, font, Color.WHITE, Paint.Align.CENTER);
    }

    void background(Canvas c) {
        c.drawColor(Color.BLACK);
        for (int y = 0; y < 320; y += 20) {
            p.setColor((y / 20) % 2 == 0 ? 0xFF070711 : 0xFF0A0810);
            c.drawRect(0, y, 480, y + 20, p);
        }
        rect(c, 2, 2, 478, 318, accent(), true);
    }

    void title(Canvas c, String s, String sub) {
        text(c, "FAZBEAR CONTROL", 12, 18, 10, Color.WHITE, Paint.Align.LEFT);
        text(c, s, 240, 20, 14, accent(), Paint.Align.CENTER);
        if (sub != null) text(c, sub, 240, 34, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, syncedVolume >= 0 ? (syncedVolume + "%") : "--%", 468, 16, 7, Color.WHITE, Paint.Align.RIGHT);
        text(c, "VOL SYNC", 468, 28, 5, Color.LTGRAY, Paint.Align.RIGHT);
        rect(c, 8, 40, 472, 41, accent(), false);
    }

    void nav(Canvas c, int selected) {
        rect(c, 0, 276, 480, 320, 0xFF05060B, false);
        String[] n = {"HOME", "DEVICES", "TIMELINE", "CONTROL", "SETTINGS", "DEBUG"};
        for (int i = 0; i < 6; i++) {
            int x = i * 80;
            int col = i == selected ? accent() : Color.LTGRAY;
            text(c, navIcon(i), x + 40, 292, 11, col, Paint.Align.CENTER);
            text(c, n[i], x + 40, 309, 5.5f, col, Paint.Align.CENTER);
        }
    }

    String navIcon(int i) { return new String[]{"⌂", "▣", "≋", "▶", "⚙", "!"}[i]; }

    @Override protected void onDraw(Canvas real) {
        float scale = Math.min(getWidth() / 360f, getHeight() / 800f);
        float ox = (getWidth() - 360f * scale) / 2f;
        float oy = (getHeight() - 800f * scale) / 2f;
        real.drawColor(Color.BLACK);
        real.save();
        real.translate(ox, oy);
        real.scale(scale, scale);
        Canvas c = real;
        portraitBackground(c);
        switch (screen) {
            case HOME: portraitHome(c); break;
            case DEVICES: portraitDevices(c); break;
            case ANIMATIONS: portraitAnimations(c); break;
            case TIMELINE: portraitTimeline(c); break;
            case CONTROL: portraitControl(c); break;
            case SETTINGS: portraitSettings(c); break;
            case DEBUG: portraitDebug(c); break;
            case DIAGNOSTICS: portraitDiagnostics(c); break;
            case DEVICE_DETAIL: portraitDeviceDetail(c); break;
        }
        if (screen != DEVICE_DETAIL) portraitNav(c, screen);
        if (errorPopup) portraitErrorPopup(c);
        drawThemeEffects(c);
        real.restore();
    }

    void portraitBackground(Canvas c) {
        if (theme == 3 && (theme >= themeBackgrounds.length || themeBackgrounds[theme] == null)) {
            c.drawColor(0xFF1B0D0A);
            p.setShader(new LinearGradient(0, 0, 360, 800, 0xFF4A2418, 0xFF160A08, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, 360, 800, p);
            p.setShader(null);
            // Warm wood-plank texture.
            for (int y = 110; y < 720; y += 42) {
                p.setColor(0x223F1C10); p.setStrokeWidth(1);
                c.drawLine(12, y, 348, y, p);
                c.drawLine(34, y + 2, 34, Math.min(720, y + 40), p);
                c.drawLine(220, y + 2, 220, Math.min(720, y + 40), p);
            }
            // Checkerboard trim inspired by the pizzeria reference.
            int tile = 12;
            for (int row = 0; row < 2; row++) {
                for (int col = 0; col < 30; col++) {
                    boolean light = ((row + col) & 1) == 0;
                    p.setColor(light ? 0xFFE8DCC5 : 0xFF241916);
                    c.drawRect(col * tile, 96 + row * tile, col * tile + tile, 108 + row * tile, p);
                    c.drawRect(col * tile, 696 + row * tile, col * tile + tile, 708 + row * tile, p);
                }
            }
            p.setColor(0xFFFFC45A); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
            c.drawRoundRect(7, 7, 353, 793, 12, 12, p); p.setStyle(Paint.Style.FILL);
            return;
        }
        c.drawColor(0xFF070910);
        // Subtle midnight gradient, restrained scanlines, and console edge lighting.
        p.setShader(new LinearGradient(0, 0, 360, 800, 0xFF111321, 0xFF08070E, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 360, 800, p);
        p.setShader(null);
        Bitmap activeBackground = (theme >= 0 && theme < themeBackgrounds.length) ? themeBackgrounds[theme] : null;
        if (activeBackground != null && !activeBackground.isRecycled()) {
            p.setAlpha(150);
            c.drawBitmap(activeBackground, null, new Rect(0, 0, 360, 800), p);
            p.setAlpha(255);
        } else {
            int tint = accent();
            p.setShader(new LinearGradient(0, 0, 360, 800,
                    (tint & 0x00FFFFFF) | 0x33100000,
                    (tint & 0x00FFFFFF) | 0x08000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, 360, 800, p); p.setShader(null);
        }
        if (scanlinesEnabled) {
            for (int y = 0; y < 800; y += 5) {
                p.setColor(y % 10 == 0 ? 0x10000000 : 0x08000000);
                c.drawRect(0, y, 360, y + 1, p);
            }
        }
        // Faint HUD grid only in the background, kept behind all controls.
        p.setColor(0x0C9B70C8); p.setStrokeWidth(1);
        for (int x = 24; x < 360; x += 24) c.drawLine(x, 100, x, 715, p);
        for (int y = 120; y < 720; y += 24) c.drawLine(12, y, 348, y, p);
        // Subtle FNAF checker strips and glitch blocks, echoing the stage floor.
        int tile = 12;
        for (int row = 0; row < 1; row++) {
            for (int col = 0; col < 30; col++) {
                int x = col * tile;
                boolean lit = ((col + row) % 2 == 0);
                p.setColor(lit ? 0x553A1037 : 0x55200D2C);
                c.drawRect(x, 96, x + tile, 108, p);
                p.setColor(lit ? 0x55320A25 : 0x55200D2C);
                c.drawRect(x, 708, x + tile, 720, p);
            }
        }
        p.setColor(0x66FF3155); c.drawRect(12, 96, 348, 97, p);
        p.setColor(0x664F1DFF); c.drawRect(12, 719, 348, 720, p);
        rect(c, 7, 7, 353, 793, 0xFF30283E, true);
        rect(c, 11, 11, 349, 789, 0xFF4A253D, true);
        // Tiny corner status lamps give it a finished security-console feel.
        p.setColor(accent()); c.drawCircle(20, 20, 2.2f, p); c.drawCircle(340, 20, 2.2f, p);
        p.setColor(0xFF5A2434); c.drawCircle(20, 780, 2.2f, p); c.drawCircle(340, 780, 2.2f, p);
    }

    void portraitHeader(Canvas c, String heading, String sub) {
        if (theme == 3) {
            p.setColor(0xF02B100D);
            c.drawRoundRect(12, 14, 348, 94, 8, 8, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(0xFFFFC45A);
            c.drawRoundRect(12.5f, 14.5f, 347.5f, 93.5f, 8, 8, p); p.setStyle(Paint.Style.FILL);
            // Marquee bulbs.
            for (int x = 22; x <= 338; x += 18) {
                p.setColor(0xFFFFE1A0); c.drawCircle(x, 21, 1.8f, p); c.drawCircle(x, 87, 1.8f, p);
            }
            text(c, "FAZBEAR'S PIZZA", 180, 39, 16, 0xFFFFD77D, Paint.Align.CENTER);
            text(c, heading, 180, 62, 12, 0xFFFFF0D1, Paint.Align.CENTER);
            text(c, sub == null ? "" : sub.toUpperCase(Locale.US), 180, 79, 6.5f, 0xFFD8BCA0, Paint.Align.CENTER);
            return;
        }
        p.setColor(0xEE0D101B);
        c.drawRoundRect(12, 14, 348, 94, 12, 12, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1);
        p.setColor(0xFF353044); c.drawRoundRect(12.5f, 14.5f, 347.5f, 93.5f, 12, 12, p);
        p.setStyle(Paint.Style.FILL);
        rect(c, 25, 24, 335, 25, 0xFFFF4D58, false);
        rect(c, 25, 91, 335, 92, 0x884D1DFF, false);
        text(c, "FAZBEAR  /  CONTROL", 180, 43, 17, 0xFFFF654F, Paint.Align.CENTER);
        text(c, heading, 180, 67, 14, accent(), Paint.Align.CENTER);
        text(c, sub == null ? "" : sub.toUpperCase(Locale.US), 180, 83, 7.5f, 0xFFB8B6C7, Paint.Align.CENTER);
    }

    void pButton(Canvas c, int x, int y, int w, int h, String label, int color) {
        button(c, x, y, w, h, label, color);
    }

    void portraitNav(Canvas c, int selected) {
        if (theme == 3) {
            p.setColor(0xF51A0B08);
            c.drawRoundRect(12, 720, 348, 786, 8, 8, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(0xFFFFC45A);
            c.drawRoundRect(12.5f, 720.5f, 347.5f, 785.5f, 8, 8, p); p.setStyle(Paint.Style.FILL);
            String[] labels = {"HOME", "DEVICES", "ANIMATIONS", "CONTROL", "SETTINGS"};
            int[] screens = {HOME, DEVICES, ANIMATIONS, CONTROL, SETTINGS};
            for (int i = 0; i < labels.length; i++) {
                int x = 14 + i * 66;
                int col = selected == screens[i] ? 0xFFFFD06B : 0xFFD1B49A;
                if (selected == screens[i]) {
                    p.setColor(0xFF67301D); c.drawRoundRect(x + 3, 727, x + 59, 778, 6, 6, p);
                    p.setColor(0xFFFFD06B); c.drawRoundRect(x + 3, 727, x + 59, 778, 6, 6, p);
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); c.drawRoundRect(x + 3, 727, x + 59, 778, 6, 6, p); p.setStyle(Paint.Style.FILL);
                }
                text(c, new String[]{"⌂", "▣", "▤", "▶", "⚙"}[i], x + 31, 750, 15, col, Paint.Align.CENTER);
                text(c, labels[i], x + 31, 770, 5.8f, col, Paint.Align.CENTER);
            }
            return;
        }
        p.setColor(0xF20A0C14);
        c.drawRoundRect(12, 720, 348, 786, 12, 12, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xFF343143);
        c.drawRoundRect(12.5f, 720.5f, 347.5f, 785.5f, 12, 12, p); p.setStyle(Paint.Style.FILL);
        String[] labels = {"HOME", "DEVICES", "ANIMATIONS", "CONTROL", "SETTINGS"};
        int[] screens = {HOME, DEVICES, ANIMATIONS, CONTROL, SETTINGS};
        for (int i = 0; i < labels.length; i++) {
            int x = 14 + i * 66;
            int col = selected == screens[i] ? accent() : 0xFF8C8B9D;
            if (selected == screens[i]) {
                p.setColor(0x332A8EFF); c.drawRoundRect(x + 3, 727, x + 59, 778, 9, 9, p);
                rect(c, x + 9, 780, x + 53, 782, col, false);
            }
            text(c, new String[]{"⌂", "▣", "▤", "▶", "⚙"}[i], x + 31, 750, 15, col, Paint.Align.CENTER);
            text(c, labels[i], x + 31, 770, 6.5f, col, Paint.Align.CENTER);
        }
    }

    void portraitAnimations(Canvas c) {
        portraitHeader(c, "ANIMATIONS", "8 SHOW SLOTS  •  EDIT NAME / IMAGE");
        for (int i = 0; i < 8; i++) {
            int col = i % 2, row = i / 2;
            int x = 20 + col * 164, y = 112 + row * 145;
            rect(c, x, y, x + 156, y + 132, panel2(), false);
            rect(c, x, y, x + 156, y + 132, i + 1 == selectedAnimation ? accent() : 0xFF3B2D50, true);
            Bitmap thumb = customAnimImages[i] != null ? customAnimImages[i] : chars[i == 0 ? 1 : i == 1 ? 0 : i == 2 ? 2 : i == 4 ? 3 : i % 4];
            image(c, thumb, new RectF(x + 6, y + 6, x + 150, y + 76));
            text(c, (i + 1) + ". " + animNames[i], x + 8, y + 91, 7.5f, Color.WHITE, Paint.Align.LEFT);
            pButton(c, x + 8, y + 98, 66, 27, "NAME", 0xFF303444);
            pButton(c, x + 82, y + 98, 66, 27, "IMG", 0xFF303444);
        }
    }

    void editAnimationName(int slot) {
        if (slot < 0 || slot >= 8) return;
        EditText input = new EditText(appContext);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(animNames[slot]);
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(appContext)
                .setTitle("Rename Animation " + (slot + 1))
                .setMessage("Choose a name for this animation.")
                .setView(input)
                .setNegativeButton("CANCEL", (dialog, which) -> dialog.dismiss())
                .setNeutralButton("DEFAULT", (dialog, which) -> {
                    String[] defaults = {"Animation 1", "Welcome Show", "Song 1", "Song 2", "Wave", "Point", "Laugh", "Custom"};
                    animNames[slot] = defaults[slot];
                    prefs.edit().remove("animName" + slot).apply();
                    addLog("ANIMATION " + (slot + 1) + " NAME RESET");
                    invalidate();
                })
                .setPositiveButton("SAVE", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Animation " + (slot + 1);
                    if (name.length() > 24) name = name.substring(0, 24).trim();
                    animNames[slot] = name;
                    prefs.edit().putString("animName" + slot, name).apply();
                    addLog("ANIMATION " + (slot + 1) + " RENAMED: " + name);
                    invalidate();
                }).show();
    }

    void chooseWavFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Android providers label WAV files inconsistently (audio/wav, audio/x-wav,
        // audio/vnd.wave, or application/octet-stream). Use a broad picker filter
        // so valid WAV files are not greyed out by the system file browser.
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "Select a WAV audio file");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_WAV_AUDIO); }
        catch (Exception ex) { addLog("WAV PICKER ERROR: " + ex.getMessage()); status = "WAV PICKER FAILED"; }
    }

    void handleWavResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PICK_WAV_AUDIO || resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        android.net.Uri uri = data.getData();
        String pickedName = getFileName(uri);
        String pickedType = appContext.getContentResolver().getType(uri);
        boolean looksLikeWav = pickedName.toLowerCase(java.util.Locale.ROOT).endsWith(".wav")
                || (pickedType != null && pickedType.toLowerCase(java.util.Locale.ROOT).contains("wav"));
        if (!looksLikeWav) {
            status = "PLEASE SELECT A .WAV FILE";
            addLog("WAV PICKER: rejected non-WAV file " + pickedName + " (" + pickedType + ")");
            invalidate();
            return;
        }
        try { appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
        selectedWavUri = uri.toString();
        selectedWavName = pickedName;
        prefs.edit().putString("selected_wav_uri", selectedWavUri).putString("selected_wav_name", selectedWavName).apply();
        stopLocalWav();
        currentTrackName = selectedWavName;
        status = "WAV SELECTED: " + selectedWavName;
        addLog("WAV SELECTED: " + selectedWavName);
        invalidate();
    }

    String getFileName(android.net.Uri uri) {
        String name = uri.getLastPathSegment();
        try (android.database.Cursor cursor = appContext.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) { }
        return name == null || name.trim().isEmpty() ? "Selected WAV" : name;
    }

    void playLocalWav() {
        if (selectedWavUri == null) { chooseWavFile(); return; }
        stopLocalWav();
        try {
            MediaPlayer player = new MediaPlayer();
            player.setDataSource(appContext, android.net.Uri.parse(selectedWavUri));
            player.setOnPreparedListener(mp -> {
                localWavPlayer = mp;
                localWavPlaying = true;
                durationMs = mp.getDuration();
                playbackTimeMs = 0;
                mp.start();
                status = "PLAYING PHONE WAV";
                addLog("LOCAL WAV PLAYBACK STARTED");
                invalidate();
            });
            player.setOnCompletionListener(mp -> {
                localWavPlaying = false;
                playbackTimeMs = durationMs > 0 ? durationMs : playbackTimeMs;
                status = "WAV PLAYBACK COMPLETE";
                invalidate();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                localWavPlaying = false;
                status = "WAV PLAYBACK ERROR";
                addLog("WAV PLAYBACK ERROR: " + what + "/" + extra);
                invalidate();
                return true;
            });
            localWavPlayer = player;
            player.prepareAsync();
        } catch (Exception ex) {
            stopLocalWav();
            status = "WAV PLAYBACK FAILED";
            addLog("WAV PLAYBACK ERROR: " + ex.getMessage());
            showError("WAV PLAYBACK ERROR", "Could not play selected WAV", String.valueOf(ex.getMessage()));
        }
    }

    void stopLocalWav() {
        MediaPlayer player = localWavPlayer;
        localWavPlayer = null;
        localWavPlaying = false;
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) { }
            try { player.reset(); player.release(); } catch (Exception ignored) { }
        }
    }

    void chooseAnimationImage(int slot) {
        pendingImageSlot = slot;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_ANIMATION_IMAGE); }
        catch (Exception ex) { addLog("IMAGE PICKER ERROR: " + ex.getMessage()); }
    }

    void handleImageResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        android.net.Uri uri = data.getData();
        if (requestCode == PICK_CHARACTER_IMAGE && pendingCharacterSlot >= 0) {
            int slot = pendingCharacterSlot;
            try {
                appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            loadCustomCharacterImage(slot, uri);
            customCharUris[slot] = uri.toString();
            prefs.edit().putString("charImage" + slot, uri.toString()).apply();
            addLog("CUSTOM CHARACTER / STAGE IMAGE UPDATED: " + (slot + 1));
            pendingCharacterSlot = -1;
            invalidate();
            return;
        }
        if (requestCode == PICK_THEME_BACKGROUND) {
            try { appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            customBackgroundUri = uri.toString();
            themeBackgroundUris[theme] = customBackgroundUri;
            prefs.edit().putString("theme_bg_" + theme, customBackgroundUri).putString("theme_background", customBackgroundUri).apply();
            loadThemeBackground(theme, uri);
            addLog("BACKGROUND UPDATED FOR " + themeName(theme));
            invalidate(); return;
        }
        if (requestCode == PICK_HOME_MEDIA) {
            try { appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            homeCustomMediaUri = uri.toString();
            prefs.edit().putString("home_custom_media", homeCustomMediaUri).apply();
            loadHomeMedia(uri);
            addLog("HOME SCREEN PHOTO / GIF UPDATED");
            invalidate(); return;
        }
        if (requestCode != PICK_ANIMATION_IMAGE || pendingImageSlot < 0) return;
        try {
            appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        loadCustomAnimationImage(pendingImageSlot, uri);
        customAnimUris[pendingImageSlot] = uri.toString();
        prefs.edit().putString("animImage" + pendingImageSlot, uri.toString()).apply();
        addLog("CUSTOM IMAGE SET FOR ANIMATION " + (pendingImageSlot + 1));
        pendingImageSlot = -1;
        invalidate();
    }

    void loadCustomAnimationImage(int slot, android.net.Uri uri) {
        try (java.io.InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) customAnimImages[slot] = BitmapFactory.decodeStream(in);
        } catch (Exception ex) { addLog("IMAGE LOAD ERROR: SLOT " + (slot + 1)); }
    }

    void portraitHome(Canvas c) {
        portraitHeader(c, "SHOW OPERATIONS", "PIZZERIA SECURITY CONSOLE");
        text(c, "WI-FI", 270, 105, 6.5f, theme == 3 ? 0xFFFFE2AC : Color.LTGRAY, Paint.Align.LEFT);
        signalBars(c, 312, 104, phoneWifiBars(), phoneWifiBars() >= 3 ? 0xFF43D17D : 0xFFFFC857, 4, 2, 12);

        // Keep the user's selected home image/GIF, now presented as a small marquee banner.
        p.setColor(theme == 3 ? 0xFF2A120D : 0xEE101421);
        c.drawRoundRect(22, 112, 338, 190, 8, 8, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
        p.setColor(theme == 3 ? 0xFFFFC45A : accent());
        c.drawRoundRect(22.5f, 112.5f, 337.5f, 189.5f, 8, 8, p); p.setStyle(Paint.Style.FILL);
        drawHomeCustomMedia(c, new RectF(28, 118, 332, 184));

        // Four original character images, arranged for portrait screens.
        String[] cardNames = {"FREDDY", "BONNIE", "CHICA", "STAGE"};
        int[] cardXs = {22, 184, 22, 184};
        int[] cardYs = {202, 202, 282, 282};
        int onlineCount = 0; for (boolean b : online) if (b) onlineCount++;
        for (int i = 0; i < 4; i++) {
            int x = cardXs[i], y = cardYs[i];
            p.setColor(theme == 3 ? 0xFF321A13 : 0xEE101421);
            c.drawRoundRect(x, y, x + 154, y + 72, 7, 7, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f);
            p.setColor(theme == 3 ? 0xFFFFC45A : (i == page ? accent() : 0xFF353247));
            c.drawRoundRect(x + .5f, y + .5f, x + 153.5f, y + 71.5f, 7, 7, p);
            p.setStyle(Paint.Style.FILL);
            image(c, chars[i], new RectF(x + 4, y + 4, x + 62, y + 68));
            text(c, cardNames[i], x + 69, y + 22, 7.5f, theme == 3 ? 0xFFFFE9C7 : Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "● ONLINE" : "● OFFLINE", x + 69, y + 38, 6.2f,
                    online[i] ? 0xFF43D17D : red(), Paint.Align.LEFT);
            text(c, ips[i], x + 69, y + 53, 5.2f, theme == 3 ? 0xFFD4B59A : Color.LTGRAY, Paint.Align.LEFT);
        }

        // Live status panel.
        p.setColor(theme == 3 ? 0xFF26130E : 0xEE101421);
        c.drawRoundRect(22, 364, 338, 444, 8, 8, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1);
        p.setColor(theme == 3 ? 0xFF9A5A2A : 0xFF353247);
        c.drawRoundRect(22.5f, 364.5f, 337.5f, 443.5f, 8, 8, p); p.setStyle(Paint.Style.FILL);
        rect(c, 22, 364, 26, 444, onlineCount == 4 ? 0xFF43D17D : accent(), false);
        text(c, "SYSTEM STATUS", 36, 382, 7, theme == 3 ? 0xFFE0C3A2 : 0xFFB5B4C4, Paint.Align.LEFT);
        text(c, "CONTROLLERS ONLINE", 36, 400, 8.5f, Color.WHITE, Paint.Align.LEFT);
        text(c, onlineCount + " / 4", 322, 402, 18, onlineCount == 4 ? 0xFF43D17D : 0xFFFFC857, Paint.Align.RIGHT);
        int bestRssi = -127; long newestRx = 0L;
        for (int i = 0; i < 4; i++) {
            if (controllerWifiRssi[i] > bestRssi && lastWifiSeen[i] > 0L) bestRssi = controllerWifiRssi[i];
            if (lastSeen[i] > newestRx) newestRx = lastSeen[i];
        }
        String wifiSummary = bestRssi > -127 ? bestRssi + " dBm" : "N/A";
        String bottangoSummary = !lastPlaybackError.isEmpty() ? "ERROR" : playbackStateKnown ? "ONLINE" : "WAITING";
        String rxSummary = newestRx > 0L ? ageLabel(newestRx) : "NEVER";
        text(c, "WIFI " + wifiSummary + "  •  BOTTANGO " + bottangoSummary, 36, 420, 5.5f,
                theme == 3 ? 0xFFD4B59A : 0xFFB8B6C7, Paint.Align.LEFT);
        text(c, "LAST RX " + rxSummary, 36, 435, 5.2f, theme == 3 ? 0xFFD4B59A : 0xFF85899A, Paint.Align.LEFT);

        // Keep the original action hit-zones and actions exactly where they were.
        pButton(c, 24, 464, 312, 56, "▶  START SHOW", theme == 3 ? 0xFF258448 : accent());
        pButton(c, 24, 534, 312, 48, "MANAGE DEVICES", theme == 3 ? 0xFF5A2A1B : 0xFF252039);
        pButton(c, 24, 594, 312, 48, "TIMELINE / WAV", theme == 3 ? 0xFF5A2A1B : 0xFF252039);
        pButton(c, 24, 634, 312, 42, "SHOW CONTROL", theme == 3 ? 0xFF5A2A1B : 0xFF252039);
        text(c, "VOLUME  •  ESP32 POTENTIOMETER", 24, 687, 7, theme == 3 ? 0xFFE0C3A2 : Color.LTGRAY, Paint.Align.LEFT);
        volumeIndicator(c, 24, 696, 250, 9);
    }

    void portraitDevices(Canvas c) {
        portraitHeader(c, "DEVICES", "SELECT A CONTROLLER");
        for (int i = 0; i < 4; i++) {
            int y = 112 + i * 142;
            rect(c, 22, y, 338, y + 128, panel2(), false);
            rect(c, 22, y, 338, y + 128, i == page ? accent() : 0xFF354056, true);
            image(c, chars[i], new RectF(32, y + 12, 130, y + 94));
            text(c, "ESP32 — " + names[i], 143, y + 28, 12, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "● ONLINE" : "● OFFLINE", 143, y + 48, 9, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, ips[i], 143, y + 66, 8, Color.LTGRAY, Paint.Align.LEFT);
            text(c, "Playing: " + playing[i], 143, y + 84, 8, accent(), Paint.Align.LEFT);
            pButton(c, 34, y + 98, 292, 24, "OPEN CONTROLLER  ›", accent());
        }
    }

    void portraitDeviceDetail(Canvas c) {
        portraitHeader(c, "ESP32 — " + names[page], ips[page]);
        pButton(c, 22, 105, 82, 34, "‹ BACK", accent());
        image(c, chars[page], new RectF(22, 153, 150, 253));
        text(c, online[page] ? "● ONLINE" : "● OFFLINE", 170, 178, 10, online[page] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "NOW PLAYING", 170, 201, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, playing[page], 170, 222, 12, Color.WHITE, Paint.Align.LEFT);
        text(c, "VOLUME LEVEL  •  ESP32 POT", 170, 244, 7, accent(), Paint.Align.LEFT);
        volumeIndicator(c, 170, 251, 105, 9);
        text(c, "CHOOSE ANIMATION", 24, 286, 11, Color.WHITE, Paint.Align.LEFT);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 2, row = (i - 1) / 2;
            int x = 24 + col * 160, y = 304 + row * 48;
            pButton(c, x, y, 152, 39, String.format(Locale.US, "%02d  %s", i, animNames[i-1]), i == selectedAnimation ? accent() : 0xFF303444);
        }
        pButton(c, 24, 510, 150, 44, "▶ PLAY", Color.GREEN);
        pButton(c, 186, 510, 150, 44, "PAUSE N/A", 0xFF8A6B00);
        pButton(c, 24, 566, 312, 44, "↻ RESTART", accent());
        pButton(c, 24, 626, 312, 42, autoplay ? "AUTO NEXT: ON" : "AUTO NEXT: OFF", autoplay ? Color.GREEN : 0xFF303444);
    }

    void portraitTimeline(Canvas c) {
        portraitHeader(c, "TIMELINE", "BOTTANGO PLAYBACK");
        text(c, "NOW PLAYING", 26, 126, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, currentTrackName, 26, 153, 14, Color.WHITE, Paint.Align.LEFT);
        rect(c, 24, 180, 336, 330, panel2(), false);
        rect(c, 24, 180, 336, 330, accent(), true);
        for (int x = 32; x < 328; x += 4) {
            double wave = Math.sin(x * 0.12) * 35 + Math.sin(x * 0.31) * 15 + Math.sin(x * 0.61) * 7;
            p.setColor(x % 24 < 8 ? 0xFFFF1744 : accent());
            c.drawLine(x, 255, x, (float)(255 + wave), p);
        }
        if (durationMs > 0) {
            float ratio = Math.max(0f, Math.min(1f, playbackTimeMs / (float) durationMs));
            rect(c, 24, 326, 24 + 312 * ratio, 330, Color.GREEN, false);
            float markerX = 24 + 312 * ratio;
            rect(c, markerX - 1, 188, markerX + 1, 326, Color.WHITE, false);
        } else {
            rect(c, 174, 188, 176, 322, Color.WHITE, false);
        }
        String durationText = durationMs > 0 ? formatTime(durationMs) : "--:--";
        text(c, formatTime(playbackTimeMs) + "  /  " + durationText, 180, 356, 12, Color.WHITE, Paint.Align.CENTER);
        text(c, playbackStateKnown ? (bottangoPlaying ? "● PLAYING" : "● STOPPED / IDLE") : "● CONNECTING TO BOTTANGO…", 180, 376, 8,
                playbackStateKnown && bottangoPlaying ? Color.GREEN : Color.LTGRAY, Paint.Align.CENTER);

        text(c, "ADVANCED LIVE MIC METER", 24, 402, 10, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "RMS %5.1f dBFS", vuDbfs), 24, 425, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "PEAK %5.1f dBFS", vuPeakDbfs), 336, 425, 8, Color.WHITE, Paint.Align.RIGHT);
        drawAdvancedVu(c, 24, 437, vuLevel, vuPeak);
        text(c, "-60", 24, 463, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "-30", 180, 463, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "0 dBFS", 336, 463, 6, Color.LTGRAY, Paint.Align.RIGHT);
        if (vuClip) {
            rect(c, 253, 474, 336, 497, red(), false);
            text(c, "CLIP DETECTED", 294, 488, 7, Color.WHITE, Paint.Align.CENTER);
        } else {
            text(c, "PEAK HOLD  •  MIC INPUT", 180, 488, 7, Color.LTGRAY, Paint.Align.CENTER);
        }
        if (vuPermissionDenied) text(c, "MIC PERMISSION DENIED", 180, 518, 7, red(), Paint.Align.CENTER);

        // Local phone WAV controls must be on the portrait screen actually used by the app.
        pButton(c, 24, 528, 190, 44, "PICK WAV FILE", accent());
        pButton(c, 224, 528, 112, 44, localWavPlaying ? "STOP WAV" : "PLAY WAV", localWavPlaying ? red() : Color.GREEN);
        String wavLabel = selectedWavName.length() > 42 ? selectedWavName.substring(0, 41) + "…" : selectedWavName;
        text(c, wavLabel, 24, 592, 8, Color.WHITE, Paint.Align.LEFT);
        pButton(c, 24, 608, 94, 40, "−5 SEC", accent());
        pButton(c, 132, 608, 96, 40, "PAUSE N/A", 0xFF5A4B30);
        pButton(c, 242, 608, 94, 40, "+5 SEC", accent());
        text(c, "PHONE WAV PLAYBACK  •  VOLUME VIA PHONE", 24, 668, 7, Color.LTGRAY, Paint.Align.LEFT);
    }

    void drawAdvancedVu(Canvas c, int x, int y, float level, float peak) {
        int segments = 32;
        float safeLevel = Math.max(0f, Math.min(1f, level));
        float safePeak = Math.max(0f, Math.min(1f, peak));
        int active = Math.round(safeLevel * segments);
        for (int i = 0; i < segments; i++) {
            int sx = x + i * 9;
            int color = i >= 28 ? red() : i >= 23 ? 0xFFFFB52E : 0xFF45E08A;
            rect(c, sx, y, sx + 6, y + 15, i < active ? color : 0xFF252A34, false);
        }
        int peakX = x + Math.round(safePeak * (segments - 1)) * 9;
        rect(c, peakX, y - 3, peakX + 2, y + 18, Color.WHITE, false);
        // The hold marker is bright white; the bar itself shows smoothed RMS energy.
    }

    void portraitControl(Canvas c) {
        portraitHeader(c, "SHOW CONTROL", "MULTI-CONTROLLER");
        text(c, "SELECTED ANIMATION", 26, 126, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation-1]), 26, 154, 15, Color.WHITE, Paint.Align.LEFT);
        pButton(c, 24, 184, 150, 56, "▶ PLAY ALL", Color.GREEN);
        pButton(c, 186, 184, 150, 56, "PAUSE N/A", 0xFF8A6B00);
        pButton(c, 24, 254, 150, 56, "↻ RESTART", accent());
        pButton(c, 186, 254, 150, 56, "⏭ SKIP ANIM", 0xFFB02CFF);
        for (int i = 0; i < 4; i++) {
            int y = 334 + i * 76;
            rect(c, 24, y, 336, y + 62, panel2(), false);
            image(c, chars[i], new RectF(32, y + 6, 90, y + 56));
            text(c, names[i], 104, y + 24, 11, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "ONLINE" : "OFFLINE", 104, y + 44, 8, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, playing[i], 220, y + 34, 8, accent(), Paint.Align.LEFT);
        }
        pButton(c, 24, 650, 150, 42, loop ? "LOOP: ON" : "LOOP: OFF", loop ? Color.GREEN : 0xFF303444);
        pButton(c, 186, 650, 150, 42, autoplay ? "AUTO NEXT: ON" : "AUTO NEXT: OFF", autoplay ? Color.GREEN : 0xFF303444);
    }

    void editControllerAddress(int which) {
        if (which < 0 || which >= 4) return;
        EditText input = new EditText(appContext);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("e.g. 192.168.1.101");
        input.setText(ips[which]);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(appContext)
                .setTitle("ESP32 — " + names[which] + " IP Address")
                .setMessage("Enter the controller's IPv4 address.")
                .setView(input)
                .setNegativeButton("CANCEL", (dialog, id) -> dialog.dismiss())
                .setNeutralButton("DEFAULT", (dialog, id) -> {
                    ips[which] = defaultIPs[which];
                    prefs.edit().putString("ip" + which, ips[which]).apply();
                    addLog("IP UPDATED: " + names[which] + " = " + ips[which]);
                    invalidate();
                })
                .setPositiveButton("SAVE", (dialog, id) -> {
                    String candidate = input.getText().toString().trim();
                    if (isValidIPv4(candidate)) {
                        ips[which] = candidate;
                        prefs.edit().putString("ip" + which, candidate).apply();
                        addLog("IP UPDATED: " + names[which] + " = " + candidate);
                        invalidate();
                    } else {
                        new AlertDialog.Builder(appContext)
                                .setTitle("Invalid IP address")
                                .setMessage("Enter an IPv4 address such as 192.168.1.101.")
                                .setPositiveButton("OK", null)
                                .show();
                    }
                })
                .show();
    }

    boolean isValidIPv4(String value) {
        String[] parts = value.split("\\\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) return false;
            for (int i = 0; i < part.length(); i++) {
                if (!Character.isDigit(part.charAt(i))) return false;
            }
            try {
                int n = Integer.parseInt(part);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    void showThemeCustomization() {
        final String[] themes = {
                "Pizza Place — marquee", "Neon Purple", "Cyan", "Amber",
                "Alert Red", "Ice Blue", "Sunset Orange", "Pink",
                "Monochrome", "Toxic Lime"
        };
        final int[] themeIds = {3, 0, 1, 2, 4, 5, 6, 7, 8, 9};
        int selected = 0;
        for (int i = 0; i < themeIds.length; i++) {
            if (theme == themeIds[i]) { selected = i; break; }
        }
        new AlertDialog.Builder(appContext)
                .setTitle("THEME CUSTOMIZATION")
                .setSingleChoiceItems(themes, selected, (dialog, which) -> {
                    theme = themeIds[which];
                    prefs.edit().putInt("theme", theme).apply();
                    addLog("THEME CHANGED: " + themes[which]);
                    invalidate();
                })
                .setNeutralButton("MORE OPTIONS", (d, w) -> showThemeMoreOptions())
                .setPositiveButton("DONE", (d, w) -> invalidate())
                .show();
    }

    void showThemeMoreOptions() {
        final String[] options = {"CUSTOMIZE CURRENT THEME", "BACKGROUND FOR THIS THEME",
                "HOME SCREEN PHOTO / GIF", "CHARACTER IMAGES"};
        new AlertDialog.Builder(appContext).setTitle("THEME CUSTOMIZATION")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) showThemeEffectsDialog();
                    else if (which == 1) chooseThemeBackground();
                    else if (which == 2) chooseHomeMedia();
                    else showCharacterImagePicker();
                }).setNegativeButton("CANCEL", null).show();
    }

    void showCharacterImagePicker() {
        final String[] choices = {"Freddy image", "Bonnie image", "Chica image", "Stage image"};
        new AlertDialog.Builder(appContext)
                .setTitle("CHANGE CHARACTER / STAGE IMAGE")
                .setItems(choices, (dialog, which) -> chooseCharacterImage(which))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    void chooseCharacterImage(int slot) {
        if (slot < 0 || slot >= 4) return;
        pendingCharacterSlot = slot;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_CHARACTER_IMAGE); }
        catch (Exception ex) { addLog("CHARACTER IMAGE PICKER ERROR: " + ex.getMessage()); }
    }

    void loadCustomCharacterImage(int slot, android.net.Uri uri) {
        if (slot < 0 || slot >= chars.length) return;
        try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) {
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                if (bitmap != null) chars[slot] = bitmap;
            }
        } catch (Exception ex) {
            addLog("CHARACTER IMAGE LOAD FAILED: " + (slot + 1));
        }
    }

    void showThemeEffectsDialog() {
        final String[] effects = {"Theme default (unique look)", "CRT scanlines",
                "Glitch / signal tearing", "Security camera static", "Neon glow pulse", "No extra effects"};
        final int[] selected = {themeEffects[Math.max(0, Math.min(9, theme))]};
        new AlertDialog.Builder(appContext).setTitle("CUSTOMIZE " + themeName(theme))
                .setSingleChoiceItems(effects, selected[0], (dialog, which) -> {
                    selected[0] = which;
                    themeEffects[theme] = which;
                    prefs.edit().putInt("theme_effect_" + theme, which).apply();
                    invalidate();
                })
                .setNeutralButton("BACKGROUND", (d, w) -> chooseThemeBackground())
                .setPositiveButton("DONE", (d, w) -> {
                    themeEffects[theme] = selected[0];
                    prefs.edit().putInt("theme_effect_" + theme, selected[0]).apply();
                    invalidate();
                }).show();
    }

    String themeName(int id) {
        String[] names = {"Neon Purple", "Cyan", "Amber", "Pizza Place",
                "Alert Red", "Ice Blue", "Sunset Orange", "Pink", "Monochrome", "Toxic Lime"};
        return names[Math.max(0, Math.min(names.length - 1, id))];
    }

    void chooseThemeBackground() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_THEME_BACKGROUND); }
        catch (Exception ex) { addLog("BACKGROUND PICKER ERROR: " + ex.getMessage()); }
    }

    void loadThemeBackground(int themeId, android.net.Uri uri) {
        if (themeId < 0 || themeId >= themeBackgrounds.length) return;
        try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) {
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                if (bitmap != null) themeBackgrounds[themeId] = bitmap;
            }
        } catch (Exception ex) { addLog("THEME BACKGROUND LOAD FAILED: " + themeId); }
    }

    void chooseHomeMedia() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_HOME_MEDIA); }
        catch (Exception ex) { addLog("HOME MEDIA PICKER ERROR: " + ex.getMessage()); }
    }

    void loadHomeMedia(android.net.Uri uri) {
        homeCustomBitmap = null;
        homeCustomMovie = null;
        try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) homeCustomMovie = Movie.decodeStream(in);
        } catch (Exception ignored) { }
        if (homeCustomMovie == null) {
            try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
                if (in != null) homeCustomBitmap = BitmapFactory.decodeStream(in);
            } catch (Exception ex) { addLog("HOME MEDIA LOAD FAILED"); }
        }
        homeCustomMovieStartedAt = android.os.SystemClock.uptimeMillis();
    }

    void drawHomeCustomMedia(Canvas c, RectF box) {
        if (homeCustomMovie != null && homeCustomMovie.width() > 0 && homeCustomMovie.height() > 0) {
            int duration = Math.max(1, homeCustomMovie.duration());
            homeCustomMovie.setTime((int)((android.os.SystemClock.uptimeMillis() - homeCustomMovieStartedAt) % duration));
            float fit = Math.min(box.width() / homeCustomMovie.width(), box.height() / homeCustomMovie.height());
            float dw = homeCustomMovie.width() * fit, dh = homeCustomMovie.height() * fit;
            c.save(); c.clipRect(box);
            c.translate(box.centerX() - dw / 2f, box.centerY() - dh / 2f);
            c.scale(fit, fit); homeCustomMovie.draw(c, 0, 0); c.restore();
            if (screen == HOME) postInvalidateDelayed(40);
        } else if (homeCustomBitmap != null && !homeCustomBitmap.isRecycled()) {
            image(c, homeCustomBitmap, box);
        } else if (menuGif != null) {
            int duration = Math.max(1, menuGif.duration());
            if (menuGifStartedAt < 0) menuGifStartedAt = android.os.SystemClock.uptimeMillis();
            menuGif.setTime((int)((android.os.SystemClock.uptimeMillis() - menuGifStartedAt) % duration));
            float fit = Math.min(box.width() / menuGif.width(), box.height() / menuGif.height());
            float dw = menuGif.width() * fit, dh = menuGif.height() * fit;
            c.save(); c.clipRect(box);
            c.translate(box.centerX() - dw / 2f, box.centerY() - dh / 2f);
            c.scale(fit, fit); menuGif.draw(c, 0, 0); c.restore();
            if (screen == HOME) postInvalidateDelayed(40);
        } else image(c, chars[0], box);
    }

    void drawThemeEffects(Canvas c) {
        int effect = (theme >= 0 && theme < themeEffects.length) ? themeEffects[theme] : 0;
        if (effect == 5) return;
        boolean crt = effect == 1 || (effect == 0 && (theme == 3 || theme == 8));
        boolean glitch = effect == 2 || (effect == 0 && (theme == 0 || theme == 4));
        boolean staticNoise = effect == 3 || (effect == 0 && theme == 9);
        boolean neon = effect == 4 || (effect == 0 && (theme == 1 || theme == 5 || theme == 7));
        if (crt || (effect == 0 && scanlinesEnabled)) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(0x183CFF82);
            for (int y = 2; y < 800; y += 5) c.drawLine(0, y, 360, y, p);
            p.setStyle(Paint.Style.FILL);
        }
        if (glitch && (System.currentTimeMillis() / 700L) % 11L == 0L) {
            p.setColor(0x24FFFFFF); c.drawRect(0, 245, 360, 251, p);
            p.setColor((accent() & 0x00FFFFFF) | 0x33000000); c.drawRect(8, 498, 352, 503, p);
        }
        if (staticNoise && (System.currentTimeMillis() / 350L) % 3L == 0L) {
            p.setColor(0x18FFFFFF);
            for (int i = 0; i < 28; i++) {
                float y = (i * 29 + (System.currentTimeMillis() / 40L) % 29) % 800;
                int x = (i * 47) % 340; c.drawRect(x, y, x + 18, y + 1, p);
            }
        }
        if (neon) {
            int alpha = 0x18 + (int)(Math.abs(Math.sin(System.currentTimeMillis() / 500.0)) * 0x20);
            p.setColor((alpha << 24) | (accent() & 0x00FFFFFF));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f);
            c.drawRoundRect(15, 100, 345, 720, 18, 18, p); p.setStyle(Paint.Style.FILL);
        }
    }

    void portraitSettings(Canvas c) {
        portraitHeader(c, "SETTINGS", "NETWORK + STATUS");
        text(c, "TAP ADDRESS TO EDIT  •  TEST TO PING", 24, 124, 9, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            int y = 140 + i * 82;
            rect(c, 24, y, 336, y + 68, panel2(), false);
            text(c, names[i], 36, y + 24, 11, Color.WHITE, Paint.Align.LEFT);
            text(c, ips[i], 36, y + 45, 9, Color.LTGRAY, Paint.Align.LEFT);
            pButton(c, 242, y + 16, 80, 36, "TEST", accent());
        }
        rect(c, 24, 475, 336, 531, panel2(), false);
        text(c, "AUDIO OUTPUT  •  SELECT ONE MODE", 32, 490, 7.2f, Color.LTGRAY, Paint.Align.LEFT);
        pButton(c, 28, 497, 96, 28, audioOutputMode == 0 ? "MAX ONLY ✓" : "MAX ONLY", audioOutputMode == 0 ? accent() : 0xFF303444);
        pButton(c, 132, 497, 96, 28, audioOutputMode == 1 ? "BOTH ✓" : "BOTH", audioOutputMode == 1 ? accent() : 0xFF303444);
        pButton(c, 236, 497, 96, 28, audioOutputMode == 2 ? "PHONE ✓" : "PHONE", audioOutputMode == 2 ? accent() : 0xFF303444);
        text(c, phoneAudioStatus, 32, 542, 8, audioOutputMode == 0 ? Color.LTGRAY : 0xFFFFC857, Paint.Align.LEFT);
        text(c, "VOLUME IS READ-ONLY", 24, 558, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "% — SYNCED FROM ESP32" : "WAITING FOR ESP32", 24, 576, 8, Color.WHITE, Paint.Align.LEFT);
        volumeIndicator(c, 24, 581, 245, 7);
        pButton(c, 24, 590, 312, 38, "THEMES  •  IMAGES  •  EFFECTS", accent());
        pButton(c, 24, 638, 100, 42, "DIAGNOSTICS", accent());
        pButton(c, 130, 638, 100, 42, "DEBUG LOG", 0xFF303444);
        pButton(c, 236, 638, 100, 42, "CLEAR LOG", red());
    }

    String ageLabel(long timestamp) {
        if (timestamp <= 0L) return "NEVER";
        long seconds = Math.max(0L, (System.currentTimeMillis() - timestamp) / 1000L);
        return seconds < 2 ? "JUST NOW" : seconds + "s AGO";
    }

    void portraitDiagnostics(Canvas c) {
        portraitHeader(c, "SECURITY DIAGNOSTICS", "LIVE SYSTEM HEALTH");
        int onlineCount = 0;
        for (boolean connected : online) if (connected) onlineCount++;
        rect(c, 22, 110, 338, 210, panel2(), false);
        text(c, "SYSTEM STATUS", 32, 130, 8, accent(), Paint.Align.LEFT);
        text(c, "ESP32 NETWORK: " + onlineCount + " / 4 ONLINE", 32, 151, 9,
                onlineCount == 4 ? Color.GREEN : onlineCount > 0 ? 0xFFFFC857 : red(), Paint.Align.LEFT);
        String phoneWifi = phoneWifiRssi > -127 ? phoneWifiRssi + " dBm" : "UNAVAILABLE";
        text(c, "PHONE WI-FI: " + phoneWifi, 32, 171, 8, Color.WHITE, Paint.Align.LEFT);
        String botStatus = !lastPlaybackError.isEmpty() ? "ERROR" : playbackStateKnown ? "RESPONDING" : "WAITING";
        int botColor = !lastPlaybackError.isEmpty() ? red() : playbackStateKnown ? Color.GREEN : 0xFFFFC857;
        text(c, "BOTTANGO: " + botStatus, 32, 190, 8, botColor, Paint.Align.LEFT);
        text(c, "LAST PLAYBACK STATE: " + ageLabel(lastPlaybackPollAt), 32, 202, 6.5f, Color.LTGRAY, Paint.Align.LEFT);

        for (int i = 0; i < 4; i++) {
            int y = 220 + i * 88;
            rect(c, 22, y, 338, y + 78, panel2(), false);
            text(c, names[i] + "  //  " + (online[i] ? "ONLINE" : "OFFLINE"), 32, y + 20, 9,
                    online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, ips[i], 32, y + 39, 8, Color.LTGRAY, Paint.Align.LEFT);
            text(c, "LAST RX: " + ageLabel(lastSeen[i]), 32, y + 57, 7, Color.WHITE, Paint.Align.LEFT);
            int rssi = controllerWifiRssi[i];
            String wifi = lastWifiSeen[i] > 0 && rssi > -127 ? rssi + " dBm" : "N/A";
            text(c, "WI-FI " + wifi, 326, y + 39, 7, rssi >= -67 ? Color.GREEN : rssi > -90 ? 0xFFFFC857 : Color.LTGRAY, Paint.Align.RIGHT);
        }
        if (!lastPlaybackError.isEmpty()) {
            String err = "BOT ERROR: " + lastPlaybackError;
            if (err.length() > 48) err = err.substring(0, 48);
            text(c, err, 24, 584, 7, red(), Paint.Align.LEFT);
        } else {
            text(c, "DIAGNOSTICS ARE READ-ONLY — NO SHOW COMMANDS", 24, 584, 6.5f, Color.LTGRAY, Paint.Align.LEFT);
        }
        pButton(c, 24, 610, 98, 44, "PING ESP32", accent());
        pButton(c, 131, 610, 98, 44, "REFRESH BOT", 0xFF303444);
        pButton(c, 238, 610, 98, 44, "OPEN DEBUG", 0xFF303444);
    }

    void portraitDebug(Canvas c) {
        portraitHeader(c, "DEBUG", "WIRELESS SERIAL MONITOR");
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, "RX 4211  •  TX 4210  •  " + on + "/4 ONLINE", 24, 120, 9, Color.LTGRAY, Paint.Align.LEFT);
        rect(c, 22, 136, 338, 266, panel2(), false);
        text(c, "BOTTANGO PLAYBACK DIAGNOSTICS", 32, 156, 8, accent(), Paint.Align.LEFT);
        String connection = !lastPlaybackError.isEmpty() ? "ERROR: " + lastPlaybackError : playbackStateKnown ? "CONNECTED / STATE RECEIVED" : "WAITING FOR FIRST RESPONSE";
        text(c, connection, 32, 176, 7, !lastPlaybackError.isEmpty() ? red() : playbackStateKnown ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "ANIMATION: " + String.format(Locale.US, "%02d", selectedAnimation) + "  " + animNames[selectedAnimation - 1], 32, 195, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "PLAYBACK: " + (bottangoPlaying ? "PLAYING" : playbackStateKnown ? "STOPPED / IDLE" : "UNKNOWN"), 32, 213, 7, bottangoPlaying ? Color.GREEN : Color.LTGRAY, Paint.Align.LEFT);
        text(c, "TIME: " + formatTime(playbackTimeMs) + " / " + (durationMs > 0 ? formatTime(durationMs) : "DURATION UNKNOWN"), 32, 231, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "AUTO NEXT: " + (autoplay ? "ON" : "OFF") + "  •  LOOP: " + (loop ? "ON" : "OFF"), 32, 249, 7, Color.LTGRAY, Paint.Align.LEFT);
        rect(c, 22, 276, 338, 640, panel2(), false);
        text(c, "EVENT LOG", 30, 294, 7, accent(), Paint.Align.LEFT);
        int start = Math.max(0, log.size() - 18), y = 314;
        for (int i = start; i < log.size(); i++) {
            String line = log.get(i);
            if (line.length() > 46) line = line.substring(0, 46);
            text(c, line, 30, y, 7, Color.LTGRAY, Paint.Align.LEFT);
            y += 19;
        }
        pButton(c, 24, 660, 96, 42, "CLEAR", red());
        pButton(c, 132, 660, 96, 42, "STATUS", accent());
        pButton(c, 240, 660, 96, 42, "TEST ALL", Color.GREEN);
    }

    void portraitErrorPopup(Canvas c) {
        rect(c, 0, 0, 360, 800, 0xDD000000, false);
        rect(c, 22, 270, 338, 530, 0xFF10050A, false);
        rect(c, 22, 270, 338, 530, red(), true);
        text(c, "⚠ SYSTEM ERROR", 180, 310, 17, red(), Paint.Align.CENTER);
        text(c, errorTitle, 180, 350, 12, Color.WHITE, Paint.Align.CENTER);
        text(c, errorMessage, 180, 385, 10, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "Open DEBUG for details", 180, 420, 9, Color.LTGRAY, Paint.Align.CENTER);
        pButton(c, 34, 455, 90, 44, "RETRY", accent());
        pButton(c, 135, 455, 90, 44, "DETAILS", Color.WHITE);
        pButton(c, 236, 455, 90, 44, "CLOSE", red());
    }

    void image(Canvas c, Bitmap b, RectF dst) {
        if (b == null) return;
        Rect src = new Rect(0, 0, b.getWidth(), b.getHeight());
        c.drawBitmap(b, src, dst, p);
    }

    void drawHome(Canvas c) {
        title(c, "HOME", "WIRELESS SHOW CONTROL");
        image(c, chars[0], new RectF(15, 50, 230, 178));
        text(c, "FAZBEAR", 245, 74, 22, Color.WHITE, Paint.Align.LEFT);
        text(c, "CONTROL", 245, 98, 22, red(), Paint.Align.LEFT);
        text(c, "4 ESP32 CONTROLLERS", 245, 119, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "PHONE WI-FI", 375, 119, 6, Color.LTGRAY, Paint.Align.LEFT);
        signalBars(c, 427, 127, phoneWifiBars(), phoneWifiBars() >= 3 ? 0xFF43D17D : 0xFFFFC857, 4, 2, 12);
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, on + " / 4 ONLINE", 245, 137, 12, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        button(c, 245, 148, 105, 31, "START SHOW", accent());
        button(c, 360, 148, 105, 31, "DEBUG", Color.DKGRAY);

        button(c, 15, 190, 106, 42, "DEVICES", accent());
        button(c, 130, 190, 106, 42, "TIMELINE", accent());
        button(c, 245, 190, 106, 42, "CONTROL", accent());
        button(c, 360, 190, 105, 42, "SETTINGS", accent());
        text(c, "PHYSICAL ESP32 POTENTIOMETER = VOLUME SOURCE", 240, 250, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, status, 240, 265, 6, Color.WHITE, Paint.Align.CENTER);
        for (int i = 0; i < 4; i++) {
            float sx = 90 + i * 88;
            text(c, names[i], sx + 12, 278, 6, Color.LTGRAY, Paint.Align.CENTER);
            int wifiBars = controllerWifiBars(i);
            int wifiColor = wifiBars >= 3 ? 0xFF43D17D : (wifiBars > 0 ? 0xFFFFC857 : 0xFF454754);
            signalBars(c, sx, 299, wifiBars, wifiColor, 4, 2, 12);
        }
        // Tiny live diagnostics line on the home/menu screen.
        int bestRssi = -127;
        long newestRx = 0L;
        for (int i = 0; i < 4; i++) {
            if (controllerWifiRssi[i] > bestRssi && lastWifiSeen[i] > 0L) bestRssi = controllerWifiRssi[i];
            if (lastSeen[i] > newestRx) newestRx = lastSeen[i];
        }
        String wifiSummary = bestRssi > -127 ? bestRssi + " dBm" : "N/A";
        String bottangoSummary = !lastPlaybackError.isEmpty() ? "ERROR" : playbackStateKnown ? "ONLINE" : "WAITING";
        String rxSummary = newestRx > 0L ? ageLabel(newestRx) : "NEVER";
        text(c, "SYS " + on + "/4  |  WIFI " + wifiSummary + "  |  BOTTANGO " + bottangoSummary,
                240, 326, 5.5f, 0xFFB8B6C7, Paint.Align.CENTER);
        text(c, "LAST ESP32 RX: " + rxSummary, 240, 337, 5.5f, 0xFF85899A, Paint.Align.CENTER);
        nav(c, HOME);
    }

    void deviceCard(Canvas c, int i, int y) {
        int a = i == page ? accent() : 0xFF263044;
        rect(c, 10, y, 470, y + 48, panel2(), false);
        rect(c, 10, y, 470, y + 48, a, true);
        image(c, chars[i], new RectF(16, y + 4, 68, y + 44));
        text(c, "ESP32 - " + names[i], 78, y + 15, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, ips[i], 78, y + 28, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, online[i] ? "● ONLINE" : "● OFFLINE", 78, y + 40, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "Playing: " + playing[i], 205, y + 16, 6.5f, Color.WHITE, Paint.Align.LEFT);
        text(c, "Animation " + String.format(Locale.US, "%02d", i == 3 ? 5 : selectedAnimation), 205, y + 29, 6, accent(), Paint.Align.LEFT);
        button(c, 372, y + 7, 45, 30, "PLAY", Color.GREEN);
        button(c, 423, y + 7, 40, 30, "…", a);
    }

    void drawDevices(Canvas c) {
        title(c, "DEVICES", "4 ESP32 CONTROLLERS");
        for (int i = 0; i < 4; i++) deviceCard(c, i, 47 + i * 51);
        text(c, "TAP A DEVICE FOR ANIMATIONS + PLAYBACK", 240, 262, 5.5f, Color.LTGRAY, Paint.Align.CENTER);
        nav(c, DEVICES);
    }

    void drawDeviceDetail(Canvas c) {
        title(c, "ESP32 - " + names[page], ips[page]);
        button(c, 10, 48, 55, 26, "BACK", accent());
        image(c, chars[page], new RectF(75, 48, 175, 112));
        text(c, online[page] ? "● ONLINE" : "● OFFLINE", 190, 61, 7, online[page] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "NOW PLAYING", 190, 78, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, playing[page], 190, 94, 11, Color.WHITE, Paint.Align.LEFT);
        text(c, "VOLUME  " + (syncedVolume >= 0 ? syncedVolume + "%" : "--%") + "  •  ESP32 POT", 190, 108, 6, Color.LTGRAY, Paint.Align.LEFT);

        text(c, "ANIMATIONS", 12, 132, 8, accent(), Paint.Align.LEFT);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 4, row = (i - 1) / 4;
            int x = 12 + col * 116, y = 140 + row * 30;
            button(c, x, y, 105, 23, String.format(Locale.US, "%02d  %s", i, animNames[i - 1]), i == selectedAnimation ? accent() : 0xFF303444);
        }
        button(c, 12, 205, 92, 29, "PLAY", Color.GREEN);
        button(c, 112, 205, 92, 29, "PAUSE", Color.YELLOW);
        button(c, 212, 205, 92, 29, "RESTART", accent());
        button(c, 312, 205, 56, 29, "BACK", 0xFF303444);
        text(c, "AUTOPLAY NEXT", 15, 252, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, autoplay ? "ON" : "OFF", 110, 252, 7, autoplay ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "UDP 4210", 470, 252, 6, Color.LTGRAY, Paint.Align.RIGHT);
    }

    void drawTimeline(Canvas c) {
        title(c, "TIMELINE", "AUDIO PLAYBACK");
        text(c, "NOW PLAYING", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, currentTrackName, 15, 73, 9, Color.WHITE, Paint.Align.LEFT);
        rect(c, 12, 84, 392, 146, panel2(), false);
        rect(c, 12, 84, 392, 146, accent(), true);
        p.setStrokeWidth(2);
        for (int x = 16; x < 390; x += 4) {
            double wave = Math.sin(x * 0.12) * 13 + Math.sin(x * 0.31) * 6 + Math.sin(x * 0.61) * 3;
            p.setColor(x % 24 < 8 ? 0xFFFF1744 : accent());
            c.drawLine(x, 115, x, (float)(115 + wave), p);
        }
        rect(c, 188, 86, 190, 144, Color.WHITE, false);
        text(c, formatTime(playbackTimeMs) + " / " + (durationMs > 0 ? formatTime(durationMs) : "--:--"), 202, 160, 7, Color.WHITE, Paint.Align.CENTER);
        text(c, "L", 420, 92, 6, Color.WHITE, Paint.Align.CENTER);
        text(c, "R", 458, 92, 6, Color.WHITE, Paint.Align.CENTER);
        for (int i = 0; i < 8; i++) {
            int h = 12 + (i % 5) * 5;
            rect(c, 415, 142 - h, 430, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
            rect(c, 448, 142 - h, 463, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
        }
        button(c, 35, 170, 65, 30, "-5s", accent());
        button(c, 108, 170, 80, 30, "◀◀", accent());
        button(c, 198, 166, 44, 38, "N/A", 0xFF5A4B30);
        button(c, 252, 170, 80, 30, "▶▶", accent());
        button(c, 340, 170, 65, 30, "+5s", accent());
        text(c, "CURRENT EVENT", 15, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "Freddy Move", 15, 238, 9, Color.WHITE, Paint.Align.LEFT);
        text(c, "00:45", 120, 238, 7, accent(), Paint.Align.LEFT);
        button(c, 18, 275, 150, 42, "PICK WAV", accent());
        button(c, 180, 275, 75, 42, localWavPlaying ? "STOP" : "PLAY", localWavPlaying ? red() : Color.GREEN);
        String wavLabel = selectedWavName.length() > 26 ? selectedWavName.substring(0, 25) + "…" : selectedWavName;
        text(c, wavLabel, 18, 333, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "PHONE WAV PLAYBACK", 18, 350, 5.5f, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "PHYSICAL VOLUME", 280, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%" : "WAITING", 280, 238, 10, Color.WHITE, Paint.Align.LEFT);
        nav(c, TIMELINE);
    }

    void drawControl(Canvas c) {
        title(c, "SHOW CONTROL", "MULTI-ESP32");
        text(c, "SELECTED ANIMATION", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation - 1]), 15, 76, 12, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 92, 106, 40, "PLAY ALL", Color.GREEN);
        button(c, 129, 92, 106, 40, "PAUSE ALL", Color.YELLOW);
        button(c, 243, 92, 108, 40, "RESTART", accent());
        for (int i = 0; i < 4; i++) {
            int x = 15 + (i % 2) * 230, y = 145 + (i / 2) * 48;
            rect(c, x, y, x + 215, y + 40, panel2(), false);
            text(c, names[i], x + 10, y + 15, 7, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "ONLINE" : "OFFLINE", x + 10, y + 29, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, playing[i], x + 85, y + 22, 7, accent(), Paint.Align.LEFT);
        }
        button(c, 15, 243, 140, 25, loop ? "LOOP ON" : "LOOP OFF", loop ? Color.GREEN : Color.DKGRAY);
        button(c, 165, 243, 140, 25, autoplay ? "AUTO NEXT ON" : "AUTO NEXT OFF", autoplay ? Color.GREEN : Color.DKGRAY);
        nav(c, CONTROL);
    }

    void drawSettings(Canvas c) {
        title(c, "SETTINGS", "APP + CONTROLLER STATUS");
        text(c, "CONTROLLER IP ADDRESSES", 15, 57, 7, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            int y = 65 + i * 40;
            text(c, names[i], 15, y + 17, 7, Color.WHITE, Paint.Align.LEFT);
            rect(c, 92, y, 280, y + 27, panel2(), false);
            text(c, ips[i], 102, y + 18, 7, Color.WHITE, Paint.Align.LEFT);
            button(c, 292, y, 75, 27, "TEST", accent());
            text(c, online[i] ? "ONLINE" : "OFFLINE", 382, y + 17, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        }
        text(c, "VOLUME IS READ-ONLY", 15, 239, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%  •  SYNCED FROM ESP32 POT" : "WAITING FOR ESP32", 160, 239, 6, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 250, 110, 25, theme == 0 ? "NEON PURPLE" : "CYAN THEME", accent());
        button(c, 135, 250, 110, 25, "DEBUG", Color.DKGRAY);
        button(c, 255, 250, 110, 25, "CLEAR LOG", red());
        nav(c, SETTINGS);
    }

    void drawDebug(Canvas c) {
        title(c, "DEBUG", "WIRELESS SERIAL + DIAGNOSTICS");
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, "UDP RX 4211", 12, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "UDP TX 4210", 110, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, on + "/4 ONLINE", 220, 56, 7, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "VOLUME " + (syncedVolume >= 0 ? syncedVolume + "%" : "WAITING"), 330, 56, 7, Color.WHITE, Paint.Align.LEFT);
        rect(c, 10, 64, 470, 242, panel2(), false);
        String playbackConn = !lastPlaybackError.isEmpty() ? "ERROR " + lastPlaybackError : playbackStateKnown ? "CONNECTED" : "WAITING";
        text(c, "BOTTANGO: " + playbackConn + "  •  " + (bottangoPlaying ? "PLAYING" : "STOPPED"), 16, 79, 6, !lastPlaybackError.isEmpty() ? red() : playbackStateKnown ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "ANIM " + String.format(Locale.US, "%02d", selectedAnimation) + " " + animNames[selectedAnimation - 1] + "  •  " + formatTime(playbackTimeMs) + "/" + (durationMs > 0 ? formatTime(durationMs) : "--:--"), 16, 93, 6, Color.WHITE, Paint.Align.LEFT);
        text(c, "AUTO NEXT " + (autoplay ? "ON" : "OFF") + "  •  LOOP " + (loop ? "ON" : "OFF"), 16, 107, 6, Color.LTGRAY, Paint.Align.LEFT);
        int start = Math.max(0, log.size() - 8), y = 125;
        for (int i = start; i < log.size(); i++) {
            String s = log.get(i);
            if (s.length() > 74) s = s.substring(0, 74);
            text(c, s, 16, y, 5.5f, Color.LTGRAY, Paint.Align.LEFT);
            y += 15;
        }
        button(c, 12, 248, 95, 25, "CLEAR", red());
        button(c, 115, 248, 95, 25, "STATUS", accent());
        button(c, 218, 248, 110, 25, "TEST ALL", Color.GREEN);
        text(c, "ERROR POPUP: READY", 345, 264, 5.5f, errorPopup ? red() : Color.GREEN, Paint.Align.CENTER);
        nav(c, DEBUG);
    }

    void drawErrorPopup(Canvas c) {
        rect(c, 0, 0, 480, 320, 0x99000000, false);
        int l = 42, t = 67, r = 438, b = 252;
        rect(c, l, t, r, b, 0xFF10050A, false);
        rect(c, l, t, r, b, red(), true);
        text(c, "⚠  SYSTEM ERROR", 240, 92, 13, red(), Paint.Align.CENTER);
        text(c, errorTitle, 240, 116, 9, Color.WHITE, Paint.Align.CENTER);
        text(c, errorMessage, 240, 139, 8, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "Details are available in DEBUG.", 240, 160, 6, Color.LTGRAY, Paint.Align.CENTER);
        button(c, 62, 191, 100, 34, "RETRY", accent());
        button(c, 190, 191, 100, 34, "DETAILS", Color.WHITE);
        button(c, 318, 191, 100, 34, "CLOSE", red());
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;
        float scale = Math.min(getWidth() / 360f, getHeight() / 800f);
        float ox = (getWidth() - 360f * scale) / 2f;
        float oy = (getHeight() - 800f * scale) / 2f;
        float x = (e.getX() - ox) / scale;
        float y = (e.getY() - oy) / scale;
        if (x < 0 || x > 360 || y < 0 || y > 800) return true;

        if (errorPopup) {
            if (y >= 450 && y <= 510) {
                if (x < 130) retryError();
                else if (x < 230) { errorPopup = false; screen = DEBUG; }
                else errorPopup = false;
            }
            invalidate(); return true;
        }

        if (screen == DEVICE_DETAIL) {
            if (y >= 100 && y < 145) { screen = DEVICES; invalidate(); return true; }
            if (y >= 300 && y < 500) {
                int col = x < 180 ? 0 : 1;
                int row = (int)((y - 304) / 48);
                int a = row * 2 + col + 1;
                if (a >= 1 && a <= 8) { selectedAnimation = a; invalidate(); return true; }
            }
            if (y >= 505 && y < 560) {
                if (x < 180) play(page, selectedAnimation);
                else { send(page, "[PAUSE]"); status = "PAUSED"; }
            } else if (y >= 560 && y < 615) {
                send(page, "[RESTART]");
                status = "RESTARTED";
            } else if (y >= 620 && y < 680) autoplay = !autoplay;
            invalidate(); return true;
        }

        if (y >= 720) {
            int n = Math.max(0, Math.min(4, (int)((x - 14) / 66)));
            int[] screens = {HOME, DEVICES, ANIMATIONS, CONTROL, SETTINGS};
            screen = screens[n]; invalidate(); return true;
        }

        if (screen == HOME) {
            if (y >= 450 && y < 520) { playAll(); screen = CONTROL; }
            else if (y >= 525 && y < 580) screen = DEVICES;
            else if (y >= 585 && y < 640) { screen = TIMELINE; ensureVuPermission(); }
            else if (y >= 645 && y < 705) screen = CONTROL;
        } else if (screen == DEVICES) {
            if (y >= 112 && y < 680) {
                int i = (int)((y - 112) / 142);
                if (i >= 0 && i < 4) { page = i; screen = DEVICE_DETAIL; }
            }
        } else if (screen == ANIMATIONS) {
            if (y >= 112 && y < 692) {
                int col = x < 180 ? 0 : 1;
                int row = (int)((y - 112) / 145);
                int a = row * 2 + col + 1;
                if (a >= 1 && a <= 8) {
                    selectedAnimation = a;
                    int cardX = col == 0 ? 20 : 184;
                    float localX = x - cardX;
                    int cardY = 112 + row * 145;
                    // The Animations tab is for selecting and customizing slots only.
                    // Playback remains available from the dedicated Control screen.
                    if (y >= cardY + 98 && y < cardY + 129) {
                        if (localX >= 78) chooseAnimationImage(a - 1);
                        else if (localX >= 4) editAnimationName(a - 1);
                    }
                }
            }
        } else if (screen == TIMELINE) {
            if (y >= 528 && y < 574) {
                if (x < 218) chooseWavFile();
                else if (localWavPlaying) stopLocalWav();
                else playLocalWav();
            } else if (y >= 608 && y < 650) {
                if (x < 125) seekBy(-5000);
                else if (x >= 235) seekBy(5000);
                else status = "PAUSE NOT SUPPORTED BY BOTTANGO";
            } else if (y >= 180 && y < 330) {
                if (durationMs > 0) {
                    float ratio = Math.max(0f, Math.min(1f, (x - 24f) / 312f));
                    seekTo((int)(durationMs * ratio));
                } else {
                    status = "TIMELINE DURATION NOT PROVIDED BY BOTTANGO";
                }
            } else if (y >= 400 && y < 528) {
                ensureVuPermission();
            }
        } else if (screen == CONTROL) {
            if (y >= 180 && y < 245) {
                if (x < 180) playAll();
                else status = "PAUSE NOT SUPPORTED BY BOTTANGO";
            } else if (y >= 250 && y < 315) {
                if (x < 180) restartShow(); else skipAnimation();
            } else if (y >= 645 && y < 705) {
                if (x < 180) loop = !loop; else autoplay = !autoplay;
            }
        } else if (screen == SETTINGS) {
            if (y >= 140 && y < 468) {
                int i = (int)((y - 140) / 82);
                if (i >= 0 && i < 4) {
                    if (x >= 225) send(i, "[STATUS]");
                    else editControllerAddress(i);
                }
            } else if (y >= 492 && y < 532) {
                if (x < 128) selectAudioOutput(0);
                else if (x < 232) selectAudioOutput(1);
                else selectAudioOutput(2);
            } else if (y >= 590 && y < 630) showThemeCustomization();
            else if (y >= 638 && y < 686) {
                if (x < 125) screen = DIAGNOSTICS;
                else if (x < 235) screen = DEBUG;
                else log.clear();
            }
        } else if (screen == DIAGNOSTICS) {
            if (y >= 605 && y < 670) {
                if (x < 125) {
                    for (int i = 0; i < 4; i++) send(i, "[STATUS]");
                    status = "DIAGNOSTIC STATUS REQUEST SENT";
                    addLog("DIAGNOSTICS // STATUS REQUEST SENT TO ALL CONTROLLERS");
                } else if (x < 235) {
                    pollBottangoState();
                    addLog("DIAGNOSTICS // BOTTANGO STATE REFRESH REQUESTED");
                } else {
                    screen = DEBUG;
                }
            }
        } else if (screen == DEBUG) {
            if (y >= 655 && y < 710) {
                if (x < 125) log.clear();
                else if (x < 235) for (int i = 0; i < 4; i++) send(i, "[STATUS]");
                else broadcast("[STATUS]");
            }
        }
        invalidate(); return true;
    }

    boolean touchDeviceDetail(float x, float y) {
        if (y >= 48 && y <= 78 && x < 70) { screen = DEVICES; invalidate(); return true; }
        if (y >= 140 && y < 200) {
            int col = (int)((x - 12) / 116), row = (int)((y - 140) / 30);
            if (col >= 0 && col < 4 && row >= 0 && row < 2) {
                int a = row * 4 + col + 1;
                selectedAnimation = a;
                play(page, a);
                invalidate(); return true;
            }
        }
        if (y >= 205 && y < 240) {
            if (x < 104) { play(page, selectedAnimation); }
            else if (x < 204) { send(page, "[PAUSE]"); status = "PAUSED " + names[page]; }
            else if (x < 304) { send(page, "[RESTART]"); progress[page] = 0; status = "RESTARTED " + names[page]; }
            else { screen = DEVICES; }
            invalidate(); return true;
        }
        if (y >= 240 && y < 270 && x < 160) { autoplay = !autoplay; invalidate(); return true; }
        return true;
    }
}
