package com.fazbear.control;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.app.AlarmManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.InputType;
import android.widget.EditText;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import org.json.JSONObject;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.net.wifi.WifiManager;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    // Lets the background alarm avoid starting a second copy of the WAV while
    // the foreground scheduled-show screen is already handling playback.
    static volatile boolean appVisible = false;
    static boolean isAppVisible() { return appVisible; }

    @Override protected void onResume() {
        super.onResume();
        appVisible = true;
    }

    @Override protected void onPause() {
        appVisible = false;
        super.onPause();
    }

    FazbearView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        // Keep the phone display awake for as long as Fazbear Control is running.
        // This prevents the screen from timing out during Bottango shows/scheduled shows.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 9001);
        }
        view = new FazbearView(this);
        view.setKeepScreenOn(true);
        setContentView(view);
        if (getIntent() != null && getIntent().getBooleanExtra("OPEN_FAZBEAR_DEBUG", false)) view.openDebugFromNotification();
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (view != null) view.invalidate();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (view != null && intent.getBooleanExtra("OPEN_FAZBEAR_DEBUG", false)) view.openDebugFromNotification();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (view != null) {
            view.handleImageResult(requestCode, resultCode, data);
            view.handleWavResult(requestCode, resultCode, data);
            view.handleIntermissionWavResult(requestCode, resultCode, data);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (view != null && requestCode == 9002) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            view.onAudioPermissionResult(granted);
        }
    }

    @Override protected void onDestroy() {
        if (view != null) view.shutdown();
        super.onDestroy();
    }
}

class FazbearView extends View {
    final Context appContext;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService net = Executors.newCachedThreadPool();
    final DatagramSocket rxSocket;
    final SharedPreferences prefs;

    final String[] names = {"FREDDY", "BONNIE", "CHICA", "STAGE"};
    final String[] defaultIPs = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
    final String[] ips = new String[4];
    final String[] animNames = {"Animation 1", "Welcome Show", "Song 1", "Song 2", "Wave", "Point", "Laugh", "Custom"};
    final Bitmap[] chars = new Bitmap[4];
    final String[] customCharUris = new String[4];
    // Each theme keeps its own character/stage photo set. If a theme has no
    // custom photo yet, the normal default character artwork is used.
    final Bitmap[][] themeCharImages = new Bitmap[11][4];
    final String[][] themeCharUris = new String[11][4];
    int pendingThemeCharacterTheme = -1;
    int pendingThemeCharacterSlot = -1;
    int pendingCharacterSlot = -1;
    static final int PICK_CHARACTER_IMAGE = 4211;
    final Bitmap[] customAnimImages = new Bitmap[8];
    final String[] customAnimUris = new String[8];
    int pendingImageSlot = -1;
    static final int PICK_ANIMATION_IMAGE = 4208;
    Movie menuGif;
    Bitmap customBackground;
    String customBackgroundUri;
    // Dedicated wide scheduled-show stage background. This is the uploaded artwork only;
    // all timer panels, text, and buttons are drawn by Java so they remain live/touchable.
    Bitmap showTimerBackground;
    Bitmap[] themeBackgrounds = new Bitmap[11];
    String[] themeBackgroundUris = new String[11];
    int[] themeEffects = new int[11]; // 0=default, 1=CRT, 2=glitch, 3=static, 4=neon, 5=none
    boolean scanlinesEnabled = true;
    boolean glitchEnabled = true;
    static final int PICK_THEME_BACKGROUND = 4210;
    static final int PICK_HOME_MEDIA = 4213;
    static final int PICK_WAV_AUDIO = 4214;
    static final int PICK_INTERMISSION_WAVS = 4215;
    static final int PICK_COUNTDOWN_WAV1 = 4216;
    static final int PICK_COUNTDOWN_WAV2 = 4217;
    final ArrayList<String> intermissionWavUris = new ArrayList<>();
    final ArrayList<String> intermissionWavNames = new ArrayList<>();
    int intermissionWavIndex = 0;
    String countdownWav1Uri = null, countdownWav1Name = "FIRST HALF WAV";
    String countdownWav2Uri = null, countdownWav2Name = "SECOND HALF WAV";
    int countdownWavHalf = 0;
    long scheduledCountdownMidpointMs = 0L;
    final String[] animWavUris = new String[8];
    final String[] animWavNames = new String[8];
    int pendingWavAnimationSlot = -1; // -1 means the legacy/global WAV picker
    MediaPlayer localWavPlayer;
    // Track every local player, including players still waiting for prepareAsync().
    final Set<MediaPlayer> localWavPlayers = Collections.newSetFromMap(new IdentityHashMap<MediaPlayer, Boolean>());
    String selectedWavUri;
    String selectedWavName = "NO WAV SELECTED";
    boolean localWavPlaying = false;
    boolean localWavPausedByBottango = false;
    int localWavGeneration = 0; // Invalidates pending async MediaPlayer callbacks when playback is stopped/replaced.
    int lastStartedWavSlot = -1;
    long lastStartedWavAt = 0L;
    String lastStartedWavUri = null;
    Bitmap homeCustomBitmap;
    Movie homeCustomMovie;
    String homeCustomMediaUri;
    long homeCustomMovieStartedAt = -1;
    long menuGifStartedAt = -1;

    static final int HOME = 0, DEVICES = 1, TIMELINE = 2, CONTROL = 3, SETTINGS = 4, DEBUG = 5, DEVICE_DETAIL = 6, ANIMATIONS = 7, DIAGNOSTICS = 8, SCHEDULE = 9;

    int screen = HOME;
    int scheduleHour = 19, scheduleMinute = 0, scheduleDays = 0; // 0=daily, 1=weekdays, 2=weekends
    boolean scheduleEnabled = false;
    boolean scheduledShowActive = false;
    boolean scheduledShowFinished = false;
    // Original countdown interval captured when a scheduled show is started.
    // After the show finishes, the next countdown uses this same interval
    // instead of jumping to the next calendar occurrence.
    long scheduledRepeatIntervalMs = 0L;
    // Bottango owns the real animation list. The app identifies the idle pose
    // by the Bottango animation name "idle", never by a fixed slot number.
    static final String BOTTANGO_IDLE_ANIMATION_NAME = "idle";
    volatile boolean bottangoIdleAnimationAvailable = false;
    volatile int bottangoIdleAnimationIndex = -1;
    boolean scheduledIdleActivated = false;
    boolean intermissionMusicStarted = false;
    long scheduledShowTargetMs = 0L;
    long scheduledCountdownStartMs = 0L;
    long scheduledShowCountdownStartMs = 0L;
    int scheduledShowPhase = 0; // 0=intermission, 1=countdown, 2=show
    int scheduledCountdownValue = 10;
    long scheduledCountdownErrorUntilMs = 0L;
    final Runnable scheduledShowTick = () -> tickScheduledShow();
    int page = 0;
    int selectedAnimation = 1;
    boolean autoplay = false;
    boolean loop = false;
    boolean manualTimingMode = false;
    final long[] manualAnimationDurationsMs = {279000L, 233000L, 308000L, 357000L, 263000L, 171000L, 180000L, 180000L};
    boolean manualShowRunning = false;
    long manualAnimationDeadline = 0L;
    final Runnable manualAdvanceRunnable = () -> manualAdvanceTick();
    void manualAdvanceTick() {
        if (!manualShowRunning || !manualTimingMode) return;
        long remaining = manualAnimationDeadline - System.currentTimeMillis();
        if (remaining > 0) { main.postDelayed(manualAdvanceRunnable, Math.min(remaining, 1000L)); return; }
        advanceManualShow();
    }
    boolean[] online = new boolean[4];
    long[] lastSeen = new long[4];
    // Actual ESP32 Wi-Fi RSSI, populated by CTOUCH,WIFI,<ID>,<dBm> packets.
    int[] controllerWifiRssi = {-127, -127, -127, -127};
    long[] lastWifiSeen = new long[4];
    String[] playing = {"Stopped", "Stopped", "Stopped", "Stage Lights"};
    int[] progress = {0, 0, 0, 0};
    int syncedVolume = -1;
    volatile boolean vuCaptureRequested = false;
    // Mic-based VU telemetry: normalized RMS level, peak hold, dBFS readout, and clip warning.
    volatile float vuLevel = 0f;
    volatile float vuPeak = 0f;
    volatile float vuDbfs = -60f;
    volatile float vuPeakDbfs = -60f;
    volatile boolean vuClip = false;
    volatile long vuPeakHoldUntil = 0L;
    volatile boolean vuPermissionDenied = false;
    AudioRecord audioRecord;
    int playbackTimeMs = 0;
    int durationMs = -1;
    boolean bottangoPlaying = false;
    boolean playbackStateKnown = false;
    boolean playbackPollInFlight = false;
    boolean lastPlaybackWasPlaying = false;
    int lastAutoAdvanceIndex = -1;
    long scheduledAdvanceLockUntilMs = 0L;
    volatile long playbackPollGeneration = 0L;
    volatile boolean shuttingDown = false;
    long lastBottangoReportedTimeMs = -1L;
    long pendingBottangoSeekMs = -1L;
    boolean playbackPollErrorLogged = false;
    long lastPlaybackPollAt = 0L;
    String lastPlaybackError = "";
    String currentTrackName = "BOTTANGO PLAYBACK";
    ArrayList<String> log = new ArrayList<>();
    String status = "SYSTEM READY";
    String errorTitle = "";
    String errorMessage = "";
    String errorDetails = "";
    boolean errorPopup = false;
    int theme = 0;
    // Live Show Timer customization. Values are persisted per app so the timer
    // appearance can be changed without replacing the artwork.
    int timerSizeMode = 1;   // 0=small, 1=medium, 2=large
    int timerColorMode = 0;  // 0=theme accent, 1=gold, 2=cyan, 3=red, 4=white
    int timerEffectMode = 0; // 0=none, 1=pulse, 2=flash-at-10s, 3=glow, 4=shake
    volatile int phoneWifiRssi = -127;

    // Audio output: 0 = MAX98357 only, 1 = BOTH, 2 = PHONE only.
    WifiAudioReceiver phoneAudioReceiver;
    int audioOutputMode = 0;
    String phoneAudioStatus = "MAX98357 ONLY";
    Typeface appFont;

    FazbearView(Context c) {
        super(c);
        appContext = c;
        try {
            appFont = Typeface.createFromAsset(c.getAssets(), "fonts/Open 24 Display St.ttf");
        } catch (Exception ignored) {
            appFont = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
        }
        setFocusable(true);
        try {
            menuGif = Movie.decodeStream(c.getAssets().open("menu.gif"));
        } catch (Exception ignored) {
            menuGif = null;
        }
        prefs = c.getSharedPreferences("fazbear", Context.MODE_PRIVATE);
        selectedWavUri = prefs.getString("selected_wav_uri", null);
        selectedWavName = prefs.getString("selected_wav_name", "NO WAV SELECTED");
        loadIntermissionPlaylist();
        for (int i = 0; i < 4; i++) ips[i] = prefs.getString("ip" + i, defaultIPs[i]);
        theme = prefs.getInt("theme", 0);
        timerSizeMode = prefs.getInt("timer_size_mode", 1);
        timerColorMode = prefs.getInt("timer_color_mode", 0);
        timerEffectMode = prefs.getInt("timer_effect_mode", 0);
        scheduleEnabled = prefs.getBoolean("schedule_enabled", false);
        scheduleHour = prefs.getInt("schedule_hour", 19);
        scheduleMinute = prefs.getInt("schedule_minute", 0);
        scheduleDays = prefs.getInt("schedule_days", 0);
        manualTimingMode = prefs.getBoolean("manual_timing_mode", false);
        for (int i = 0; i < 8; i++) manualAnimationDurationsMs[i] = Math.max(1000L, prefs.getLong("manual_duration_" + i, manualAnimationDurationsMs[i]));
        if (!prefs.contains("theme")) prefs.edit().putInt("theme", 0).apply();
        scanlinesEnabled = prefs.getBoolean("theme_scanlines", true);
        glitchEnabled = prefs.getBoolean("theme_glitch", true);
        customBackgroundUri = prefs.getString("theme_background", null);
        for (int i = 0; i < 11; i++) {
            themeBackgroundUris[i] = null;
            themeEffects[i] = prefs.getInt("theme_effect_" + i, 0);
            for (int slot = 0; slot < 4; slot++) {
                themeCharUris[i][slot] = prefs.getString("theme_char_" + i + "_" + slot, null);
            }
        }
        homeCustomMediaUri = prefs.getString("home_custom_media", null);
        if (homeCustomMediaUri != null) loadHomeMedia(android.net.Uri.parse(homeCustomMediaUri));
        for (int i = 0; i < 8; i++) {
            animNames[i] = prefs.getString("animName" + i, animNames[i]);
            animWavUris[i] = prefs.getString("animWavUri" + i, null);
            animWavNames[i] = prefs.getString("animWavName" + i, null);
            customAnimUris[i] = prefs.getString("animImage" + i, null);
            if (customAnimUris[i] != null) loadCustomAnimationImage(i, android.net.Uri.parse(customAnimUris[i]));
        }

        chars[0] = load(c, "freddy");
        chars[1] = load(c, "bonnie");
        chars[2] = load(c, "chica");
        chars[3] = load(c, "stage");
        showTimerBackground = load(c, "show_timer_background");
        for (int i = 0; i < 4; i++) {
            customCharUris[i] = prefs.getString("charImage" + i, null);
            if (customCharUris[i] != null) loadCustomCharacterImage(i, android.net.Uri.parse(customCharUris[i]));
        }

        // Load a built-in photo set for every theme first. Persisted user photos
        // are applied afterward, so a custom photo always overrides the theme default.
        loadDefaultThemeArtwork();
        for (int i = 0; i < 11; i++) {
            if (themeBackgroundUris[i] != null) loadThemeBackground(i, android.net.Uri.parse(themeBackgroundUris[i]));
            for (int slot = 0; slot < 4; slot++) {
                if (themeCharUris[i][slot] != null) {
                    loadThemeCharacterImage(i, slot, android.net.Uri.parse(themeCharUris[i][slot]));
                }
            }
        }

        DatagramSocket s = null;
        try {
            s = new DatagramSocket(4211);
            s.setBroadcast(true);
            addLog("UDP RX READY  //  PORT 4211");
        } catch (Exception e) {
            addLog("UDP RX ERROR: " + e.getMessage());
            showError("NETWORK ERROR", "Unable to open UDP 4211", String.valueOf(e.getMessage()));
        }
        rxSocket = s;
        if (rxSocket != null) startReceiver();
        addLog("FAZBEAR CONTROL ONLINE");

        main.postDelayed(() -> {
            for (int i = 0; i < 4; i++) {
                if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
            }
            invalidate();
            main.postDelayed(this::tick, 1000);
            main.postDelayed(this::pollBottangoState, 100);
        }, 1000);
    }

    void tick() {
        updatePhoneWifiRssi();
        for (int i = 0; i < 4; i++) {
            if (online[i] && System.currentTimeMillis() - lastSeen[i] > 6000) online[i] = false;
        }
        invalidate();
        main.postDelayed(this::tick, 1000);
        if (screen == TIMELINE) ensureVuCaptureIfPermitted();
    }

    void updatePhoneWifiRssi() {
        try {
            WifiManager wm = (WifiManager) appContext.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm != null && wm.getConnectionInfo() != null) {
                phoneWifiRssi = wm.getConnectionInfo().getRssi();
            } else {
                phoneWifiRssi = -127;
            }
        } catch (Exception ignored) {
            phoneWifiRssi = -127;
        }
    }

    int phoneWifiBars() {
        int rssi = phoneWifiRssi;
        if (rssi <= -100 || rssi == 0) return 0;
        if (rssi >= -55) return 5;
        if (rssi >= -65) return 4;
        if (rssi >= -75) return 3;
        if (rssi >= -85) return 2;
        return 1;
    }

    // Controller bars use measured ESP32 Wi-Fi RSSI, not packet freshness.
    // A controller without an RSSI packet stays unknown (all gray bars).
    int controllerWifiBars(int i) {
        if (i < 0 || i >= 4 || !online[i]) return 0;
        if (lastWifiSeen[i] == 0 || System.currentTimeMillis() - lastWifiSeen[i] > 6000) return 0;
        int rssi = controllerWifiRssi[i];
        if (rssi >= -55) return 5;
        if (rssi >= -65) return 4;
        if (rssi >= -75) return 3;
        if (rssi >= -85) return 2;
        if (rssi >= -100) return 1;
        return 0;
    }

    int controllerIndexForId(String id) {
        if (id == null) return -1;
        for (int i = 0; i < names.length; i++) {
            if (names[i].equalsIgnoreCase(id.trim())) return i;
        }
        return -1;
    }

    void signalBars(Canvas c, float x, float baseline, int bars, int color, float barWidth, float gap, float maxHeight) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 5; i++) {
            float h = maxHeight * (i + 1) / 5f;
            p.setColor(i < bars ? color : 0xFF454754);
            c.drawRoundRect(x + i * (barWidth + gap), baseline - h,
                    x + i * (barWidth + gap) + barWidth, baseline, 1.5f, 1.5f, p);
        }
    }

    Bitmap load(Context c, String n) {
        int id = getResources().getIdentifier(n, "drawable", c.getPackageName());
        return id == 0 ? null : BitmapFactory.decodeResource(getResources(), id);
    }

    void startReceiver() {
        net.execute(() -> {
            byte[] buf = new byte[2048];
            while (rxSocket != null && !rxSocket.isClosed()) {
                try {
                    DatagramPacket d = new DatagramPacket(buf, buf.length);
                    rxSocket.receive(d);
                    String msg = new String(d.getData(), d.getOffset(), d.getLength()).trim();
                    final String host = d.getAddress().getHostAddress();
                    main.post(() -> handlePacket(host, msg));
                } catch (Exception ignored) {}
            }
        });
    }

    void handlePacket(String host, String msg) {
        int idx = indexForHost(host);
        String[] fields = msg.split(",");
        // New firmware reports actual radio strength separately from the legacy status packet.
        if (fields.length >= 4 && "CTOUCH".equalsIgnoreCase(fields[0].trim())
                && "WIFI".equalsIgnoreCase(fields[1].trim())) {
            int idIndex = controllerIndexForId(fields[2]);
            try {
                int rssi = Integer.parseInt(fields[3].trim());
                if (idIndex >= 0 && rssi >= -127 && rssi <= 0) {
                    controllerWifiRssi[idIndex] = rssi;
                    lastWifiSeen[idIndex] = System.currentTimeMillis();
                    online[idIndex] = true;
                    lastSeen[idIndex] = System.currentTimeMillis();
                    addLog(names[idIndex] + " WI-FI RSSI " + rssi + " dBm");
                }
            } catch (NumberFormatException ignored) { }
        }
        if (idx >= 0 && !msg.toUpperCase(Locale.US).startsWith("CTOUCH,WIFI,")) {
            online[idx] = true;
            lastSeen[idx] = System.currentTimeMillis();
        }
        addLog(host + " > " + msg);

        int v = parseVolume(msg);
        if (v >= 0) {
            syncedVolume = v;
            status = "VOLUME " + v + "%  //  ESP32 POT";
        }

        if (msg.toUpperCase(Locale.US).contains("ANIM_DONE")) {
            if (idx >= 0) {
                progress[idx] = 100;
                if (scheduledShowActive || autoplay) {
                    if (scheduledShowActive) {
                        advanceScheduledShowAfterAnimationDone();
                    } else {
                        int next = selectedAnimation >= 8 ? 1 : selectedAnimation + 1;
                        selectedAnimation = next;
                        playing[idx] = animNames[next - 1];
                        send(idx, "[START " + next + "]");
                    }
                }
            }
        }
        invalidate();
    }

    void advanceScheduledShowAfterAnimationDone() {
        if (!scheduledShowActive || scheduledShowPhase != 2 || scheduledShowFinished) return;

        // Multiple ESP32 controllers can report ANIM_DONE for the same animation.
        // Treat those reports as one completion so the show cannot jump over songs.
        long now = System.currentTimeMillis();
        if (now < scheduledAdvanceLockUntilMs) {
            addLog("SCHEDULED SHOW // ANIM_DONE DUPLICATE IGNORED");
            return;
        }
        scheduledAdvanceLockUntilMs = now + 2000L;

        int completedSlot = Math.max(1, selectedAnimation);
        int nextSlot = findNextDetectableAssignedWav(completedSlot);
        if (nextSlot < 0) {
            finishScheduledShowBecauseNoWavs();
            return;
        }

        selectedAnimation = nextSlot + 1;
        currentTrackName = animNames[nextSlot];
        playbackTimeMs = 0;
        status = "SCHEDULED SHOW // AUTO NEXT ANIMATION " + selectedAnimation;
        addLog("SCHEDULED SHOW // ANIM_DONE // AUTO NEXT ANIMATION " + selectedAnimation);

        for (int i = 0; i < 3; i++) {
            playing[i] = animNames[nextSlot];
            progress[i] = 0;
            send(i, "[START " + selectedAnimation + "]");
        }
        send(3, "[START " + selectedAnimation + "]");

        // Keep Bottango on the same animation as the scheduled-show audio.
        // This is required when the previous animation ended naturally in
        // Bottango rather than through a touchscreen controller ANIM_DONE.
        sendBottangoPlayback(
                "{\"selectedAnimationIndex\":" + nextSlot
                        + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "SCHEDULED SHOW // AUTO NEXT  // " + animNames[nextSlot]);

        playAssignedWavForSelectedAnimation();
        invalidate();
    }

    int indexForHost(String host) {
        for (int i = 0; i < 4; i++) if (ips[i].equals(host)) return i;
        return -1;
    }

    int parseVolume(String msg) {
        // Accept the explicit status suffix: ...,VOLUME,<0..100>.
        // Do not mistake unrelated numbers (file offsets, CPU data, etc.) for volume.
        String[] fields = msg.split(",");
        for (int i = 0; i < fields.length - 1; i++) {
            if ("VOLUME".equalsIgnoreCase(fields[i].trim())) {
                try {
                    int value = Integer.parseInt(fields[i + 1].trim());
                    return value >= 0 && value <= 100 ? value : -1;
                } catch (NumberFormatException ignored) {
                    return -1;
                }
            }
        }
        // Also accept a standalone legacy message such as "VOLUME 75".
        String u = msg.trim().toUpperCase(Locale.US);
        if (u.matches("VOLUME\\s+\\d{1,3}%?")) {
            try {
                String digits = u.replaceAll("[^0-9]", "");
                int value = Integer.parseInt(digits);
                return value >= 0 && value <= 100 ? value : -1;
            } catch (NumberFormatException ignored) { return -1; }
        }
        return -1;
    }

    void addLog(String s) {
        log.add(timeStamp() + "  " + s);
        while (log.size() > 160) log.remove(0);
        invalidate();
    }

    String timeStamp() {
        long n = System.currentTimeMillis() / 1000;
        return String.format(Locale.US, "%02d:%02d:%02d", (n / 3600) % 24, (n / 60) % 60, n % 60);
    }

    void send(int which, String cmd) {
        if (which < 0 || which > 3) return;
        final String ip = ips[which];
        addLog(ip + " < " + cmd);
        net.execute(() -> {
            try {
                byte[] data = cmd.getBytes("UTF-8");
                DatagramPacket dp = new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210);
                DatagramSocket s = new DatagramSocket();
                s.setBroadcast(true);
                s.send(dp);
                s.close();
                main.post(this::invalidate);
            } catch (Exception e) {
                main.post(() -> {
                    addLog("SEND ERROR " + ip + ": " + e.getMessage());
                    showError("COMMAND FAILED", "Could not reach ESP32 " + names[which],
                            "Target: " + ip + "\nUDP command port: 4210\n" + e.getMessage());
                });
            }
        });
    }

    void broadcast(String cmd) { for (int i = 0; i < 4; i++) send(i, cmd); }

    void play(int i, int anim) {
        selectedAnimation = anim;
        playAssignedWavForSelectedAnimation();
        playing[i] = animNames[anim - 1];
        progress[i] = 0;
        send(i, "[START " + anim + "]");
        status = names[i] + "  //  PLAYING " + animNames[anim - 1];
    }

    // Bottango Windows REST API (configured for this show's PC).
    // Bottango API Access must be enabled in the Hardware menu.
    static final String BOTTANGO_PLAYBACK_URL = "http://10.0.0.226:59224/PlaybackState/";

    void sendBottangoPlayback(String json, String successStatus) {
        status = "BOT TANGO // SENDING";
        addLog("BOT TANGO PUT " + BOTTANGO_PLAYBACK_URL + " BODY " + json);
        invalidate();
        net.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(BOTTANGO_PLAYBACK_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("PUT");
                connection.setConnectTimeout(2500);
                connection.setReadTimeout(2500);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] body = json.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream os = connection.getOutputStream()) { os.write(body); }
                int code = connection.getResponseCode();
                if (code >= 200 && code < 300) {
                    main.post(() -> {
                        status = successStatus;
                        addLog("BOTTANGO API OK // HTTP " + code);
                        invalidate();
                    });
                } else {
                    String response = "";
                    InputStream es = connection.getErrorStream();
                    if (es != null) {
                        try (InputStream in = es; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                            byte[] buf = new byte[512]; int count;
                            while ((count = in.read(buf)) != -1) out.write(buf, 0, count);
                            response = out.toString("UTF-8");
                        }
                    }
                    final String detail = "HTTP " + code + (response.isEmpty() ? "" : " // " + response);
                    main.post(() -> {
                        status = "BOTTANGO API ERROR";
                        addLog("BOTTANGO API ERROR // " + detail);
                        showError("BOTTANGO COMMAND FAILED", "The PC rejected the playback request", detail + "\nURL: " + BOTTANGO_PLAYBACK_URL);
                    });
                }
            } catch (Exception e) {
                final String detail = e.getClass().getSimpleName() + ": " + e.getMessage();
                main.post(() -> {
                    status = "BOTTANGO OFFLINE";
                    addLog("BOTTANGO CONNECTION ERROR // " + detail);
                    showError("BOTTANGO CONNECTION FAILED", "Could not connect to Bottango on the Windows PC", detail + "\nURL: " + BOTTANGO_PLAYBACK_URL + "\nCheck that the phone can reach the PC and Windows Firewall allows Bottango on the local network.");
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    void playAll() {
        if (manualTimingMode) { startManualShow(); return; }
        manualShowRunning = false; main.removeCallbacks(manualAdvanceRunnable);
        playAssignedWavForSelectedAnimation();
        lastAutoAdvanceIndex = -1;
        lastPlaybackWasPlaying = false;
        for (int i = 0; i < 4; i++) {
            if (i == 3) playing[i] = "Stage Lights";
            else playing[i] = animNames[selectedAnimation - 1];
            progress[i] = 0;
        }
        // Bottango animation indexes are zero-based; the app's slots are 1–8.
        sendBottangoPlayback("{\"selectedAnimationIndex\":" + (selectedAnimation - 1) + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "PLAY ALL  //  " + animNames[selectedAnimation - 1]);
    }

    void restartShow() {
        if (manualTimingMode) { startManualShow(); return; }
        manualShowRunning = false; main.removeCallbacks(manualAdvanceRunnable);
        // For a scheduled show, beginScheduledShowPlayback() has already selected
        // the first detectable WAV. Do not overwrite that selection with slot 1.
        if (!scheduledShowActive) selectedAnimation = 1;
        playAssignedWavForSelectedAnimation();
        // Restart means return to the beginning of the show for a normal manual
        // restart. A scheduled show must preserve the first playable slot (for
        // example, if Animation 1 has no WAV and Animation 2 does).
        int startIndex = Math.max(0, Math.min(animNames.length - 1, selectedAnimation - 1));
        if (!scheduledShowActive) startIndex = 0;
        selectedAnimation = startIndex + 1;
        lastAutoAdvanceIndex = -1;
        lastPlaybackWasPlaying = false;
        currentTrackName = animNames[startIndex];
        playbackTimeMs = 0;
        for (int i = 0; i < 4; i++) progress[i] = 0;
        for (int i = 0; i < 3; i++) playing[i] = animNames[startIndex];
        playing[3] = "Stage Lights";
        sendBottangoPlayback("{\"selectedAnimationIndex\":" + startIndex
                + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "RESTART SHOW  //  " + animNames[startIndex]);
        invalidate();
    }

    void startManualShow() {
        manualShowRunning = true; main.removeCallbacks(manualAdvanceRunnable);
        addLog("MANUAL SHOW // START"); startManualAnimation(0);
    }
    void startManualAnimation(int index) {
        if (!manualShowRunning || index < 0 || index >= animNames.length) return;
        selectedAnimation = index + 1; currentTrackName = animNames[index]; playbackTimeMs = 0;
        durationMs = (int)Math.min(Integer.MAX_VALUE, manualAnimationDurationsMs[index]);
        playAssignedWavForSelectedAnimation();
        if (scheduledShowFinished) return;
        index = selectedAnimation - 1;
        durationMs = (int)Math.min(Integer.MAX_VALUE, manualAnimationDurationsMs[index]);
        for (int i = 0; i < 4; i++) { playing[i] = i == 3 ? "Stage Lights" : animNames[index]; progress[i] = 0; send(i, "[START " + (index + 1) + "]"); }
        manualAnimationDeadline = System.currentTimeMillis() + manualAnimationDurationsMs[index];
        status = "MANUAL MODE // " + animNames[index];
        addLog("MANUAL SHOW // " + animNames[index] + " FOR " + formatTime((int)manualAnimationDurationsMs[index]));
        main.removeCallbacks(manualAdvanceRunnable); main.postDelayed(manualAdvanceRunnable, Math.min(manualAnimationDurationsMs[index], 1000L)); invalidate();
    }
    void advanceManualShow() {
        if (!manualShowRunning) return;
        int next = selectedAnimation;
        if (next >= animNames.length) {
            if (loop) next = 0;
            else {
                manualShowRunning = false; status = "SHOW COMPLETE // MANUAL MODE"; addLog("MANUAL SHOW // COMPLETE");
                if (scheduledShowActive) { scheduledShowFinished = true; status = "SHOW COMPLETE // SCHEDULED SHOW"; }
                else new AlertDialog.Builder(appContext).setTitle("Show complete").setMessage("All 8 animations have finished. Would you like to restart the show?")
                    .setPositiveButton("RESTART SHOW", (d, w) -> startManualShow()).setNegativeButton("NO", null).show(); invalidate(); return;
            }
        }
        startManualAnimation(next);
    }
    void showShowTimingSettings() {
        android.widget.LinearLayout content = new android.widget.LinearLayout(appContext); content.setOrientation(android.widget.LinearLayout.VERTICAL); content.setPadding(28, 12, 28, 12);
        android.widget.RadioGroup modes = new android.widget.RadioGroup(appContext); modes.setOrientation(android.widget.RadioGroup.VERTICAL);
        android.widget.RadioButton bot = new android.widget.RadioButton(appContext); bot.setText("Bottango Mode — use Bottango playback timing"); bot.setId(1);
        android.widget.RadioButton manual = new android.widget.RadioButton(appContext); manual.setText("Manual Mode — run all 8 animations using these durations"); manual.setId(2);
        modes.addView(bot); modes.addView(manual); modes.check(manualTimingMode ? 2 : 1); content.addView(modes);
        android.widget.TextView note = new android.widget.TextView(appContext); note.setText("Enter each duration as minutes and seconds. Animations 7 and 8 start at 3:00; edit as needed."); note.setPadding(0, 8, 0, 12); content.addView(note);
        EditText[] mins = new EditText[8], secs = new EditText[8];
        for (int i = 0; i < 8; i++) {
            android.widget.LinearLayout row = new android.widget.LinearLayout(appContext); row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            android.widget.TextView label = new android.widget.TextView(appContext); label.setText("Animation " + (i + 1)); label.setGravity(android.view.Gravity.CENTER_VERTICAL); row.addView(label, new android.widget.LinearLayout.LayoutParams(0, 52, 1));
            mins[i] = new EditText(appContext); mins[i].setSingleLine(true); mins[i].setInputType(InputType.TYPE_CLASS_NUMBER); mins[i].setHint("min"); mins[i].setText(String.valueOf(manualAnimationDurationsMs[i] / 60000L));
            secs[i] = new EditText(appContext); secs[i].setSingleLine(true); secs[i].setInputType(InputType.TYPE_CLASS_NUMBER); secs[i].setHint("sec"); secs[i].setText(String.valueOf((manualAnimationDurationsMs[i] / 1000L) % 60L));
            row.addView(mins[i], new android.widget.LinearLayout.LayoutParams(64, 52)); android.widget.TextView colon = new android.widget.TextView(appContext); colon.setText(":"); colon.setGravity(android.view.Gravity.CENTER); row.addView(colon, new android.widget.LinearLayout.LayoutParams(18, 52)); row.addView(secs[i], new android.widget.LinearLayout.LayoutParams(64, 52)); content.addView(row);
        }
        android.widget.ScrollView scroll = new android.widget.ScrollView(appContext); scroll.addView(content);
        new AlertDialog.Builder(appContext).setTitle("SHOW TIMING MODE").setView(scroll).setNegativeButton("CANCEL", null).setPositiveButton("SAVE", (d, w) -> {
            manualTimingMode = modes.getCheckedRadioButtonId() == 2; android.content.SharedPreferences.Editor editor = prefs.edit().putBoolean("manual_timing_mode", manualTimingMode);
            for (int i = 0; i < 8; i++) { try { long m = Long.parseLong(mins[i].getText().toString().trim()); long sec = Long.parseLong(secs[i].getText().toString().trim()); if (m < 0 || sec < 0 || sec > 59 || (m * 60L + sec) <= 0) throw new NumberFormatException(); manualAnimationDurationsMs[i] = (m * 60L + sec) * 1000L; editor.putLong("manual_duration_" + i, manualAnimationDurationsMs[i]); } catch (Exception ex) { status = "INVALID DURATION // ANIMATION " + (i + 1); addLog(status); } }
            editor.apply(); if (!manualTimingMode) { manualShowRunning = false; main.removeCallbacks(manualAdvanceRunnable); }
            status = manualTimingMode ? "MANUAL TIMING MODE SAVED" : "BOTTANGO TIMING MODE SAVED"; addLog("SHOW TIMING // " + status); invalidate();
        }).show();
    }

    void skipAnimation() {
        if (manualTimingMode && manualShowRunning) { main.removeCallbacks(manualAdvanceRunnable); advanceManualShow(); return; }
        int nextIndex = selectedAnimation; // selectedAnimation is 1-based; this is the next 0-based index.
        if (nextIndex >= animNames.length) {
            if (loop) nextIndex = 0;
            else {
                status = "SHOW COMPLETE  //  LAST ANIMATION";
                addLog("SKIP // ALREADY AT LAST ANIMATION");
                invalidate();
                return;
            }
        }
        selectedAnimation = nextIndex + 1;
        playAssignedWavForSelectedAnimation();
        if (scheduledShowFinished) return;
        nextIndex = selectedAnimation - 1;
        lastAutoAdvanceIndex = -1;
        lastPlaybackWasPlaying = false;
        currentTrackName = animNames[nextIndex];
        playbackTimeMs = 0;
        for (int i = 0; i < 3; i++) {
            playing[i] = animNames[nextIndex];
            progress[i] = 0;
        }
        playing[3] = "Stage Lights";
        addLog("SKIP ANIMATION // " + animNames[nextIndex]);
        sendBottangoPlayback("{\"selectedAnimationIndex\":" + nextIndex + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "SKIP  //  " + animNames[nextIndex]);
        invalidate();
    }

    void advanceAfterCurrentAnimation(int completedZeroBasedIndex) {
        if (!autoplay || completedZeroBasedIndex < 0 || completedZeroBasedIndex >= animNames.length) return;
        if (lastAutoAdvanceIndex == completedZeroBasedIndex) return;
        lastAutoAdvanceIndex = completedZeroBasedIndex;

        int nextIndex = completedZeroBasedIndex + 1;
        if (nextIndex >= animNames.length) {
            if (loop) nextIndex = 0;
            else {
                status = "SHOW COMPLETE  //  AUTOPLAY ON";
                addLog("AUTOPLAY // LAST ANIMATION FINISHED");
                invalidate();
                return;
            }
        }

        selectedAnimation = nextIndex + 1;
        playAssignedWavForSelectedAnimation();
        if (scheduledShowFinished) return;
        nextIndex = selectedAnimation - 1;
        currentTrackName = animNames[nextIndex];
        playbackTimeMs = 0;
        for (int i = 0; i < 3; i++) {
            playing[i] = animNames[nextIndex];
            progress[i] = 0;
        }
        addLog("AUTOPLAY // NEXT: " + animNames[nextIndex]);
        sendBottangoPlayback("{\"selectedAnimationIndex\":" + nextIndex + ",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "AUTO NEXT  //  " + animNames[nextIndex]);
        invalidate();
    }

    void pollBottangoState() {
        if (shuttingDown) return;
        if (playbackPollInFlight) {
            main.postDelayed(this::pollBottangoState, 100);
            return;
        }
        playbackPollInFlight = true;
        final long requestGeneration = ++playbackPollGeneration;
        net.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(BOTTANGO_PLAYBACK_URL).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(600);
                connection.setReadTimeout(600);
                int code = connection.getResponseCode();
                if (code >= 200 && code < 300) {
                    StringBuilder body = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = reader.readLine()) != null) body.append(line);
                    }
                    JSONObject json = new JSONObject(body.toString());
                    long time = jsonLong(json, -1, "playbackTimeInMS", "playbackTimeMs", "currentTimeInMS", "currentTimeMs");
                    long duration = jsonLong(json, -1, "durationInMS", "playbackDurationInMS", "animationDurationInMS", "totalDurationInMS", "durationMs");
                    long index = jsonLong(json, -1, "selectedAnimationIndex", "animationIndex");
                    boolean playingNow = jsonBoolean(json, bottangoPlaying, "isPlaying", "playing");
                    final long parsedTime = time;
                    final long parsedDuration = duration;
                    final long parsedIndex = index;
                    final boolean parsedPlaying = playingNow;
                    main.post(() -> {
                        if (requestGeneration != playbackPollGeneration) return;
                        int priorIndex = selectedAnimation - 1;
                        boolean wasPlaying = lastPlaybackWasPlaying;
                        if (parsedTime >= 0 && parsedTime <= Integer.MAX_VALUE) playbackTimeMs = (int) parsedTime;
                        if (parsedDuration > 0 && parsedDuration <= Integer.MAX_VALUE) durationMs = (int) parsedDuration;
                        if (parsedIndex >= 0 && parsedIndex < animNames.length) {
                            boolean animationChanged = ((int) parsedIndex != priorIndex);
                            selectedAnimation = (int) parsedIndex + 1;
                            currentTrackName = animNames[selectedAnimation - 1];
                            if (animationChanged) lastBottangoReportedTimeMs = -1L;
                            if ((int) parsedIndex != lastAutoAdvanceIndex) lastAutoAdvanceIndex = -1;
                        }
                        int observedIndex = parsedIndex >= 0 && parsedIndex < animNames.length
                                ? (int) parsedIndex : priorIndex;
                        boolean reachedEnd = parsedDuration > 0 && parsedTime >= 0
                                && parsedTime >= parsedDuration - 250;
                        long previousBottangoTime = lastBottangoReportedTimeMs;
                        boolean timelineSeeked = previousBottangoTime >= 0 && parsedTime >= 0
                                && Math.abs(parsedTime - previousBottangoTime) > 750;
                        bottangoPlaying = parsedPlaying;
                        // Bottango's timeline is the master clock. If the user drags
                        // the Bottango playhead, seek the existing phone MediaPlayer to
                        // that position instead of starting a new player from 0.
                        if (timelineSeeked && parsedIndex == observedIndex) {
                            seekLocalWavFromBottango(parsedTime);
                        }
                        // Bottango is the master transport. Mirror its transport state
                        // to the phone WAV player. A playing -> stopped transition is NOT
                        // treated as animation completion; completion is based on the
                        // reported playback time reaching the reported duration.
                        // Mirror an observed pause immediately. Do not require a second
                        // user click or a prior poll transition to confirm it. Bottango can
                        // briefly report the same transport state while its REST endpoint
                        // catches up, so a transition-only check could miss the first pause.
                        if (!parsedPlaying) {
                            // A backward timeline jump is a SEEK, not a STOP.
                            // Bottango may briefly report paused while the playhead is being dragged;
                            // never destroy the phone MediaPlayer here.
                            pauseLocalWavFromBottango();
                        } else if (playbackStateKnown && wasPlaying != parsedPlaying) {
                            startOrResumeLocalWavFromBottango();
                        }
                        if (parsedTime >= 0) lastBottangoReportedTimeMs = parsedTime;
                        lastPlaybackWasPlaying = parsedPlaying;
                        playbackStateKnown = true;
                        lastPlaybackPollAt = System.currentTimeMillis();
                        lastPlaybackError = "";
                        playbackPollErrorLogged = false;
                        if (autoplay && observedIndex >= 0 && observedIndex < animNames.length
                                && reachedEnd) {
                            advanceAfterCurrentAnimation(observedIndex);
                        }
                        invalidate();
                    });
                } else if (!playbackPollErrorLogged) {
                    main.post(() -> { lastPlaybackError = "HTTP " + code; addLog("BOTTANGO STATE GET // HTTP " + code); playbackPollErrorLogged = true; invalidate(); });
                }
            } catch (Exception e) {
                if (!playbackPollErrorLogged) {
                    String detail = e.getClass().getSimpleName() + ": " + e.getMessage();
                    main.post(() -> { lastPlaybackError = detail; addLog("BOTTANGO STATE POLL UNAVAILABLE // " + detail); playbackPollErrorLogged = true; invalidate(); });
                }
            } finally {
                if (connection != null) connection.disconnect();
                playbackPollInFlight = false;
                if (!shuttingDown) main.postDelayed(this::pollBottangoState, 100);
            }
        });
    }

    long jsonLong(JSONObject json, long fallback, String... keys) {
        for (String key : keys) {
            Object value = json.opt(key);
            if (value instanceof Number) return ((Number) value).longValue();
            if (value instanceof String) {
                try { return Long.parseLong(((String) value).trim()); } catch (Exception ignored) {}
            }
        }
        return fallback;
    }

    boolean jsonBoolean(JSONObject json, boolean fallback, String... keys) {
        for (String key : keys) {
            Object value = json.opt(key);
            if (value instanceof Boolean) return (Boolean) value;
            if (value instanceof Number) return ((Number) value).intValue() != 0;
            if (value instanceof String) {
                String v = ((String) value).trim();
                if ("true".equalsIgnoreCase(v) || "1".equals(v)) return true;
                if ("false".equalsIgnoreCase(v) || "0".equals(v)) return false;
            }
        }
        return fallback;
    }

    void seekBy(int deltaMs) {
        int target = Math.max(0, playbackTimeMs + deltaMs);
        if (durationMs > 0) target = Math.min(target, durationMs);
        seekTo(target);
    }

    void seekTo(int targetMs) {
        targetMs = Math.max(0, targetMs);
        if (durationMs > 0) targetMs = Math.min(targetMs, durationMs);
        playbackTimeMs = targetMs;
        String body = "{\"selectedAnimationIndex\":" + (selectedAnimation - 1) + ",\"playbackTimeInMS\":" + targetMs + (bottangoPlaying ? ",\"isPlaying\":true" : "") + "}";
        sendBottangoPlayback(body, "SEEK  //  " + formatTime(targetMs));
        invalidate();
    }

    String formatTime(int ms) {
        int seconds = Math.max(0, ms / 1000);
        return String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60);
    }

    void ensureVuPermission() {
        if (Build.VERSION.SDK_INT >= 23 && appContext.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ((Activity) appContext).requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 9002);
        } else {
            vuPermissionDenied = false;
            startVuCapture();
        }
    }

    void onAudioPermissionResult(boolean granted) {
        vuPermissionDenied = !granted;
        if (granted && screen == TIMELINE) startVuCapture();
        else if (!granted) stopVuCapture();
        invalidate();
    }

    void ensureVuCaptureIfPermitted() {
        if (appContext.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVuCapture();
    }

    synchronized void startVuCapture() {
        if (vuCaptureRequested) return;
        vuCaptureRequested = true;
        net.execute(() -> {
            AudioRecord recorder = null;
            try {
                int min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) min = 4096;
                recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 4096));
                audioRecord = recorder;
                recorder.startRecording();
                short[] samples = new short[512];
                while (vuCaptureRequested && recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    int count = recorder.read(samples, 0, samples.length);
                    if (count > 0) {
                        double sum = 0;
                        double samplePeak = 0;
                        for (int i = 0; i < count; i++) {
                            double v = samples[i] / 32768.0;
                            double abs = Math.abs(v);
                            sum += v * v;
                            if (abs > samplePeak) samplePeak = abs;
                        }
                        float rms = (float) Math.sqrt(sum / count);
                        float dbfs = (float) (20.0 * Math.log10(Math.max(rms, 0.000001)));
                        float peakDbfs = (float) (20.0 * Math.log10(Math.max(samplePeak, 0.000001)));
                        dbfs = Math.max(-60f, Math.min(0f, dbfs));
                        peakDbfs = Math.max(-60f, Math.min(0f, peakDbfs));
                        float level = (dbfs + 60f) / 60f;
                        float instantPeak = (peakDbfs + 60f) / 60f;
                        vuLevel = vuLevel * 0.68f + level * 0.32f;
                        long now = System.currentTimeMillis();
                        if (instantPeak >= vuPeak || now > vuPeakHoldUntil) {
                            vuPeak = Math.max(instantPeak, vuPeak * 0.985f);
                            if (instantPeak >= vuPeak) {
                                vuPeakDbfs = peakDbfs;
                                vuPeakHoldUntil = now + 900;
                            } else {
                                vuPeakDbfs = -60f + vuPeak * 60f;
                            }
                        }
                        vuDbfs = dbfs;
                        if (samplePeak >= 0.985) vuClip = true;
                        main.post(this::invalidate);
                    }
                }
            } catch (Exception e) {
                main.post(() -> addLog("VU MIC ERROR // " + e.getMessage()));
            } finally {
                if (recorder != null) {
                    try { recorder.stop(); } catch (Exception ignored) {}
                    recorder.release();
                }
                if (audioRecord == recorder) audioRecord = null;
            }
        });
    }

    synchronized void stopVuCapture() {
        vuCaptureRequested = false;
        AudioRecord r = audioRecord;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) {}
        }
        vuLevel = 0f;
        vuPeak = 0f;
        vuDbfs = -60f;
        vuPeakDbfs = -60f;
        vuClip = false;
        vuPeakHoldUntil = 0L;
    }

    void showError(String title, String message, String details) {
        errorTitle = title;
        errorMessage = message;
        errorDetails = details == null ? "" : details;
        errorPopup = false;
        screen = DEBUG;
        addLog("ERROR: " + title + " - " + message + (errorDetails.isEmpty() ? "" : " | " + errorDetails));
        postErrorNotification(title, message);
        invalidate();
    }

    void openDebugFromNotification() {
        screen = DEBUG;
        errorPopup = false;
        invalidate();
    }

    void postErrorNotification(String title, String message) {
        try {
            Context context = appContext.getApplicationContext();
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            String channelId = "fazbear_errors";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(channelId, "Fazbear Control errors", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Alerts when Fazbear Control encounters an error");
                manager.createNotificationChannel(channel);
            }
            Intent intent = new Intent(context, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.putExtra("OPEN_FAZBEAR_DEBUG", true);
            PendingIntent pending = PendingIntent.getActivity(context, 9002, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, channelId) : new Notification.Builder(context);
            Notification notification = builder.setSmallIcon(android.R.drawable.stat_notify_error)
                    .setContentTitle("Fazbear Control — " + title)
                    .setContentText(message)
                    .setStyle(new Notification.BigTextStyle().bigText(message + "\nTap to open Advanced Debug."))
                    .setContentIntent(pending).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).build();
            if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                manager.notify(9003, notification);
            }
        } catch (Exception ignored) { }
    }

    void retryError() {
        errorPopup = false;
        send(page, "[STATUS]");
        status = "STATUS REQUEST SENT";
        invalidate();
    }

    void shutdown() {
        shuttingDown = true;
        playbackPollGeneration++;
        playbackStateKnown = false;
        stopLocalWav();
        stopVuCapture();
        stopPhoneAudioReceiver();
        try { if (rxSocket != null) rxSocket.close(); } catch (Exception ignored) {}
        net.shutdownNow();
    }

    void selectAudioOutput(int mode) {
        if (mode < 0 || mode > 2) return;
        prefs.edit().putInt("audio_output_mode", mode).apply();

        // Phone receiver is needed for BOTH and PHONE-only modes.
        boolean needsPhone = (mode == 1 || mode == 2);
        stopPhoneAudioReceiver();

        if (!needsPhone) {
            send(0, "[AUDIO MAX]");
            audioOutputMode = 0;
            phoneAudioStatus = "MAX98357 ONLY SELECTED";
            status = "MAX98357 OUTPUT SELECTED";
            addLog("AUDIO OUTPUT // MAX98357 ONLY");
            invalidate();
            return;
        }

        WifiAudioReceiver receiver = new WifiAudioReceiver();
        try {
            // Start the phone receiver before requesting the ESP32 stream.
            receiver.start();
            phoneAudioReceiver = receiver;
            audioOutputMode = mode;
            if (mode == 1) {
                send(0, "[AUDIO BOTH]");
                phoneAudioStatus = "BOTH OUTPUTS • UDP 4212";
                status = "AUDIO OUTPUT // MAX98357 + PHONE";
                addLog("AUDIO OUTPUT // BOTH REQUESTED");
            } else {
                send(0, "[AUDIO PHONE]");
                phoneAudioStatus = "PHONE ONLY • UDP 4212";
                status = "AUDIO OUTPUT // PHONE ONLY";
                addLog("AUDIO OUTPUT // PHONE ONLY REQUESTED");
            }
        } catch (Exception ex) {
            audioOutputMode = 0;
            phoneAudioStatus = "PHONE RECEIVER START FAILED";
            status = "PHONE AUDIO RECEIVER FAILED";
            addLog("PHONE AUDIO START ERROR: " + ex.getMessage());
            try { receiver.close(); } catch (Exception ignored) {}
            send(0, "[AUDIO MAX]");
            showError("PHONE AUDIO ERROR", "Could not start audio receiver", String.valueOf(ex.getMessage()));
        }
        invalidate();
    }

    void stopPhoneAudioReceiver() {
        if (phoneAudioReceiver != null) {
            try { phoneAudioReceiver.close(); } catch (Exception ignored) {}
            phoneAudioReceiver = null;
        }
    }

    int accent() {
        switch (theme) {
            case 0: return 0xFFB000FF; // Neon purple
            case 1: return Color.CYAN;
            case 2: return Color.YELLOW;
            case 3: return 0xFF52FF91; // Classic Fazbear green
            case 4: return 0xFFFF3B30; // Alert red
            case 5: return 0xFF66BFFF; // Ice blue
            case 6: return 0xFFFF8C42; // Sunset orange
            case 7: return 0xFFFF66B3; // Pink
            case 8: return 0xFFE6E6E6; // Monochrome
            case 9: return 0xFFB7FF00; // Toxic lime
            case 10: return 0xFFFF7518; // Halloween orange
            default: return 0xFF52FF91;
        }
    }
    int red() { return 0xFFFF1744; }
    int panel() { return 0xFF090B14; }
    int panel2() { return 0xFF111525; }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align a) {
        p.setTypeface(appFont != null ? appFont : Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        p.setTextSize(size); p.setColor(color); p.setTextAlign(a); p.setStyle(Paint.Style.FILL);
        c.drawText(s, x, y, p);
    }

    void rect(Canvas c, float l, float t, float r, float b, int color, boolean stroke) {
        p.setColor(color); p.setStyle(stroke ? Paint.Style.STROKE : Paint.Style.FILL); p.setStrokeWidth(stroke ? 1.5f : 1);
        c.drawRect(l, t, r, b, p); p.setStyle(Paint.Style.FILL);
    }

    // Read-only volume indicator. The ESP32 potentiometer remains the only control.
    void volumeIndicator(Canvas c, float x, float y, float w, float h) {
        rect(c, x, y, x + w, y + h, 0xFF303747, false);
        rect(c, x, y, x + w, y + h, 0xFF596174, true);
        if (syncedVolume >= 0) {
            float filled = w * (Math.max(0, Math.min(100, syncedVolume)) / 100f);
            int color = syncedVolume >= 85 ? red() : syncedVolume >= 60 ? Color.YELLOW : Color.GREEN;
            if (filled > 0) rect(c, x + 1, y + 1, x + Math.max(1, filled - 1), y + h - 1, color, false);
        }
        text(c, syncedVolume >= 0 ? syncedVolume + "%" : "--%", x + w + 8, y + h, 9, Color.WHITE, Paint.Align.LEFT);
    }

    void button(Canvas c, int x, int y, int w, int h, String label, int color) {
        // Premium theme button renderer. Geometry is unchanged so all existing
        // touch targets remain aligned with the visible buttons.
        final float r = Math.min(11f, Math.max(7f, h * 0.22f));

        int base, inner, accent2, texture;
        switch (theme) {
            case 1:  // Night Shift
                base=0xFF0A2630; inner=0xFF07171F; accent2=0xFF39E8FF; texture=0x5539E8FF; break;
            case 2:  // Security
                base=0xFF26301B; inner=0xFF11170D; accent2=0xFFFFD84A; texture=0x66FFD84A; break;
            case 3:  // 8-Bit
                base=0xFF25164A; inner=0xFF100B22; accent2=0xFF65FF8A; texture=0x5565FF8A; break;
            case 4:  // Worn & Withered
                base=0xFF403431; inner=0xFF211C1A; accent2=0xFFC6A77D; texture=0x55C6A77D; break;
            case 5:  // Party
                base=0xFF3A182C; inner=0xFF1B0D19; accent2=0xFFFF6FAE; texture=0x66FF6FAE; break;
            case 6:  // Halloween
            case 10:
                base=0xFF27132F; inner=0xFF12091A; accent2=0xFFFF7A18; texture=0x66FF7A18; break;
            case 7:  // Arcade
                base=0xFF101F3A; inner=0xFF080F20; accent2=0xFF57F5FF; texture=0x6657F5FF; break;
            case 8:  // Monochrome
                base=0xFF35383D; inner=0xFF15171A; accent2=0xFFE5E7EB; texture=0x55FFFFFF; break;
            case 9:  // Toxic
                base=0xFF1A3219; inner=0xFF091409; accent2=0xFF7CFF3A; texture=0x667CFF3A; break;
            default: // Classic Fazbear
                base=0xFF21153D; inner=0xFF0D0919; accent2=0xFFD45CFF; texture=0x665F36A8; break;
        }

        // Deep offset shadow / lift.
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(0xCC020308);
        c.drawRoundRect(x+2, y+4, x+w+2, y+h+5, r+1, r+1, p);

        // Outer shell with a subtle vertical material gradient.
        p.setShader(new LinearGradient(0, y, 0, y+h,
                lighten(base, 12), darken(base, 16), Shader.TileMode.CLAMP));
        c.drawRoundRect(x, y, x+w, y+h, r, r, p);
        p.setShader(null);

        // Recessed inner face.
        p.setColor(inner);
        c.drawRoundRect(x+3, y+3, x+w-3, y+h-3, Math.max(5f,r-3), Math.max(5f,r-3), p);

        // Theme-specific material texture.
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.1f);
        p.setColor(texture);
        if (theme == 0) { // neon circuit
            for (int yy=y+7; yy<y+h-4; yy+=7) c.drawLine(x+6,yy,x+w-6,yy,p);
            for (int xx=x+10; xx<x+w-5; xx+=22) {
                c.drawLine(xx,y+5,xx,y+h-6,p);
                c.drawCircle(xx,y+7,1.5f,p);
            }
        } else if (theme == 1) { // CRT scanlines + diagonal signal traces
            for (int yy=y+5; yy<y+h; yy+=5) c.drawLine(x+5,yy,x+w-5,yy,p);
            p.setColor(0x4457F5FF);
            for (int d=-h; d<w; d+=20) c.drawLine(x+d,y+h,x+d+h,y,p);
        } else if (theme == 2) { // industrial hazard
            p.setStrokeWidth(3f);
            for (int d=-h; d<w; d+=15) c.drawLine(x+d,y+h,x+d+h,y,p);
            p.setStrokeWidth(1f);
            for (int yy=y+7; yy<y+h; yy+=12) c.drawLine(x+5,yy,x+w-5,yy,p);
        } else if (theme == 3) { // pixel circuitry
            p.setStrokeWidth(2f);
            for (int xx=x+7; xx<x+w-5; xx+=12) c.drawLine(xx,y+6,xx,y+h-6,p);
            for (int yy=y+7; yy<y+h-4; yy+=12) c.drawLine(x+6,yy,x+w-6,yy,p);
            p.setStyle(Paint.Style.FILL);
            for (int xx=x+8; xx<x+w-7; xx+=24) c.drawRect(xx,y+8,xx+3,y+11,p);
        } else if (theme == 4) { // scratched metal
            p.setStrokeWidth(1.4f);
            for (int d=-h; d<w; d+=13) c.drawLine(x+d,y+h-2,x+d+h,y+2,p);
            p.setColor(0x446B5A4B);
            for (int d=4; d<w-4; d+=27) c.drawLine(x+d,y+5,x+d+9,y+h-6,p);
        } else if (theme == 5) { // party confetti
            p.setStyle(Paint.Style.FILL);
            int[] dots={0x88FF5B7F,0x8870E7FF,0x88FFD34E,0x887CFF6B};
            int k=0;
            for (int xx=x+10; xx<x+w-7; xx+=23) {
                p.setColor(dots[k++%dots.length]);
                c.drawCircle(xx,y+8+(k%2)*4,2.2f,p);
                c.drawRect(xx+6,y+h-10-(k%3)*2,xx+9,y+h-7-(k%3)*2,p);
            }
        } else if (theme == 6 || theme == 10) { // haunted hazard / occult circuit
            p.setStrokeWidth(2.5f);
            for (int d=-h; d<w; d+=14) c.drawLine(x+d,y+h,x+d+h,y,p);
            p.setStrokeWidth(1f);
            p.setColor(0x668E44AD);
            for (int yy=y+8; yy<y+h-4; yy+=11) c.drawLine(x+6,yy,x+w-6,yy,p);
        } else if (theme == 7) { // arcade neon grid
            p.setColor(0x6640FFFF);
            for (int d=-h; d<w; d+=18) c.drawLine(x+d,y+h,x+d+h,y,p);
            p.setColor(0x66FF4FD8);
            for (int d=0; d<w; d+=24) c.drawLine(x+d,y+4,x+d+h/2f,y+h-4,p);
        } else if (theme == 8) { // monochrome brushed metal
            for (int yy=y+5; yy<y+h; yy+=6) c.drawLine(x+5,yy,x+w-5,yy,p);
            p.setColor(0x337FFFFF);
            for (int xx=x+7; xx<x+w; xx+=18) c.drawLine(xx,y+5,xx,y+h-5,p);
        } else { // toxic bio-tech
            p.setColor(0x667CFF3A);
            for (int xx=x+8; xx<x+w-5; xx+=16) {
                c.drawLine(xx,y+5,xx,y+h-5,p);
                c.drawCircle(xx,y+7,1.4f,p);
            }
            for (int yy=y+9; yy<y+h-4; yy+=10) c.drawLine(x+5,yy,x+w-5,yy,p);
        }
        p.setStyle(Paint.Style.FILL);

        // Crisp inset border and theme-colored glow.
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f);
        p.setColor(color);
        c.drawRoundRect(x+0.9f,y+0.9f,x+w-0.9f,y+h-0.9f,r,r,p);
        p.setStrokeWidth(1f);
        p.setColor(0xAA000000 | (accent2 & 0x00FFFFFF));
        c.drawRoundRect(x+4,y+4,x+w-4,y+h-4,Math.max(4,r-4),Math.max(4,r-4),p);

        // Top glass highlight and bottom shadow.
        p.setStrokeWidth(1.2f);
        p.setColor(0x99FFFFFF);
        c.drawLine(x+r,y+2.5f,x+w-r,y+2.5f,p);
        p.setColor(0x66000000);
        c.drawLine(x+r,y+h-2.5f,x+w-r,y+h-2.5f,p);

        // Tiny hardware details make the controls feel physical.
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCCB9C4D0);
        c.drawCircle(x+7,y+7,1.35f,p);
        c.drawCircle(x+w-7,y+7,1.35f,p);
        p.setColor(0x66424B58);
        c.drawCircle(x+7,y+7,2.5f,p);
        c.drawCircle(x+w-7,y+7,2.5f,p);

        float font = h >= 50 ? 11f : h >= 38 ? 9f : h >= 29 ? 8f : 7f;
        int labelColor = (theme == 8) ? 0xFFF4F4F4 : Color.WHITE;
        // Small dark backing behind text improves readability over textures.
        p.setColor(0x55000000);
        c.drawRoundRect(x+w/2f-(w*0.34f), y+h/2f-font*0.72f,
                x+w/2f+(w*0.34f), y+h/2f+font*0.75f, 5,5,p);
        text(c, label, x+w/2f, y+h/2f+font*0.34f, font, labelColor, Paint.Align.CENTER);
    }

    int lighten(int c, int amount) {
        int r=Math.min(255,((c>>16)&255)+amount);
        int g=Math.min(255,((c>>8)&255)+amount);
        int b=Math.min(255,(c&255)+amount);
        return 0xFF000000|(r<<16)|(g<<8)|b;
    }

    int darken(int c, int amount) {
        int r=Math.max(0,((c>>16)&255)-amount);
        int g=Math.max(0,((c>>8)&255)-amount);
        int b=Math.max(0,(c&255)-amount);
        return 0xFF000000|(r<<16)|(g<<8)|b;
    }


    void background(Canvas c) {
        c.drawColor(Color.BLACK);
        for (int y = 0; y < 320; y += 20) {
            p.setColor((y / 20) % 2 == 0 ? 0xFF070711 : 0xFF0A0810);
            c.drawRect(0, y, 480, y + 20, p);
        }
        rect(c, 2, 2, 478, 318, accent(), true);
    }

    void title(Canvas c, String s, String sub) {
        text(c, "FAZBEAR CONTROL", 12, 18, 10, Color.WHITE, Paint.Align.LEFT);
        text(c, s, 240, 20, 14, accent(), Paint.Align.CENTER);
        if (sub != null) text(c, sub, 240, 34, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, syncedVolume >= 0 ? (syncedVolume + "%") : "--%", 468, 16, 7, Color.WHITE, Paint.Align.RIGHT);
        text(c, "VOL SYNC", 468, 28, 5, Color.LTGRAY, Paint.Align.RIGHT);
        rect(c, 8, 40, 472, 41, accent(), false);
    }

    void nav(Canvas c, int selected) {
        rect(c, 0, 276, 480, 320, 0xFF05060B, false);
        String[] n = {"HOME", "DEVICES", "TIMELINE", "CONTROL", "SETTINGS", "DEBUG"};
        for (int i = 0; i < 6; i++) {
            int x = i * 80;
            int col = i == selected ? accent() : Color.LTGRAY;
            text(c, navIcon(i), x + 40, 292, 11, col, Paint.Align.CENTER);
            text(c, n[i], x + 40, 309, 5.5f, col, Paint.Align.CENTER);
        }
    }

    String navIcon(int i) { return new String[]{"⌂", "▣", "≋", "▶", "⚙", "!"}[i]; }

    @Override protected void onDraw(Canvas real) {
        float scale = Math.min(getWidth() / 360f, getHeight() / 800f);
        float ox = (getWidth() - 360f * scale) / 2f;
        float oy = (getHeight() - 800f * scale) / 2f;
        real.drawColor(Color.BLACK);

        // Scheduled Show has its own landscape coordinate system. Do NOT apply
        // the portrait 360x800 transform before drawing it; doing so offsets the
        // landscape canvas and creates the large black area on the left.
        if (scheduledShowActive) {
            if (getWidth() > getHeight()) {
                drawScheduledShowWide(real);
            } else {
                real.save();
                real.translate(ox, oy);
                real.scale(scale, scale);
                drawScheduledShow(real);
                real.restore();
            }
            return;
        }

        real.save();
        real.translate(ox, oy);
        real.scale(scale, scale);
        Canvas c = real;
        portraitBackground(c);
        switch (screen) {
            case HOME: portraitHome(c); break;
            case DEVICES: portraitDevices(c); break;
            case ANIMATIONS: portraitAnimations(c); break;
            case TIMELINE: portraitTimeline(c); break;
            case CONTROL: portraitControl(c); break;
            case SETTINGS: portraitSettings(c); break;
            case DEBUG: portraitDebug(c); break;
            case DIAGNOSTICS: portraitDiagnostics(c); break;
            case DEVICE_DETAIL: portraitDeviceDetail(c); break;
            case SCHEDULE: portraitSchedule(c); break;
        }
        if (screen != DEVICE_DETAIL) portraitNav(c, screen);
        if (errorPopup) portraitErrorPopup(c);
        drawThemeEffects(c);
        real.restore();
    }

    void portraitBackground(Canvas c) {
        c.drawColor(0xFF070910);
        // Subtle midnight gradient, restrained scanlines, and console edge lighting.
        p.setShader(new LinearGradient(0, 0, 360, 800, 0xFF111321, 0xFF08070E, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 360, 800, p);
        p.setShader(null);
        // Theme background photos are intentionally disabled. The portrait
        // background is always rendered in code so no theme can stretch or
        // replace the supplied high-quality character/stage artwork.
        int tint = accent();
        p.setShader(new LinearGradient(0, 0, 360, 800,
                (tint & 0x00FFFFFF) | 0x33100000,
                (tint & 0x00FFFFFF) | 0x08000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 360, 800, p); p.setShader(null);
        if (scanlinesEnabled) {
            for (int y = 0; y < 800; y += 5) {
                p.setColor(y % 10 == 0 ? 0x10000000 : 0x08000000);
                c.drawRect(0, y, 360, y + 1, p);
            }
        }
        // Faint HUD grid only in the background, kept behind all controls.
        p.setColor(0x0C9B70C8); p.setStrokeWidth(1);
        for (int x = 24; x < 360; x += 24) c.drawLine(x, 100, x, 715, p);
        for (int y = 120; y < 720; y += 24) c.drawLine(12, y, 348, y, p);
        // Subtle FNAF checker strips and glitch blocks, echoing the stage floor.
        int tile = 12;
        for (int row = 0; row < 1; row++) {
            for (int col = 0; col < 30; col++) {
                int x = col * tile;
                boolean lit = ((col + row) % 2 == 0);
                p.setColor(lit ? 0x553A1037 : 0x55200D2C);
                c.drawRect(x, 96, x + tile, 108, p);
                p.setColor(lit ? 0x55320A25 : 0x55200D2C);
                c.drawRect(x, 708, x + tile, 720, p);
            }
        }
        p.setColor(0x66FF3155); c.drawRect(12, 96, 348, 97, p);
        p.setColor(0x664F1DFF); c.drawRect(12, 719, 348, 720, p);
        rect(c, 7, 7, 353, 793, 0xFF30283E, true);
        rect(c, 11, 11, 349, 789, 0xFF4A253D, true);
        // Tiny corner status lamps give it a finished security-console feel.
        p.setColor(accent()); c.drawCircle(20, 20, 2.2f, p); c.drawCircle(340, 20, 2.2f, p);
        p.setColor(0xFF5A2434); c.drawCircle(20, 780, 2.2f, p); c.drawCircle(340, 780, 2.2f, p);
    }

    void portraitHeader(Canvas c, String heading, String sub) {
        p.setColor(0xEE0D101B);
        c.drawRoundRect(12, 14, 348, 94, 12, 12, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1);
        p.setColor(0xFF353044); c.drawRoundRect(12.5f, 14.5f, 347.5f, 93.5f, 12, 12, p);
        p.setStyle(Paint.Style.FILL);
        rect(c, 25, 24, 335, 25, 0xFFFF4D58, false);
        rect(c, 25, 91, 335, 92, 0x884D1DFF, false);
        text(c, "FAZBEAR  /  CONTROL", 180, 43, 17, 0xFFFF654F, Paint.Align.CENTER);
        text(c, heading, 180, 67, 14, accent(), Paint.Align.CENTER);
        text(c, sub == null ? "" : sub.toUpperCase(Locale.US), 180, 83, 7.5f, 0xFFB8B6C7, Paint.Align.CENTER);
    }

    void pButton(Canvas c, int x, int y, int w, int h, String label, int color) {
        button(c, x, y, w, h, label, color);
    }

    void portraitNav(Canvas c, int selected) {
        p.setColor(0xF20A0C14);
        c.drawRoundRect(12, 720, 348, 786, 12, 12, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xFF343143);
        c.drawRoundRect(12.5f, 720.5f, 347.5f, 785.5f, 12, 12, p); p.setStyle(Paint.Style.FILL);
        String[] labels = {"HOME", "DEVICES", "ANIMS", "CONTROL", "SCHEDULE", "SETTINGS"};
        int[] screens = {HOME, DEVICES, ANIMATIONS, CONTROL, SCHEDULE, SETTINGS};
        for (int i = 0; i < labels.length; i++) {
            int x = 14 + i * 55;
            int col = selected == screens[i] ? accent() : 0xFF8C8B9D;
            if (selected == screens[i]) {
                p.setColor(0x332A8EFF); c.drawRoundRect(x + 1, 727, x + 53, 778, 9, 9, p);
                rect(c, x + 7, 780, x + 47, 782, col, false);
            }
            text(c, new String[]{"⌂", "▣", "▤", "▶", "◷", "⚙"}[i], x + 27, 750, 14, col, Paint.Align.CENTER);
            text(c, labels[i], x + 27, 770, 5.7f, col, Paint.Align.CENTER);
        }
    }

    void portraitAnimations(Canvas c) {
        portraitHeader(c, "ANIMATIONS", "8 SHOW SLOTS  •  EDIT NAME / IMAGE");
        for (int i = 0; i < 8; i++) {
            int col = i % 2, row = i / 2;
            int x = 20 + col * 164, y = 112 + row * 145;
            rect(c, x, y, x + 156, y + 132, panel2(), false);
            rect(c, x, y, x + 156, y + 132, i + 1 == selectedAnimation ? accent() : 0xFF3B2D50, true);
            Bitmap thumb = customAnimImages[i] != null ? customAnimImages[i] : chars[i == 0 ? 1 : i == 1 ? 0 : i == 2 ? 2 : i == 4 ? 3 : i % 4];
            image(c, thumb, new RectF(x + 6, y + 6, x + 150, y + 76));
            text(c, (i + 1) + ". " + animNames[i], x + 8, y + 91, 7.5f, Color.WHITE, Paint.Align.LEFT);
            pButton(c, x + 5, y + 98, 46, 27, "NAME", 0xFF303444);
            pButton(c, x + 55, y + 98, 44, 27, "IMG", 0xFF303444);
            pButton(c, x + 103, y + 98, 48, 27, "WAV", animWavUris[i] != null ? 0xFF246B48 : 0xFF303444);
        }
    }

    void editAnimationName(int slot) {
        if (slot < 0 || slot >= 8) return;
        EditText input = new EditText(appContext);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(animNames[slot]);
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(appContext)
                .setTitle("Rename Animation " + (slot + 1))
                .setMessage("Choose a name for this animation.")
                .setView(input)
                .setNegativeButton("CANCEL", (dialog, which) -> dialog.dismiss())
                .setNeutralButton("DEFAULT", (dialog, which) -> {
                    String[] defaults = {"Animation 1", "Welcome Show", "Song 1", "Song 2", "Wave", "Point", "Laugh", "Custom"};
                    animNames[slot] = defaults[slot];
                    prefs.edit().remove("animName" + slot).apply();
                    addLog("ANIMATION " + (slot + 1) + " NAME RESET");
                    invalidate();
                })
                .setPositiveButton("SAVE", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Animation " + (slot + 1);
                    if (name.length() > 24) name = name.substring(0, 24).trim();
                    animNames[slot] = name;
                    prefs.edit().putString("animName" + slot, name).apply();
                    addLog("ANIMATION " + (slot + 1) + " RENAMED: " + name);
                    invalidate();
                }).show();
    }

    void chooseWavFile() { chooseWavFileForAnimation(-1); }

    void chooseWavFileForAnimation(int slot) {
        pendingWavAnimationSlot = slot;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Android providers label WAV files inconsistently (audio/wav, audio/x-wav,
        // audio/vnd.wave, or application/octet-stream). Use a broad picker filter
        // so valid WAV files are not greyed out by the system file browser.
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, "Select a WAV audio file");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_WAV_AUDIO); }
        catch (Exception ex) { addLog("WAV PICKER ERROR: " + ex.getMessage()); status = "WAV PICKER FAILED"; }
    }

    void handleWavResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PICK_WAV_AUDIO || resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        android.net.Uri uri = data.getData();
        String pickedName = getFileName(uri);
        String pickedType = appContext.getContentResolver().getType(uri);
        boolean looksLikeWav = pickedName.toLowerCase(java.util.Locale.ROOT).endsWith(".wav")
                || (pickedType != null && pickedType.toLowerCase(java.util.Locale.ROOT).contains("wav"));
        if (!looksLikeWav) {
            status = "PLEASE SELECT A .WAV FILE";
            addLog("WAV PICKER: rejected non-WAV file " + pickedName + " (" + pickedType + ")");
            invalidate();
            return;
        }
        try { appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
        if (pendingWavAnimationSlot >= 0 && pendingWavAnimationSlot < 8) {
            int slot = pendingWavAnimationSlot;
            animWavUris[slot] = uri.toString();
            animWavNames[slot] = pickedName;
            prefs.edit().putString("animWavUri" + slot, animWavUris[slot])
                    .putString("animWavName" + slot, animWavNames[slot]).apply();
            selectedAnimation = slot + 1;
            status = "WAV ASSIGNED: " + animNames[slot];
            addLog("WAV ASSIGNED // " + animNames[slot] + " <- " + pickedName);
        } else {
            selectedWavUri = uri.toString();
            selectedWavName = pickedName;
            prefs.edit().putString("selected_wav_uri", selectedWavUri).putString("selected_wav_name", selectedWavName).apply();
            status = "WAV SELECTED: " + selectedWavName;
            addLog("WAV SELECTED: " + selectedWavName);
        }
        pendingWavAnimationSlot = -1;
        stopLocalWav();
        currentTrackName = pickedName;
        invalidate();
    }

    void chooseIntermissionWavs() {
        chooseCountdownWavSlot(1);
    }

    void chooseCountdownWavSlot(int slot) {
        int requestCode = slot == 1 ? PICK_COUNTDOWN_WAV1 : PICK_COUNTDOWN_WAV2;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // The picker may show all files on some Android versions, so handleIntermissionWavResult
        // performs the authoritative .wav/type validation and rejects everything else.
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_TITLE, slot == 1
                ? "Select WAV 1 • First Half Countdown"
                : "Select WAV 2 • Second Half Countdown");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, requestCode); }
        catch (Exception ex) { status = "COUNTDOWN WAV PICKER FAILED"; addLog("COUNTDOWN WAV PICKER ERROR: " + ex.getMessage()); invalidate(); }
    }

    void handleIntermissionWavResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null) return;
        if (requestCode != PICK_COUNTDOWN_WAV1 && requestCode != PICK_COUNTDOWN_WAV2) return;
        android.net.Uri uri = data.getData();
        if (uri == null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
            uri = data.getClipData().getItemAt(0).getUri();
        }
        if (uri == null) return;

        String name = getFileName(uri);
        String type = appContext.getContentResolver().getType(uri);
        boolean extensionLooksWav = name != null && name.toLowerCase(Locale.ROOT).endsWith(".wav");
        boolean mimeLooksWav = type != null && type.toLowerCase(Locale.ROOT).contains("wav");
        boolean headerLooksWav = false;
        if (extensionLooksWav || mimeLooksWav) {
            try (java.io.InputStream in = appContext.getContentResolver().openInputStream(uri)) {
                if (in != null) {
                    byte[] h = new byte[12];
                    int n = 0, r;
                    while (n < h.length && (r = in.read(h, n, h.length - n)) > 0) n += r;
                    headerLooksWav = n >= 12
                            && h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F'
                            && h[8] == 'W' && h[9] == 'A' && h[10] == 'V' && h[11] == 'E';
                }
            } catch (Exception ignored) { }
        }
        boolean wav = extensionLooksWav && headerLooksWav;
        if (!wav) {
            status = "ERROR: WRONG FILE TYPE • WAV ONLY";
            addLog("COUNTDOWN WAV ERROR // WRONG FILE TYPE // " + name + " // " + type);
            invalidate();
            return;
        }
        try { appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }

        if (requestCode == PICK_COUNTDOWN_WAV1) {
            countdownWav1Uri = uri.toString();
            countdownWav1Name = name;
            status = "WAV 1 SAVED • FIRST HALF • AUTO LOOP";
            addLog("COUNTDOWN WAV 1 // FIRST HALF // AUTO LOOP // " + name);
        } else {
            countdownWav2Uri = uri.toString();
            countdownWav2Name = name;
            status = "WAV 2 SAVED • SECOND HALF • AUTO LOOP";
            addLog("COUNTDOWN WAV 2 // SECOND HALF // AUTO LOOP // " + name);
        }
        saveCountdownWavs();
        invalidate();
    }

    void saveCountdownWavs() {
        prefs.edit()
                .putString("countdown_wav1_uri", countdownWav1Uri == null ? "" : countdownWav1Uri)
                .putString("countdown_wav1_name", countdownWav1Name == null ? "FIRST HALF WAV" : countdownWav1Name)
                .putString("countdown_wav2_uri", countdownWav2Uri == null ? "" : countdownWav2Uri)
                .putString("countdown_wav2_name", countdownWav2Name == null ? "SECOND HALF WAV" : countdownWav2Name)
                .apply();
    }

    void loadCountdownWavs() {
        countdownWav1Uri = prefs.getString("countdown_wav1_uri", countdownWav1Uri);
        countdownWav1Name = prefs.getString("countdown_wav1_name", countdownWav1Name);
        countdownWav2Uri = prefs.getString("countdown_wav2_uri", countdownWav2Uri);
        countdownWav2Name = prefs.getString("countdown_wav2_name", countdownWav2Name);
    }

    void playCountdownWavForCurrentHalf() {
        loadCountdownWavs();
        long now = System.currentTimeMillis();
        if (!scheduledShowActive || scheduledShowPhase != 0 || now >= scheduledShowTargetMs) return;
        int half = now >= scheduledCountdownMidpointMs ? 2 : 1;
        countdownWavHalf = half;
        String uri = half == 1 ? countdownWav1Uri : countdownWav2Uri;
        String name = half == 1 ? countdownWav1Name : countdownWav2Name;
        if (uri != null && !uri.isEmpty()) playLocalWav(uri, name);
        else { status = half == 1 ? "FIRST HALF COUNTDOWN WAV NOT SET" : "SECOND HALF COUNTDOWN WAV NOT SET"; addLog(status); }
    }

    void applyCountdownWavFade(long now) {
        if (!scheduledShowActive || scheduledShowPhase != 0 || localWavPlayer == null || !localWavPlaying) return;
        long midpoint = scheduledCountdownMidpointMs;
        long remainingToMidpoint = midpoint - now;

        // WAV 1: fade out during the final 10 seconds of the first half.
        // At the midpoint it is fully silent and WAV 2 takes over.
        if (countdownWavHalf == 1) {
            if (remainingToMidpoint <= 0L) {
                try { localWavPlayer.setVolume(0f, 0f); } catch (Exception ignored) { }
                return;
            }
            if (remainingToMidpoint < 10_000L) {
                float volume = remainingToMidpoint / 10_000f;
                try { localWavPlayer.setVolume(volume, volume); } catch (Exception ignored) { }
            } else {
                try { localWavPlayer.setVolume(1f, 1f); } catch (Exception ignored) { }
            }
            return;
        }

        // WAV 2: remain at full volume until the final 20 seconds, then fade
        // smoothly to silence exactly at showtime.
        long remaining = Math.max(0L, scheduledShowTargetMs - now);
        long fadeMs = 20_000L;
        float volume = remaining >= fadeMs ? 1f : remaining <= 0L ? 0f : remaining / (float) fadeMs;
        try { localWavPlayer.setVolume(volume, volume); } catch (Exception ignored) { }
    }

    void loadIntermissionPlaylist() {
        intermissionWavUris.clear();
        intermissionWavNames.clear();
        String saved = prefs.getString("intermission_wav_playlist", "[]");
        try {
            org.json.JSONArray arr = new org.json.JSONArray(saved);
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject item = arr.optJSONObject(i);
                if (item == null) continue;
                String uri = item.optString("uri", "");
                String name = item.optString("name", "Intermission WAV");
                if (!uri.isEmpty()) { intermissionWavUris.add(uri); intermissionWavNames.add(name); }
            }
        } catch (Exception ex) { addLog("INTERMISSION PLAYLIST LOAD ERROR: " + ex.getMessage()); }
    }

    void saveIntermissionPlaylist() {
        org.json.JSONArray arr = new org.json.JSONArray();
        for (int i = 0; i < intermissionWavUris.size(); i++) {
            org.json.JSONObject item = new org.json.JSONObject();
            try { item.put("uri", intermissionWavUris.get(i)); item.put("name", intermissionWavNames.get(i)); arr.put(item); }
            catch (Exception ignored) { }
        }
        prefs.edit().putString("intermission_wav_playlist", arr.toString()).apply();
    }

    void startIntermissionPlaylist() {
        if (!intermissionWavUris.isEmpty()) {
            intermissionWavIndex = 0;
            playIntermissionTrackAtIndex();
        } else if (selectedWavUri != null && !selectedWavUri.isEmpty()) {
            playLocalWav(selectedWavUri, selectedWavName);
        } else {
            status = "INTERMISSION MUSIC NOT SELECTED";
            addLog("SCHEDULED SHOW // NO INTERMISSION WAV SELECTED");
        }
    }

    void playIntermissionTrackAtIndex() {
        if (intermissionWavUris.isEmpty()) return;
        intermissionWavIndex = Math.floorMod(intermissionWavIndex, intermissionWavUris.size());
        playLocalWav(intermissionWavUris.get(intermissionWavIndex), intermissionWavNames.get(intermissionWavIndex));
    }

    void playNextIntermissionTrack() {
        if (!scheduledShowActive || scheduledShowPhase != 0 || System.currentTimeMillis() >= scheduledShowTargetMs) return;
        if (!intermissionWavUris.isEmpty()) {
            intermissionWavIndex = (intermissionWavIndex + 1) % intermissionWavUris.size();
            playIntermissionTrackAtIndex();
        } else if (selectedWavUri != null && !selectedWavUri.isEmpty()) {
            playLocalWav(selectedWavUri, selectedWavName);
        }
    }

    String getFileName(android.net.Uri uri) {
        String name = uri.getLastPathSegment();
        try (android.database.Cursor cursor = appContext.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) { }
        return name == null || name.trim().isEmpty() ? "Selected WAV" : name;
    }

    void playLocalWav() {
        if (selectedWavUri == null) { chooseWavFile(); return; }
        playLocalWav(selectedWavUri, selectedWavName);
    }

    String getNumberedFreddyWavName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (!n.matches("\\d{4}\\.wav")) return null;
        return n;
    }

    void sendAssignedFreddyWav(int slot) {
        if (slot < 0 || slot >= 8) return;
        String name = getNumberedFreddyWavName(animWavNames[slot]);
        if (name == null) {
            addLog("FREDDY SD AUDIO SKIPPED // WAV must be 0001.wav, 0002.wav, etc.");
            return;
        }
        // Freddy firmware maps [AUDIO FILE 0002.wav] to /audio/0002.wav.
        // Only MAX/BOTH request SD playback; PHONE mode remains phone-only.
        if (audioOutputMode == 0 || audioOutputMode == 1) {
            send(0, "[AUDIO FILE " + name + "]");
            addLog("FREDDY SD AUDIO // /audio/" + name);
        }
    }

    private boolean animationWavIsAssignedAndDetectable(int slot) {
        if (slot < 0 || slot >= animWavUris.length) return false;
        String uri = animWavUris[slot];
        if (uri == null || uri.trim().isEmpty()) return false;
        try {
            android.net.Uri parsed = android.net.Uri.parse(uri);
            if (parsed == null) return false;
            android.content.res.AssetFileDescriptor afd =
                    appContext.getContentResolver().openAssetFileDescriptor(parsed, "r");
            if (afd == null) return false;
            afd.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    private int findNextDetectableAssignedWav(int fromSlot) {
        int count = Math.min(animWavUris.length, 8);
        if (count <= 0) return -1;

        int start = Math.max(0, Math.min(fromSlot, count - 1));

        // Animation 7 and 8 are optional. They are skipped whenever their WAV
        // is not assigned/detectable. The check is performed every time the
        // show advances, so uploading a WAV later automatically enables them.
        for (int n = 0; n < count; n++) {
            int slot = (start + n) % count;

            if ((slot == 6 || slot == 7) && !animationWavIsAssignedAndDetectable(slot)) {
                continue;
            }

            if (animationWavIsAssignedAndDetectable(slot)) {
                return slot;
            }
        }
        return -1;
    }

    private void finishScheduledShowBecauseNoWavs() {
        long now = System.currentTimeMillis();

        // Stop everything that could still be playing.
        stopLocalWav();
        ScheduledShowReceiver.stopPhoneAudio();
        autoplay = false;
        manualShowRunning = false;
        main.removeCallbacks(manualAdvanceRunnable);
        for (int i = 0; i < 4; i++) send(i, "[STOP]");
        sendBottangoPlayback("{\"isPlaying\":false}", "NO WAV FILES // SHOW STOPPED");

        // IMPORTANT: this is not a normal show completion. Keep the scheduled
        // show active and immediately restart the ORIGINAL countdown interval.
        selectedAnimation = 1;
        currentTrackName = animNames[0];
        scheduledShowFinished = false;
        scheduledShowPhase = 0;
        intermissionMusicStarted = false;

        long repeatInterval = scheduledRepeatIntervalMs;
        if (repeatInterval <= 0L) {
            repeatInterval = Math.max(1000L, nextScheduledShowTime() - now);
        }
        scheduledRepeatIntervalMs = repeatInterval;
        scheduledShowTargetMs = now + repeatInterval;
        scheduledCountdownStartMs = now;
        scheduledCountdownValue = (int)Math.min(Integer.MAX_VALUE,
                Math.max(0L, (scheduledShowTargetMs - now + 999L) / 1000L));

        // Show the error directly in the countdown for a few seconds, then
        // return to the restarted numeric countdown.
        scheduledCountdownErrorUntilMs = now + 3500L;
        status = "WAV ERROR // NO DETECTABLE WAV FILES";
        addLog("SCHEDULED SHOW // NO WAV FILES DETECTED AT SHOW START");
        addLog("SCHEDULED SHOW // TIMER RESTARTED FROM ORIGINAL INTERVAL");
        activateBottangoIdlePose("NO WAV FILES // TIMER RESTARTED");
        invalidate();
    }

    void playAssignedWavForSelectedAnimation() {
        int slot = selectedAnimation - 1;
        if (slot < 0 || slot >= 8) return;

        // Missing/unreadable assignment: skip forward to the next detectable WAV.
        // If there are no playable assignments anywhere in the show, end the
        // scheduled show; the normal scheduled-show completion path resets the
        // countdown to the next occurrence using the original schedule.
        int playableSlot = findNextDetectableAssignedWav(slot);
        if (playableSlot < 0) {
            if (scheduledShowActive || manualShowRunning) {
                finishScheduledShowBecauseNoWavs();
            } else {
                addLog("NO DETECTABLE WAV // ANIMATION " + (slot + 1));
                status = "NO WAV ASSIGNED";
                invalidate();
            }
            return;
        }
        if (playableSlot != slot) {
            addLog("ANIMATION " + (slot + 1) + " WAV MISSING // SKIP TO ANIMATION " + (playableSlot + 1));
            selectedAnimation = playableSlot + 1;
            currentTrackName = animNames[playableSlot];
            playbackTimeMs = 0;
            slot = playableSlot;
        }

        String uri = animWavUris[slot];

        // Guard against duplicate animation-start callbacks (for example a
        // scheduled start plus a Bottango/start callback arriving together).
        // The same slot/URI is allowed again after the short duplicate window.
        long now = System.currentTimeMillis();
        if (uri != null && uri.equals(lastStartedWavUri)
                && slot == lastStartedWavSlot && now - lastStartedWavAt < 1500L) {
            addLog("WAV DUPLICATE START SUPPRESSED // ANIMATION " + (slot + 1));
            return;
        }
        lastStartedWavSlot = slot;
        lastStartedWavUri = uri;
        lastStartedWavAt = now;

        // MAX ONLY: do not start a second phone player; tell Freddy to play the
        // matching numbered file from its SD card.
        if (audioOutputMode == 0) {
            stopLocalWav();
            sendAssignedFreddyWav(slot);
            return;
        }

        // BOTH: phone plays its assigned WAV and Freddy plays the matching SD WAV.
        if (audioOutputMode == 1) sendAssignedFreddyWav(slot);

        // PHONE ONLY/BOTH retain the existing local phone playback behavior.
        if (uri == null || uri.isEmpty()) { stopLocalWav(); return; }
        playLocalWav(uri, animWavNames[slot] == null ? animNames[slot] : animWavNames[slot]);
    }

    void playLocalWav(String wavUri, String wavName) {
        if (wavUri == null) { chooseWavFile(); return; }
        stopLocalWav();
        final int playbackGeneration = localWavGeneration;
        try {
            MediaPlayer player = new MediaPlayer();
            player.setDataSource(appContext, android.net.Uri.parse(wavUri));
            player.setOnPreparedListener(mp -> {
                // A stop/exit may happen while prepareAsync() is pending. Never
                // allow that stale callback to restart music after the show stops.
                if (playbackGeneration != localWavGeneration) {
                    localWavPlayers.remove(mp);
                    try { mp.release(); } catch (Exception ignored) { }
                    return;
                }
                localWavPlayer = mp;
                durationMs = mp.getDuration();
                long pendingSeek = pendingBottangoSeekMs;
                pendingBottangoSeekMs = -1L;
                playbackTimeMs = 0;
                if (pendingSeek >= 0) {
                    try {
                        int seekTarget = (int) Math.max(0L, Math.min((long) mp.getDuration(), pendingSeek));
                        mp.seekTo(seekTarget);
                        playbackTimeMs = seekTarget;
                        addLog("BOTTANGO SEEK // PHONE WAV PREPARED AT " + seekTarget + " ms");
                    } catch (Exception ignored) { }
                }
                if (localWavPausedByBottango) {
                    localWavPlaying = false;
                    status = "PAUSED: " + wavName;
                    addLog("LOCAL WAV PREPARED WHILE BOTTANGO PAUSED // " + wavName);
                } else {
                    localWavPlaying = true;
                    mp.start();
                    status = "PLAYING: " + wavName;
                }
                invalidate();
            });
            player.setOnCompletionListener(mp -> {
                if (playbackGeneration != localWavGeneration) {
                    try { mp.release(); } catch (Exception ignored) { }
                    return;
                }
                localWavPlaying = false;
                playbackTimeMs = durationMs > 0 ? durationMs : playbackTimeMs;
                if (localWavPlayer == mp) localWavPlayer = null;
                localWavPlayers.remove(mp);
                try { mp.release(); } catch (Exception ignored) { }
                if (scheduledShowActive && scheduledShowPhase == 0
                        && System.currentTimeMillis() < scheduledShowTargetMs) {
                    playCountdownWavForCurrentHalf();
                } else if (scheduledShowActive && scheduledShowPhase == 2 && !scheduledShowFinished) {
                    // Phone audio is the authoritative completion signal when no ESP32
                    // controllers are connected. Bottango polling can also report an
                    // animation end; advanceScheduledShowAfterAnimationDone() has a
                    // short duplicate lock so the two signals cannot double-advance.
                    addLog("SCHEDULED SHOW // PHONE WAV COMPLETE // AUTO NEXT");
                    advanceScheduledShowAfterAnimationDone();
                    invalidate();
                } else {
                    status = "WAV PLAYBACK COMPLETE";
                    invalidate();
                }
            });
            player.setOnErrorListener((mp, what, extra) -> {
                if (playbackGeneration != localWavGeneration) {
                    localWavPlayers.remove(mp);
                    try { mp.release(); } catch (Exception ignored) { }
                    return true;
                }
                localWavPlayers.remove(mp);
                if (localWavPlayer == mp) localWavPlayer = null;
                localWavPlaying = false;
                status = "WAV PLAYBACK ERROR";
                addLog("WAV PLAYBACK ERROR: " + what + "/" + extra);
                invalidate();
                return true;
            });
            localWavPlayer = player;
            localWavPlayers.add(player);
            player.prepareAsync();
        } catch (Exception ex) {
            stopLocalWav();
            status = "WAV PLAYBACK FAILED";
            addLog("WAV PLAYBACK ERROR: " + ex.getMessage());
            showError("WAV PLAYBACK ERROR", "Could not play selected WAV", String.valueOf(ex.getMessage()));
        }
    }

    void seekLocalWavFromBottango(long positionMs) {
        MediaPlayer player = localWavPlayer;
        if (positionMs < 0) return;
        if (player == null) {
            pendingBottangoSeekMs = positionMs;
            return;
        }
        try {
            int target = (int) Math.max(0L, Math.min((long) player.getDuration(), positionMs));
            player.seekTo(target);
            playbackTimeMs = target;
            addLog("BOTTANGO SEEK // PHONE WAV -> " + target + " ms");
            invalidate();
        } catch (Exception e) {
            addLog("BOTTANGO SEEK // PHONE WAV FAILED // " + e.getMessage());
        }
    }

    void startOrResumeLocalWavFromBottango() {
        MediaPlayer player = localWavPlayer;
        if (player != null && localWavPausedByBottango) {
            resumeLocalWavFromBottango();
            return;
        }
        if (player != null) {
            try {
                if (player.isPlaying()) return;
            } catch (Exception ignored) { }
        }
        int slot = Math.max(0, Math.min(animWavUris.length - 1, selectedAnimation - 1));
        String uri = slot >= 0 && slot < animWavUris.length ? animWavUris[slot] : null;
        if (uri != null && !uri.isEmpty() && audioOutputMode != 0) {
            playLocalWav(uri, animWavNames[slot] == null ? animNames[slot] : animWavNames[slot]);
        }
    }

    void pauseLocalWavFromBottango() {
        MediaPlayer player = localWavPlayer;
        if (player == null) return;
        localWavPausedByBottango = true;
        try {
            if (player.isPlaying()) player.pause();
            localWavPlaying = false;
            addLog("BOTTANGO PAUSED // PHONE WAV PAUSED");
            invalidate();
        } catch (Exception ignored) { }
    }

    void resumeLocalWavFromBottango() {
        MediaPlayer player = localWavPlayer;
        if (player == null || !localWavPausedByBottango) return;
        try {
            player.start();
            localWavPausedByBottango = false;
            localWavPlaying = true;
            addLog("BOTTANGO RESUMED // PHONE WAV RESUMED");
            invalidate();
        } catch (Exception ignored) { }
    }

    void stopLocalWav() {
        // Invalidate any pending prepare/completion/error callback before releasing.
        localWavGeneration++;
        localWavPlayer = null;
        localWavPlaying = false;
        localWavPausedByBottango = false;
        lastStartedWavSlot = -1;
        lastStartedWavAt = 0L;
        lastStartedWavUri = null;
        // Stop every player, not just the most recently assigned reference. This
        // also releases any player whose asynchronous preparation is still pending.
        MediaPlayer[] players = localWavPlayers.toArray(new MediaPlayer[0]);
        localWavPlayers.clear();
        for (MediaPlayer player : players) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) { }
            try { player.reset(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
        }
    }

    void chooseAnimationImage(int slot) {
        pendingImageSlot = slot;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_ANIMATION_IMAGE); }
        catch (Exception ex) { addLog("IMAGE PICKER ERROR: " + ex.getMessage()); }
    }

    void handleImageResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        android.net.Uri uri = data.getData();
        if (requestCode == PICK_CHARACTER_IMAGE && pendingThemeCharacterTheme >= 0 && pendingThemeCharacterSlot >= 0) {
            int themeId = pendingThemeCharacterTheme;
            int slot = pendingThemeCharacterSlot;
            try {
                appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            themeCharUris[themeId][slot] = uri.toString();
            loadThemeCharacterImage(themeId, slot, uri);
            prefs.edit().putString("theme_char_" + themeId + "_" + slot, uri.toString()).apply();
            addLog("THEME PHOTO UPDATED: " + themeName(themeId) + " / " + (slot + 1));
            pendingThemeCharacterTheme = -1;
            pendingThemeCharacterSlot = -1;
            invalidate();
            return;
        }
        if (requestCode == PICK_CHARACTER_IMAGE && pendingCharacterSlot >= 0) {
            int slot = pendingCharacterSlot;
            try {
                appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            loadCustomCharacterImage(slot, uri);
            customCharUris[slot] = uri.toString();
            prefs.edit().putString("charImage" + slot, uri.toString()).apply();
            addLog("CUSTOM CHARACTER / STAGE IMAGE UPDATED: " + (slot + 1));
            pendingCharacterSlot = -1;
            invalidate();
            return;
        }
        if (requestCode == PICK_THEME_BACKGROUND) {
            try { appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            customBackgroundUri = uri.toString();
            themeBackgroundUris[theme] = customBackgroundUri;
            prefs.edit().putString("theme_bg_" + theme, customBackgroundUri).putString("theme_background", customBackgroundUri).apply();
            loadThemeBackground(theme, uri);
            addLog("BACKGROUND UPDATED FOR " + themeName(theme));
            invalidate(); return;
        }
        if (requestCode == PICK_HOME_MEDIA) {
            try { appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            homeCustomMediaUri = uri.toString();
            prefs.edit().putString("home_custom_media", homeCustomMediaUri).apply();
            loadHomeMedia(uri);
            addLog("HOME SCREEN PHOTO / GIF UPDATED");
            invalidate(); return;
        }
        if (requestCode != PICK_ANIMATION_IMAGE || pendingImageSlot < 0) return;
        try {
            appContext.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        loadCustomAnimationImage(pendingImageSlot, uri);
        customAnimUris[pendingImageSlot] = uri.toString();
        prefs.edit().putString("animImage" + pendingImageSlot, uri.toString()).apply();
        addLog("CUSTOM IMAGE SET FOR ANIMATION " + (pendingImageSlot + 1));
        pendingImageSlot = -1;
        invalidate();
    }

    void loadCustomAnimationImage(int slot, android.net.Uri uri) {
        try (java.io.InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) customAnimImages[slot] = BitmapFactory.decodeStream(in);
        } catch (Exception ex) { addLog("IMAGE LOAD ERROR: SLOT " + (slot + 1)); }
    }

    void portraitHome(Canvas c) {
        portraitHeader(c, "SECURITY TERMINAL", "WIRELESS SHOW CONTROL");
        text(c, "PHONE WI-FI", 246, 92, 7, Color.LTGRAY, Paint.Align.LEFT);
        signalBars(c, 292, 104, phoneWifiBars(), phoneWifiBars() >= 3 ? 0xFF43D17D : 0xFFFFC857, 5, 3, 15);
        RectF gifBox = new RectF(24, 112, 336, 342);
        drawHomeCustomMedia(c, gifBox);
        text(c, "LET'S PUT ON A SHOW!", 180, 366, 17, red(), Paint.Align.CENTER);
        int on = 0; for (boolean b : online) if (b) on++;
        p.setColor(0xEE101421); c.drawRoundRect(24, 382, 336, 444, 11, 11, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xFF353247);
        c.drawRoundRect(24.5f, 382.5f, 335.5f, 443.5f, 11, 11, p); p.setStyle(Paint.Style.FILL);
        rect(c, 24, 382, 28, 444, on == 4 ? 0xFF43D17D : accent(), false);
        text(c, "LIVE SYSTEM STATUS", 40, 402, 8, 0xFFB5B4C4, Paint.Align.LEFT);
        text(c, "CONTROLLERS ONLINE", 40, 421, 10, Color.WHITE, Paint.Align.LEFT);
        text(c, on + " / 4", 320, 424, 22, on == 4 ? 0xFF43D17D : 0xFFFFC857, Paint.Align.RIGHT);
        for (int i = 0; i < 4; i++) {
            float sx = 45 + i * 74;
            // Give each controller name its own row; keep signal bars beneath it.
            text(c, names[i], sx + 13, 430, 6, Color.LTGRAY, Paint.Align.CENTER);
            int wifiBars = controllerWifiBars(i);
            int wifiColor = wifiBars >= 3 ? 0xFF43D17D : (wifiBars > 0 ? 0xFFFFC857 : 0xFF454754);
            signalBars(c, sx, 442, wifiBars, wifiColor, 4, 2, 6);
        }
        // Tiny live diagnostics belong on the portrait Home screen (the screen shown in the UI).
        int bestRssi = -127;
        long newestRx = 0L;
        for (int i = 0; i < 4; i++) {
            if (controllerWifiRssi[i] > bestRssi && lastWifiSeen[i] > 0L) bestRssi = controllerWifiRssi[i];
            if (lastSeen[i] > newestRx) newestRx = lastSeen[i];
        }
        String wifiSummary = bestRssi > -127 ? bestRssi + " dBm" : "N/A";
        String bottangoSummary = !lastPlaybackError.isEmpty() ? "ERROR" : playbackStateKnown ? "ONLINE" : "WAITING";
        String rxSummary = newestRx > 0L ? ageLabel(newestRx) : "NEVER";
        text(c, "SYS " + on + "/4 | WIFI " + wifiSummary + " | BOTTANGO " + bottangoSummary,
                180, 453, 4.5f, 0xFFB8B6C7, Paint.Align.CENTER);
        text(c, "LAST RX " + rxSummary, 180, 458, 4.0f, 0xFF85899A, Paint.Align.CENTER);
        pButton(c, 24, 464, 312, 56, "▶  START SHOW", accent());
        pButton(c, 24, 534, 312, 48, "MANAGE DEVICES", 0xFF252039);
        // Quick WAV playback is available directly from Home; Timeline remains one tap away.
        pButton(c, 24, 594, 152, 48, "TIMELINE", 0xFF252039);
        pButton(c, 184, 594, 152, 48, localWavPlaying ? "■ STOP WAV" : "▶ PLAY WAV",
                localWavPlaying ? red() : Color.GREEN);
        // Keep the Show Control button separate from the read-only volume display.
        pButton(c, 24, 634, 312, 42, "SHOW CONTROL", 0xFF252039);
        text(c, "VOLUME LEVEL  •  ESP32 POTENTIOMETER", 24, 687, 7, Color.LTGRAY, Paint.Align.LEFT);
        volumeIndicator(c, 24, 696, 250, 9);
    }

    long nextScheduledShowTime() {
        return ScheduleAlarm.nextTime(scheduleHour, scheduleMinute, scheduleDays, System.currentTimeMillis());
    }

    // Ask Bottango for its actual exported/project animation list. This is
    // deliberately name-based so "idle" still works if Bottango assigns it a
    // different index when the animations are transferred/exported.
    void refreshBottangoIdleAnimation() {
        net.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(BOTTANGO_PLAYBACK_URL.replace("/PlaybackState/", "/Animations/"));
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(3000);
                connection.setReadTimeout(3000);
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                }

                JSONObject root = new JSONObject(body.toString());
                org.json.JSONArray list = null;
                String[] keys = {"animations", "animationNames", "data", "items"};
                for (String key : keys) {
                    Object value = root.opt(key);
                    if (value instanceof org.json.JSONArray) {
                        list = (org.json.JSONArray) value;
                        break;
                    }
                }

                int foundIndex = -1;
                if (list != null) {
                    for (int i = 0; i < list.length(); i++) {
                        Object item = list.opt(i);
                        String name = "";
                        int index = i;
                        if (item instanceof String) {
                            name = (String) item;
                        } else if (item instanceof JSONObject) {
                            JSONObject obj = (JSONObject) item;
                            name = obj.optString("name",
                                    obj.optString("animationName",
                                    obj.optString("selectedAnimationName", "")));
                            index = obj.has("index") ? obj.optInt("index", i)
                                    : obj.has("animationIndex") ? obj.optInt("animationIndex", i) : i;
                        }
                        if (BOTTANGO_IDLE_ANIMATION_NAME.equalsIgnoreCase(name.trim())) {
                            foundIndex = index;
                            break;
                        }
                    }
                }

                final int idleIndex = foundIndex;
                main.post(() -> {
                    bottangoIdleAnimationIndex = idleIndex;
                    bottangoIdleAnimationAvailable = idleIndex >= 0;
                    if (idleIndex >= 0) {
                        addLog("BOTTANGO // FOUND IDLE ANIMATION: \"" + BOTTANGO_IDLE_ANIMATION_NAME
                                + "\" AT INDEX " + idleIndex);
                    } else {
                        addLog("BOTTANGO // IDLE ANIMATION NOT FOUND");
                    }
                    invalidate();
                });
            } catch (Exception ex) {
                main.post(() -> addLog("BOTTANGO // IDLE DETECTION FAILED: " + ex.getMessage()));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    void activateBottangoIdlePose(String reason) {
        refreshBottangoIdleAnimation();
        // Use the animation NAME in the command, not its index. Bottango's REST
        // API resolves the name to the correct index in the current project.
        sendBottangoPlayback(
                "{\"selectedAnimationName\":\""
                        + BOTTANGO_IDLE_ANIMATION_NAME
                        + "\",\"playbackTimeInMS\":0,\"isPlaying\":true}",
                "IDLE POSE  // " + reason);
        addLog("SCHEDULED SHOW // REQUESTING BOTTANGO IDLE A-POSE");
    }

    void startScheduledShow() {
        stopScheduledShow(false);
        // The live show-timer is intentionally wide so the uploaded 1536x709 stage
        // artwork is displayed without stretching. The rest of the app remains portrait.
        try { ((Activity) appContext).setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); } catch (Exception ignored) { }
        scheduledShowActive = true;
        scheduledShowFinished = false;
        scheduledAdvanceLockUntilMs = 0L;
        scheduledShowPhase = 0;
        scheduledShowTargetMs = nextScheduledShowTime();
        // Capture the ORIGINAL countdown interval. Example: at 11:00 with
        // show time 11:30, this is 30 minutes. Every completed show will
        // restart a fresh 30-minute countdown.
        scheduledRepeatIntervalMs = Math.max(0L,
                scheduledShowTargetMs - System.currentTimeMillis());
        // The Idle A-pose begins with the scheduled countdown and remains active
        // until the actual show starts. It is identified by Bottango name "idle".
        scheduledCountdownStartMs = System.currentTimeMillis();
        scheduledCountdownMidpointMs = scheduledCountdownStartMs + Math.max(0L, scheduledRepeatIntervalMs / 2L);
        countdownWavHalf = 0;
        loadCountdownWavs();
        scheduledIdleActivated = false;
        intermissionMusicStarted = false;
        screen = SCHEDULE;
        status = "SCHEDULED SHOW // COUNTDOWN";
        addLog("SCHEDULED SHOW // COUNTDOWN STARTED; SHOWTIME " + String.format(Locale.US, "%tT", scheduledShowTargetMs));
        activateBottangoIdlePose("COUNTDOWN");
        main.removeCallbacks(scheduledShowTick);
        main.post(scheduledShowTick);
        invalidate();
    }

    void stopScheduledShow(boolean returnToNormal) {
        // Stop scheduled callbacks first, so no scheduled phase can restart audio.
        main.removeCallbacks(scheduledShowTick);
        // Prevent Bottango polling/autoplay from advancing to another animation
        // and launching that animation's assigned WAV after the user exits.
        autoplay = false;
        lastPlaybackWasPlaying = false;
        playbackStateKnown = false;
        bottangoPlaying = false;
        lastBottangoReportedTimeMs = -1L;
        playbackPollGeneration++;
        lastAutoAdvanceIndex = -1;

        // Stop both foreground WAV players and any WAV started by the background
        // AlarmManager receiver. This includes players still preparing.
        stopLocalWav();
        ScheduledShowReceiver.stopPhoneAudio();

        // Exit can happen during intermission, countdown, or animation playback.
        // Stop every controller and Bottango in every phase, not just phase 2.
        scheduledShowActive = false;
        scheduledShowFinished = false;
        scheduledAdvanceLockUntilMs = 0L;
        scheduledShowPhase = 0;
        scheduledCountdownValue = 0;
        scheduledIdleActivated = false;
        intermissionMusicStarted = false;
        bottangoIdleAnimationAvailable = false;
        bottangoIdleAnimationIndex = -1;
        manualShowRunning = false;
        main.removeCallbacks(manualAdvanceRunnable);

        for (int i = 0; i < 4; i++) {
            send(i, "[STOP]");
        }
        // Stop Bottango in BOTH timing modes. Manual timing controls how the
        // app advances animations; it must not suppress the Bottango stop request.
        sendBottangoPlayback("{\"isPlaying\":false}", "SCHEDULED SHOW STOPPED");

        addLog("SCHEDULED SHOW // EXITED; PHONE WAV + CONTROLLERS STOPPED");
        if (returnToNormal) {
            screen = HOME;
            status = "SYSTEM READY";
            try { ((Activity) appContext).setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); } catch (Exception ignored) { }
        }
        invalidate();
    }

    void beginScheduledShowPlayback() {
        // Before leaving the countdown, find the first animation with an
        // actually detectable assigned WAV. Missing assignments are skipped.
        int playableSlot = findNextDetectableAssignedWav(0);
        if (playableSlot < 0) {
            finishScheduledShowBecauseNoWavs();
            return;
        }

        // Starting the first playable animation ends the countdown Idle A-pose.
        scheduledShowPhase = 2;
        scheduledShowFinished = false;
        scheduledIdleActivated = true;
        // Scheduled shows always auto-advance; this does not depend on the
        // normal manual autoplay setting.
        autoplay = true;
        loop = false;
        selectedAnimation = playableSlot + 1;
        currentTrackName = animNames[playableSlot];
        playbackTimeMs = 0;
        status = "SCHEDULED SHOW // SHOW RUNNING";
        addLog("SCHEDULED SHOW // STARTING ANIMATION " + (playableSlot + 1));

        // restartShow() respects the selected playable slot during a scheduled
        // show, so a missing Animation 1 does not accidentally start it.
        if (manualTimingMode) startManualShow();
        else restartShow();
        main.removeCallbacks(scheduledShowTick);
        main.postDelayed(scheduledShowTick, 1000L);
    }

    void applyIntermissionFade(long now) {
        MediaPlayer player = localWavPlayer;
        if (!intermissionMusicStarted || player == null || !localWavPlaying) return;

        // Keep the intermission WAV looping until showtime. During the final
        // 30 seconds, smoothly fade it from full volume to silence.
        long fadeStart = scheduledShowTargetMs - 30_000L;
        long fadeEnd = scheduledShowTargetMs - 10_000L;
        float volume;
        if (now <= fadeStart) {
            volume = 1.0f;
        } else if (now >= fadeEnd) {
            volume = 0.0f;
        } else {
            volume = Math.max(0f, Math.min(1f,
                    (fadeEnd - now) / 20_000f));
        }
        try { player.setVolume(volume, volume); } catch (Exception ignored) { }
    }

    void tickScheduledShow() {
        if (!scheduledShowActive) return;
        long now = System.currentTimeMillis();
        if (scheduledShowPhase == 0) {
            long remaining = Math.max(0L, scheduledShowTargetMs - now);

            // The two selected countdown WAVs are the only scheduled countdown
            // audio. WAV 1 covers the first half and WAV 2 covers the second half.
            if (countdownWavHalf == 0 && remaining > 0L) {
                playCountdownWavForCurrentHalf();
            }
            if (countdownWavHalf == 1 && now >= scheduledCountdownMidpointMs) {
                countdownWavHalf = 2;
                if (localWavPlayer != null) {
                    try { localWavPlayer.setVolume(0f, 0f); } catch (Exception ignored) { }
                }
                playCountdownWavForCurrentHalf();
                addLog("COUNTDOWN WAV // FIRST HALF FADED OUT // SECOND HALF STARTED");
            }
            applyCountdownWavFade(now);

            // The Idle A-pose is active for the entire beginning countdown.
            scheduledCountdownValue = (int)Math.min(Integer.MAX_VALUE,
                    (remaining + 999L) / 1000L);

            if (now >= scheduledShowTargetMs) {
                // Showtime: silence and release intermission audio, then start
                // the first real show animation. This ends the Idle A-pose.
                stopLocalWav();
                beginScheduledShowPlayback();
            }
        } else if (scheduledShowPhase == 1) {
            // Retained for compatibility with older persisted state.
            if (intermissionMusicStarted) applyIntermissionFade(now);
            scheduledCountdownValue = (int)Math.max(0L,
                    (scheduledShowTargetMs - now + 999L) / 1000L);
            if (now >= scheduledShowTargetMs) {
                stopLocalWav();
                beginScheduledShowPlayback();
            }
        } else if (scheduledShowPhase == 2) {
            boolean complete = manualTimingMode ? !manualShowRunning && status.startsWith("SHOW COMPLETE")
                    : status.startsWith("SHOW COMPLETE");
            if (complete) {
                // A scheduled show always returns to its original countdown state after
                // finishing. The next timer is calculated from the saved schedule time,
                // so a 12:30 show viewed at 12:00 starts at 30:00 again on every cycle.
                scheduledShowFinished = false;
                stopLocalWav();
                scheduledShowPhase = 0;
                selectedAnimation = 1;
                currentTrackName = animNames[0];
                // Repeat using the ORIGINAL interval captured when this scheduled
                // run started. Do not wait until the next calendar occurrence.
                // Example: 11:00 -> 11:30 = 30-minute interval; after the
                // show ends, the next countdown starts at 30:00 again.
                long repeatInterval = scheduledRepeatIntervalMs;
                if (repeatInterval <= 0L) {
                    repeatInterval = Math.max(0L, nextScheduledShowTime() - now);
                }
                scheduledShowTargetMs = now + repeatInterval;
                scheduledRepeatIntervalMs = repeatInterval;
                scheduledCountdownStartMs = now;
                scheduledCountdownValue = (int)Math.min(Integer.MAX_VALUE,
                        Math.max(0L, (scheduledShowTargetMs - now + 999L) / 1000L));
                intermissionMusicStarted = false;
                countdownWavHalf = 0;
                scheduledCountdownStartMs = now;
                scheduledCountdownMidpointMs = now + Math.max(0L, scheduledRepeatIntervalMs / 2L);
                loadCountdownWavs();
                activateBottangoIdlePose("NEXT SCHEDULED SHOW");
                status = "SCHEDULED SHOW // RESET FOR NEXT RUN";
                addLog("SCHEDULED SHOW // COMPLETE; TIMER RESET TO NEXT SCHEDULED RUN");
            }
        }
        invalidate();
        if (scheduledShowActive) main.postDelayed(scheduledShowTick, 250L);
    }

    void drawShowTimerBackground(Canvas c, float left, float top, float right, float bottom) {
        Bitmap b = showTimerBackground;
        if (b == null || b.isRecycled()) {
            c.drawColor(Color.BLACK);
            return;
        }
        float boxW = right - left, boxH = bottom - top;
        // Keep the source aspect ratio.  The small composition change gives the
        // characters a little more breathing room behind the HUD without stretching.
        float scale = Math.min(boxW / b.getWidth(), boxH / b.getHeight());
        float dw = b.getWidth() * scale, dh = b.getHeight() * scale;
        float dx = left + (boxW - dw) * 0.5f;
        float dy = top + (boxH - dh) * 0.5f - 4f;
        p.setAlpha(255);
        c.drawBitmap(b, null, new RectF(dx, dy, dx + dw, dy + dh), p);
    }

    void widePanel(Canvas c, float l, float t, float r, float b, int alpha) {
        p.setStyle(Paint.Style.FILL);
        p.setColor((alpha << 24) | 0x00070B12);
        c.drawRoundRect(l, t, r, b, 10, 10, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f);
        p.setColor(0xFF58616F);
        c.drawRoundRect(l + 1, t + 1, r - 1, b - 1, 10, 10, p);
        p.setStrokeWidth(1f);
        p.setColor(0xFF222C39);
        c.drawRoundRect(l + 5, t + 5, r - 5, b - 5, 7, 7, p);
        p.setStyle(Paint.Style.FILL);
    }

    void wideLabel(Canvas c, String label, String value, float x, float y, float w, int valueColor) {
        text(c, label, x, y, 14, Color.WHITE, Paint.Align.LEFT);
        text(c, value, x + w, y, 13, valueColor, Paint.Align.RIGHT);
    }

    void drawScheduledShowWide(Canvas real) {
        // Logical design matches the uploaded 1536x709 artwork's ~2.17:1 aspect.
        final float W = 1000f, H = 462f;
        float scale = Math.min(real.getWidth() / W, real.getHeight() / H);
        float ox = (real.getWidth() - W * scale) / 2f;
        float oy = (real.getHeight() - H * scale) / 2f;
        real.save();
        real.translate(ox, oy);
        real.scale(scale, scale);
        Canvas c = real;

        // The uploaded photo is the actual background. It is center-cropped only as
        // needed to fill the display, never stretched, and contains no UI controls.
        drawShowTimerBackground(c, 0, 0, W, H);

        // Slight readability veil, while keeping the characters and stage visible.
        p.setColor(0x18000000); c.drawRect(0, 0, W, H, p);

        // Bottom three-panel live HUD. No bitmap UI is used, so values stay live.
        final float top = 306f, bottom = 454f;
        widePanel(c, 12, top, 310, bottom, 150);
        widePanel(c, 318, top, 682, bottom, 155);
        widePanel(c, 690, top, 988, bottom, 150);

        // Left: schedule status.
        wideLabel(c, "SCHEDULE:", scheduleEnabled ? "● SHOW ACTIVE" : "● DISABLED", 28, 320, 270,
                scheduleEnabled ? 0xFF43E08A : 0xFFFF5A66);
        wideLabel(c, "NEXT RUN:", String.format(Locale.US, "%02d:%02d", scheduleHour, scheduleMinute), 28, 348, 270, Color.WHITE);
        String repeat = scheduleDays == 0 ? "EVERY DAY" : scheduleDays == 1 ? "WEEKDAYS" : "WEEKENDS";
        wideLabel(c, "REPEAT:", repeat, 28, 376, 270, Color.WHITE);
        wideLabel(c, "SHOW TO RUN:", String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation - 1]), 28, 404, 270, Color.WHITE);
        wideLabel(c, "INTERMISSION:", intermissionWavUris.isEmpty() ? "NO WAV" : intermissionWavUris.size() + " WAV FILES", 28, 432, 270,
                intermissionWavUris.isEmpty() ? 0xFF66D9FF : 0xFF2FE6FF);

        // Center: the actual live countdown, large and readable.
        text(c, "SHOW TIMER", 500, 318, 22, Color.WHITE, Paint.Align.CENTER);
        text(c, "TIME UNTIL SHOW", 500, 340, 14, Color.WHITE, Paint.Align.CENTER);
        long remaining = Math.max(0L, scheduledShowTargetMs - System.currentTimeMillis());
        if (scheduledShowPhase == 2 && !scheduledShowFinished) remaining = 0L;
        boolean countdownError = scheduledCountdownErrorUntilMs > System.currentTimeMillis();
        String timer = countdownError ? "WAV ERROR"
                : (scheduledShowPhase == 2 && !scheduledShowFinished ? "SHOW"
                : formatTime((int)Math.min(Integer.MAX_VALUE, remaining)));
        float timerSize = countdownError ? 34f : timerTextSize();
        int timerCol = countdownError ? 0xFFFF3344 : timerColor();
        long secondsLeft = remaining / 1000L;
        float timerX = 500f;
        float timerY = 402f;
        if (timerEffectMode == 1) {
            float pulse = 1f + 0.055f * (float)Math.sin(System.currentTimeMillis() / 180.0);
            timerSize *= pulse;
        } else if (timerEffectMode == 4 && secondsLeft <= 10) {
            timerX += (float)Math.sin(System.currentTimeMillis() / 55.0) * 2.5f;
        }
        int timerAlpha = 255;
        if (timerEffectMode == 2 && secondsLeft <= 10 && (System.currentTimeMillis() / 220L) % 2L == 0L) timerAlpha = 90;
        if (timerEffectMode == 3) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(7f);
            p.setColor((0x35 << 24) | (timerCol & 0x00FFFFFF));
            c.drawRoundRect(360, 353, 640, 420, 18, 18, p);
            p.setStyle(Paint.Style.FILL);
        }
        text(c, timer, timerX, timerY, timerSize, (timerAlpha << 24) | (timerCol & 0x00FFFFFF), Paint.Align.CENTER);
        if (countdownError) {
            text(c, "NO DETECTABLE WAV FILES", 500, 433, 11, 0xFFFF6677, Paint.Align.CENTER);
            text(c, "TIMER RESTARTED", 500, 449, 10, Color.WHITE, Paint.Align.CENTER);
        } else {
            text(c, "MINUTES", 430, 433, 12, Color.WHITE, Paint.Align.CENTER);
            text(c, "SECONDS", 570, 433, 12, Color.WHITE, Paint.Align.CENTER);
        }

        // Right: phase/audio and the live stop target.
        String phase = scheduledShowPhase == 0 ? "♪ INTERMISSION" : scheduledShowPhase == 1 ? "SHOW STARTING" : scheduledShowFinished ? "SHOW COMPLETE" : "SHOW IN PROGRESS";
        wideLabel(c, "CURRENT PHASE:", phase, 708, 320, 258, 0xFF31D9FF);
        String nowPlaying = intermissionMusicStarted ? (selectedWavName == null ? "MUSIC" : selectedWavName) : "MUSIC WAITING";
        wideLabel(c, "NOW PLAYING:", nowPlaying, 708, 350, 258, Color.WHITE);

        // Red STOP SHOW button.  The visible button remains compact, while the
        // touch handler below uses the entire right-side button row so it is easy
        // to hit on phones with different aspect ratios.
        p.setStyle(Paint.Style.FILL); p.setColor(0xDD08080B); c.drawRoundRect(708, 366, 838, 447, 8, 8, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.2f); p.setColor(0xFFFF2038); c.drawRoundRect(708, 366, 838, 447, 8, 8, p); p.setStyle(Paint.Style.FILL);
        text(c, "✕", 773, 403, 31, 0xFFFF3045, Paint.Align.CENTER);
        text(c, "STOP SHOW", 773, 435, 12, Color.WHITE, Paint.Align.CENTER);

        // Character photo card: use the actual selectable Freddy artwork rather
        // than baking a second copy into the timer background.
        Bitmap timerCharacter = themeCharacter(0);
        if (timerCharacter != null) {
            p.setColor(0xCC08080B);
            c.drawRoundRect(850, 300, 982, 358, 8, 8, p);
            image(c, timerCharacter, new RectF(854, 304, 978, 354));
            text(c, "FREDDY", 916, 365, 8, Color.WHITE, Paint.Align.CENTER);
        }

        widePanel(c, 846, 366, 988, 447, 150);
        text(c, "CONTROLS:", 917, 397, 11, Color.WHITE, Paint.Align.CENTER);
        text(c, "🔒 LOCKED", 917, 428, 15, 0xFFFFD31A, Paint.Align.CENTER);

        // Small live phase line; deliberately not baked into the image.
        text(c, scheduledShowFinished ? "NEXT SCHEDULED RUN LOADED" : "LIVE SCHEDULED SHOW", 500, 451, 8, 0xFFB8C0CA, Paint.Align.CENTER);
        real.restore();
    }

    void drawScheduledShow(Canvas c) {
        portraitBackground(c);
        rect(c, 18, 18, 342, 782, 0xFF0D111C, false);
        text(c, "FAZBEAR CONTROL", 180, 55, 13, Color.LTGRAY, Paint.Align.CENTER);
        pButton(c, 24, 72, 312, 48, "✕  EXIT SHOW", 0xFF9B2635);
        text(c, scheduledShowPhase == 0 ? "INTERMISSION" : scheduledShowPhase == 1 ? "SHOW STARTING IN" : scheduledShowFinished ? "SHOW COMPLETE" : "SHOW IN PROGRESS", 180, 190, 20, Color.WHITE, Paint.Align.CENTER);
        if (scheduledShowPhase == 0) {
            long remaining = Math.max(0L, scheduledShowTargetMs - System.currentTimeMillis());
            text(c, intermissionMusicStarted ? "INTERMISSION MUSIC" : "IDLE A-POSE  •  MUSIC WAITING",
                    180, 250, 12, intermissionMusicStarted ? 0xFF43D17D : 0xFFFFC857, Paint.Align.CENTER);
            text(c, intermissionMusicStarted
                    ? (selectedWavName == null ? "NO MUSIC SELECTED" : selectedWavName)
                    : "INTERMISSION STARTS AT 45:00",
                    180, 282, 9, Color.LTGRAY, Paint.Align.CENTER);
            text(c, "SHOWTIME IN", 180, 350, 10, Color.LTGRAY, Paint.Align.CENTER);
            text(c, formatTime((int)Math.min(Integer.MAX_VALUE, remaining)), 180, 405, 36, Color.WHITE, Paint.Align.CENTER);
            text(c, "IDLE A-POSE ACTIVE • MUSIC FADES DURING FINAL 30 SECONDS", 180, 470, 7.2f, 0xFFFFC857, Paint.Align.CENTER);
        } else if (scheduledShowPhase == 1) {
            float countdownSize = scheduledCountdownValue <= 10 ? 170f : 112f;
            text(c, String.valueOf(scheduledCountdownValue), 180, 420, countdownSize, 0xFFFFC857, Paint.Align.CENTER);
            text(c, "PLEASE STAND BY", 180, 485, 12, Color.LTGRAY, Paint.Align.CENTER);
        } else {
            text(c, scheduledShowFinished ? "ALL 8 ANIMATIONS FINISHED" : "ANIMATION " + selectedAnimation + " / 8", 180, 320, 17, Color.WHITE, Paint.Align.CENTER);
            text(c, currentTrackName, 180, 365, 11, Color.LTGRAY, Paint.Align.CENTER);
            if (scheduledShowFinished) text(c, "EXIT SHOW TO RETURN TO THE APP", 180, 440, 9, 0xFFFFC857, Paint.Align.CENTER);
        }
        text(c, "OTHER CONTROLS ARE LOCKED", 180, 740, 9, 0xFF85899A, Paint.Align.CENTER);
    }

    void portraitSchedule(Canvas c) {
        portraitHeader(c, "SHOW SCHEDULE", "AUTOMATIC SHOW LAUNCH • PHONE ALARM");
        pButton(c, 22, 112, 316, 62, scheduleEnabled ? "SCHEDULE ENABLED  •  TAP TO PAUSE" : "SCHEDULE DISABLED  •  TAP TO ENABLE", scheduleEnabled ? 0xFF43D17D : 0xFF55596A);
        rect(c, 22, 190, 338, 340, panel2(), false);
        text(c, "NEXT RUN TIME", 38, 216, 8, 0xFFB8B6C7, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d:%02d", scheduleHour, scheduleMinute), 180, 263, 35, Color.WHITE, Paint.Align.CENTER);
        pButton(c, 38, 285, 284, 38, "CHANGE TIME", accent());
        rect(c, 22, 356, 338, 475, panel2(), false);
        text(c, "REPEAT", 38, 382, 8, 0xFFB8B6C7, Paint.Align.LEFT);
        String repeat = scheduleDays == 0 ? "EVERY DAY" : scheduleDays == 1 ? "WEEKDAYS" : "WEEKENDS";
        pButton(c, 38, 397, 284, 42, repeat + "  •  CHANGE", 0xFF303444);
        text(c, "SHOW TO RUN", 38, 506, 8, 0xFFB8B6C7, Paint.Align.LEFT);
        pButton(c, 22, 520, 316, 48, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation-1]), accent());
        loadCountdownWavs();
        String wav1Label = (countdownWav1Uri == null || countdownWav1Uri.isEmpty())
                ? "WAV 1 • SELECT"
                : "WAV 1 • " + countdownWav1Name;
        String wav2Label = (countdownWav2Uri == null || countdownWav2Uri.isEmpty())
                ? "WAV 2 • SELECT"
                : "WAV 2 • " + countdownWav2Name;
        pButton(c, 22, 578, 154, 42, wav1Label, 0xFF246B48);
        pButton(c, 184, 578, 154, 42, wav2Label, 0xFF246B48);
        text(c, "WAV 1 + WAV 2 AUTO-LOOP • WAV ONLY", 180, 631, 7, 0xFFB8B6C7, Paint.Align.CENTER);
        pButton(c, 22, 635, 152, 42, "SAVE SCHEDULE", 0xFF246B48);
        pButton(c, 186, 635, 152, 42, "▶ PLAY SCHEDULED SHOW", accent());
    }

    void persistSchedule() {
        prefs.edit().putBoolean("schedule_enabled", scheduleEnabled).putInt("schedule_hour", scheduleHour)
                .putInt("schedule_minute", scheduleMinute).putInt("schedule_days", scheduleDays)
                .putInt("schedule_animation", selectedAnimation).apply();
        if (scheduleEnabled && Build.VERSION.SDK_INT >= 31) {
            AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
            if (!alarmManager.canScheduleExactAlarms()) {
                new AlertDialog.Builder(appContext).setTitle("Allow exact show alarms?")
                        .setMessage("Allow Fazbear Control to schedule shows at the selected time. If you skip this, Android may deliver the show late.")
                        .setPositiveButton("OPEN SETTINGS", (d, w) -> {
                            try { appContext.startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                    android.net.Uri.parse("package:" + appContext.getPackageName()))); }
                            catch (Exception ignored) { }
                        }).setNegativeButton("NOT NOW", null).show();
            }
        }
        ScheduleAlarm.schedule(appContext, scheduleEnabled, scheduleHour, scheduleMinute, scheduleDays, selectedAnimation);
        status = scheduleEnabled ? "SHOW SCHEDULE SAVED" : "SHOW SCHEDULE DISABLED";
        addLog("SCHEDULE // " + status);
    }

    void portraitDevices(Canvas c) {
        portraitHeader(c, "DEVICES", "SELECT A CONTROLLER");
        for (int i = 0; i < 4; i++) {
            int y = 112 + i * 142;
            rect(c, 22, y, 338, y + 128, panel2(), false);
            rect(c, 22, y, 338, y + 128, i == page ? accent() : 0xFF354056, true);
            image(c, themeCharacter(i), new RectF(32, y + 12, 130, y + 94));
            text(c, "ESP32 — " + names[i], 143, y + 28, 12, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "● ONLINE" : "● OFFLINE", 143, y + 48, 9, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, ips[i], 143, y + 66, 8, Color.LTGRAY, Paint.Align.LEFT);
            text(c, "Playing: " + playing[i], 143, y + 84, 8, accent(), Paint.Align.LEFT);
            pButton(c, 34, y + 98, 292, 24, "OPEN CONTROLLER  ›", accent());
        }
    }

    void portraitDeviceDetail(Canvas c) {
        portraitHeader(c, "ESP32 — " + names[page], ips[page]);
        pButton(c, 22, 105, 82, 34, "‹ BACK", accent());
        image(c, themeCharacter(page), new RectF(22, 153, 150, 253));
        text(c, online[page] ? "● ONLINE" : "● OFFLINE", 170, 178, 10, online[page] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "NOW PLAYING", 170, 201, 8, Color.LTGRAY, Paint.Align.LEFT);
        text(c, playing[page], 170, 222, 12, Color.WHITE, Paint.Align.LEFT);
        text(c, "VOLUME LEVEL  •  ESP32 POT", 170, 244, 7, accent(), Paint.Align.LEFT);
        volumeIndicator(c, 170, 251, 105, 9);
        text(c, "CHOOSE ANIMATION", 24, 286, 11, Color.WHITE, Paint.Align.LEFT);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 2, row = (i - 1) / 2;
            int x = 24 + col * 160, y = 304 + row * 48;
            pButton(c, x, y, 152, 39, String.format(Locale.US, "%02d  %s", i, animNames[i-1]), i == selectedAnimation ? accent() : 0xFF303444);
        }
        pButton(c, 24, 510, 150, 44, "▶ PLAY", Color.GREEN);
        pButton(c, 186, 510, 150, 44, "PAUSE N/A", 0xFF8A6B00);
        pButton(c, 24, 566, 312, 44, "↻ RESTART", accent());
        pButton(c, 24, 626, 312, 42, autoplay ? "AUTO NEXT: ON" : "AUTO NEXT: OFF", autoplay ? Color.GREEN : 0xFF303444);
    }

    void portraitTimeline(Canvas c) {
        portraitHeader(c, "TIMELINE", "BOTTANGO PLAYBACK");
        text(c, "NOW PLAYING", 26, 126, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, currentTrackName, 26, 153, 14, Color.WHITE, Paint.Align.LEFT);
        rect(c, 24, 180, 336, 330, panel2(), false);
        rect(c, 24, 180, 336, 330, accent(), true);
        for (int x = 32; x < 328; x += 4) {
            double wave = Math.sin(x * 0.12) * 35 + Math.sin(x * 0.31) * 15 + Math.sin(x * 0.61) * 7;
            p.setColor(x % 24 < 8 ? 0xFFFF1744 : accent());
            c.drawLine(x, 255, x, (float)(255 + wave), p);
        }
        if (durationMs > 0) {
            float ratio = Math.max(0f, Math.min(1f, playbackTimeMs / (float) durationMs));
            rect(c, 24, 326, 24 + 312 * ratio, 330, Color.GREEN, false);
            float markerX = 24 + 312 * ratio;
            rect(c, markerX - 1, 188, markerX + 1, 326, Color.WHITE, false);
        } else {
            rect(c, 174, 188, 176, 322, Color.WHITE, false);
        }
        String durationText = durationMs > 0 ? formatTime(durationMs) : "--:--";
        text(c, formatTime(playbackTimeMs) + "  /  " + durationText, 180, 356, 12, Color.WHITE, Paint.Align.CENTER);
        text(c, playbackStateKnown ? (bottangoPlaying ? "● PLAYING" : "● STOPPED / IDLE") : "● CONNECTING TO BOTTANGO…", 180, 376, 8,
                playbackStateKnown && bottangoPlaying ? Color.GREEN : Color.LTGRAY, Paint.Align.CENTER);

        text(c, "ADVANCED LIVE MIC METER", 24, 402, 10, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "RMS %5.1f dBFS", vuDbfs), 24, 425, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "PEAK %5.1f dBFS", vuPeakDbfs), 336, 425, 8, Color.WHITE, Paint.Align.RIGHT);
        drawAdvancedVu(c, 24, 437, vuLevel, vuPeak);
        text(c, "-60", 24, 463, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "-30", 180, 463, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "0 dBFS", 336, 463, 6, Color.LTGRAY, Paint.Align.RIGHT);
        if (vuClip) {
            rect(c, 253, 474, 336, 497, red(), false);
            text(c, "CLIP DETECTED", 294, 488, 7, Color.WHITE, Paint.Align.CENTER);
        } else {
            text(c, "PEAK HOLD  •  MIC INPUT", 180, 488, 7, Color.LTGRAY, Paint.Align.CENTER);
        }
        if (vuPermissionDenied) text(c, "MIC PERMISSION DENIED", 180, 518, 7, red(), Paint.Align.CENTER);

        // Local phone WAV controls must be on the portrait screen actually used by the app.
        pButton(c, 24, 528, 190, 44, "PICK WAV FILE", accent());
        pButton(c, 224, 528, 112, 44, localWavPlaying ? "STOP WAV" : "PLAY WAV", localWavPlaying ? red() : Color.GREEN);
        String wavLabel = selectedWavName.length() > 42 ? selectedWavName.substring(0, 41) + "…" : selectedWavName;
        text(c, wavLabel, 24, 592, 8, Color.WHITE, Paint.Align.LEFT);
        pButton(c, 24, 608, 94, 40, "−5 SEC", accent());
        pButton(c, 132, 608, 96, 40, "PAUSE N/A", 0xFF5A4B30);
        pButton(c, 242, 608, 94, 40, "+5 SEC", accent());
        text(c, "PHONE WAV PLAYBACK  •  VOLUME VIA PHONE", 24, 668, 7, Color.LTGRAY, Paint.Align.LEFT);
    }

    void drawAdvancedVu(Canvas c, int x, int y, float level, float peak) {
        int segments = 32;
        float safeLevel = Math.max(0f, Math.min(1f, level));
        float safePeak = Math.max(0f, Math.min(1f, peak));
        int active = Math.round(safeLevel * segments);
        for (int i = 0; i < segments; i++) {
            int sx = x + i * 9;
            int color = i >= 28 ? red() : i >= 23 ? 0xFFFFB52E : 0xFF45E08A;
            rect(c, sx, y, sx + 6, y + 15, i < active ? color : 0xFF252A34, false);
        }
        int peakX = x + Math.round(safePeak * (segments - 1)) * 9;
        rect(c, peakX, y - 3, peakX + 2, y + 18, Color.WHITE, false);
        // The hold marker is bright white; the bar itself shows smoothed RMS energy.
    }

    void portraitControl(Canvas c) {
        portraitHeader(c, "SHOW CONTROL", "MULTI-CONTROLLER");
        text(c, "SELECTED ANIMATION", 26, 126, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation-1]), 26, 154, 15, Color.WHITE, Paint.Align.LEFT);
        pButton(c, 24, 184, 150, 56, "▶ PLAY ALL", Color.GREEN);
        pButton(c, 186, 184, 150, 56, "PAUSE N/A", 0xFF8A6B00);
        pButton(c, 24, 254, 150, 56, "↻ RESTART", accent());
        pButton(c, 186, 254, 150, 56, "⏭ SKIP ANIM", 0xFFB02CFF);
        for (int i = 0; i < 4; i++) {
            int y = 334 + i * 76;
            rect(c, 24, y, 336, y + 62, panel2(), false);
            image(c, themeCharacter(i), new RectF(32, y + 6, 90, y + 56));
            text(c, names[i], 104, y + 24, 11, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "ONLINE" : "OFFLINE", 104, y + 44, 8, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, playing[i], 220, y + 34, 8, accent(), Paint.Align.LEFT);
        }
        pButton(c, 24, 650, 150, 42, loop ? "LOOP: ON" : "LOOP: OFF", loop ? Color.GREEN : 0xFF303444);
        pButton(c, 186, 650, 150, 42, autoplay ? "AUTO NEXT: ON" : "AUTO NEXT: OFF", autoplay ? Color.GREEN : 0xFF303444);
    }

    void editControllerAddress(int which) {
        if (which < 0 || which >= 4) return;
        EditText input = new EditText(appContext);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("e.g. 192.168.1.101");
        input.setText(ips[which]);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(appContext)
                .setTitle("ESP32 — " + names[which] + " IP Address")
                .setMessage("Enter the controller's IPv4 address.")
                .setView(input)
                .setNegativeButton("CANCEL", (dialog, id) -> dialog.dismiss())
                .setNeutralButton("DEFAULT", (dialog, id) -> {
                    ips[which] = defaultIPs[which];
                    prefs.edit().putString("ip" + which, ips[which]).apply();
                    addLog("IP UPDATED: " + names[which] + " = " + ips[which]);
                    invalidate();
                })
                .setPositiveButton("SAVE", (dialog, id) -> {
                    String candidate = input.getText().toString().trim();
                    if (isValidIPv4(candidate)) {
                        ips[which] = candidate;
                        prefs.edit().putString("ip" + which, candidate).apply();
                        addLog("IP UPDATED: " + names[which] + " = " + candidate);
                        invalidate();
                    } else {
                        new AlertDialog.Builder(appContext)
                                .setTitle("Invalid IP address")
                                .setMessage("Enter an IPv4 address such as 192.168.1.101.")
                                .setPositiveButton("OK", null)
                                .show();
                    }
                })
                .show();
    }

    boolean isValidIPv4(String value) {
        String[] parts = value.split("\\\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) return false;
            for (int i = 0; i < part.length(); i++) {
                if (!Character.isDigit(part.charAt(i))) return false;
            }
            try {
                int n = Integer.parseInt(part);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    void showThemeCustomization() {
        final String[] themes = {
                "Classic", "Night Shift", "Security", "Retro (8-Bit)",
                "Worn & Withered", "Party", "Halloween", "Arcade",
                "Abandoned", "Pirate Cove", "Legacy Halloween"
        };
        final int[] themeIds = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int selected = 0;
        for (int i = 0; i < themeIds.length; i++) {
            if (theme == themeIds[i]) { selected = i; break; }
        }
        new AlertDialog.Builder(appContext)
                .setTitle("THEME CUSTOMIZATION")
                .setSingleChoiceItems(themes, selected, (dialog, which) -> {
                    theme = themeIds[which];
                    prefs.edit().putInt("theme", theme).apply();
                    addLog("THEME CHANGED: " + themes[which]);
                    invalidate();
                })
                .setNeutralButton("MORE OPTIONS", (d, w) -> showThemeMoreOptions())
                .setPositiveButton("DONE", (d, w) -> invalidate())
                .show();
    }

    void showThemeMoreOptions() {
        final String[] options = {"CUSTOMIZE CURRENT THEME", "BACKGROUND FOR THIS THEME",
                "HOME SCREEN PHOTO / GIF", "CHARACTER IMAGES", "PHOTOS FOR THIS THEME",
                "SHOW TIMER CUSTOMIZATION", "RESET PHOTOS TO THEME DEFAULTS"};
        new AlertDialog.Builder(appContext).setTitle("THEME CUSTOMIZATION")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) showThemeEffectsDialog();
                    else if (which == 1) chooseThemeBackground();
                    else if (which == 2) chooseHomeMedia();
                    else if (which == 3) showCharacterImagePicker();
                    else if (which == 4) showThemeCharacterImagePicker();
                    else if (which == 5) showTimerCustomization();
                    else resetCurrentThemePhotosToDefaults();
                }).setNegativeButton("CANCEL", null).show();
    }

    void showCharacterImagePicker() {
        final String[] choices = {"Freddy image", "Bonnie image", "Chica image", "Stage image"};
        new AlertDialog.Builder(appContext)
                .setTitle("CHANGE CHARACTER / STAGE IMAGE")
                .setItems(choices, (dialog, which) -> chooseCharacterImage(which))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    void chooseCharacterImage(int slot) {
        if (slot < 0 || slot >= 4) return;
        pendingCharacterSlot = slot;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_CHARACTER_IMAGE); }
        catch (Exception ex) { addLog("CHARACTER IMAGE PICKER ERROR: " + ex.getMessage()); }
    }

    void loadCustomCharacterImage(int slot, android.net.Uri uri) {
        if (slot < 0 || slot >= chars.length) return;
        try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) {
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                if (bitmap != null) chars[slot] = bitmap;
            }
        } catch (Exception ex) {
            addLog("CHARACTER IMAGE LOAD FAILED: " + (slot + 1));
        }
    }

    void showThemeCharacterImagePicker() {
        final int currentTheme = theme;
        final String[] choices = {"Freddy photo", "Bonnie photo", "Chica photo", "Stage photo"};
        new AlertDialog.Builder(appContext)
                .setTitle("PHOTOS FOR " + themeName(currentTheme))
                .setItems(choices, (dialog, which) -> chooseThemeCharacterImage(currentTheme, which))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    void chooseThemeCharacterImage(int themeId, int slot) {
        if (themeId < 0 || themeId >= 11 || slot < 0 || slot >= 4) return;
        pendingThemeCharacterTheme = themeId;
        pendingThemeCharacterSlot = slot;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_CHARACTER_IMAGE); }
        catch (Exception ex) { addLog("THEME PHOTO PICKER ERROR: " + ex.getMessage()); }
    }

    void loadDefaultThemeArtwork() {
        String[] slots = {"freddy", "bonnie", "chica", "stage"};
        for (int themeId = 0; themeId < 11; themeId++) {
            for (int slot = 0; slot < slots.length; slot++) {
                themeCharImages[themeId][slot] = load(appContext, "theme" + themeId + "_" + slots[slot]);
            }
        }
    }

    void resetCurrentThemePhotosToDefaults() {
        int id = Math.max(0, Math.min(10, theme));
        android.content.SharedPreferences.Editor editor = prefs.edit();
        themeBackgroundUris[id] = null;
        editor.remove("theme_bg_" + id);
        for (int slot = 0; slot < 4; slot++) {
            themeCharUris[id][slot] = null;
            editor.remove("theme_char_" + id + "_" + slot);
        }
        editor.apply();
        loadDefaultThemeArtwork();
        addLog("THEME PHOTOS RESET TO DEFAULTS: " + themeName(id));
        invalidate();
    }

    void loadThemeCharacterImage(int themeId, int slot, android.net.Uri uri) {
        if (themeId < 0 || themeId >= 11 || slot < 0 || slot >= 4) return;
        try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) {
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                if (bitmap != null) themeCharImages[themeId][slot] = bitmap;
            }
        } catch (Exception ex) {
            addLog("THEME PHOTO LOAD FAILED: " + themeName(themeId) + " / " + (slot + 1));
        }
    }

    Bitmap themeCharacter(int slot) {
        if (theme >= 0 && theme < 11 && slot >= 0 && slot < 4 && themeCharImages[theme][slot] != null) {
            return themeCharImages[theme][slot];
        }
        return chars[slot];
    }

    void showTimerCustomization() {
        final String[] sizes = {"Small", "Medium", "Large"};
        final String[] colors = {"Theme color", "Gold", "Cyan", "Red", "White"};
        final String[] effects = {"None", "Pulse", "Flash at 10 seconds", "Neon glow", "Shake"};

        new AlertDialog.Builder(appContext)
                .setTitle("SHOW TIMER CUSTOMIZATION")
                .setItems(new String[]{
                        "SIZE  •  " + sizes[Math.max(0, Math.min(2, timerSizeMode))],
                        "COLOR  •  " + colors[Math.max(0, Math.min(4, timerColorMode))],
                        "COUNTDOWN EFFECT  •  " + effects[Math.max(0, Math.min(4, timerEffectMode))]
                }, (dialog, which) -> {
                    if (which == 0) {
                        new AlertDialog.Builder(appContext).setTitle("TIMER SIZE")
                                .setSingleChoiceItems(sizes, timerSizeMode, (d, w) -> {
                                    timerSizeMode = w;
                                    prefs.edit().putInt("timer_size_mode", w).apply();
                                    d.dismiss();
                                    invalidate();
                                }).show();
                    } else if (which == 1) {
                        new AlertDialog.Builder(appContext).setTitle("TIMER COLOR")
                                .setSingleChoiceItems(colors, timerColorMode, (d, w) -> {
                                    timerColorMode = w;
                                    prefs.edit().putInt("timer_color_mode", w).apply();
                                    d.dismiss();
                                    invalidate();
                                }).show();
                    } else {
                        new AlertDialog.Builder(appContext).setTitle("COUNTDOWN EFFECT")
                                .setSingleChoiceItems(effects, timerEffectMode, (d, w) -> {
                                    timerEffectMode = w;
                                    prefs.edit().putInt("timer_effect_mode", w).apply();
                                    d.dismiss();
                                    invalidate();
                                }).show();
                    }
                })
                .setPositiveButton("DONE", null)
                .show();
    }

    int timerColor() {
        switch (timerColorMode) {
            case 1: return 0xFFFFC52B;
            case 2: return 0xFF36E7FF;
            case 3: return 0xFFFF3045;
            case 4: return Color.WHITE;
            default: return accent();
        }
    }

    float timerTextSize() {
        switch (timerSizeMode) {
            case 0: return 44f;
            case 2: return 68f;
            default: return 56f;
        }
    }

    void showThemeEffectsDialog() {
        final String[] effects = {"Theme default (unique look)", "CRT scanlines",
                "Glitch / signal tearing", "Security camera static", "Neon glow pulse", "No extra effects"};
        final int[] selected = {themeEffects[Math.max(0, Math.min(10, theme))]};
        new AlertDialog.Builder(appContext).setTitle("CUSTOMIZE " + themeName(theme))
                .setSingleChoiceItems(effects, selected[0], (dialog, which) -> {
                    selected[0] = which;
                    themeEffects[theme] = which;
                    prefs.edit().putInt("theme_effect_" + theme, which).apply();
                    invalidate();
                })
                .setPositiveButton("DONE", (d, w) -> {
                    themeEffects[theme] = selected[0];
                    prefs.edit().putInt("theme_effect_" + theme, selected[0]).apply();
                    invalidate();
                }).show();
    }

    String themeName(int id) {
        String[] names = {"Classic", "Night Shift", "Security", "Retro (8-Bit)",
                "Worn & Withered", "Party", "Halloween", "Arcade", "Abandoned", "Pirate Cove", "Legacy Halloween"};
        return names[Math.max(0, Math.min(names.length - 1, id))];
    }

    // Theme background photos were removed. This method is retained only for
    // compatibility with older saved preferences and intentionally does nothing.
    void chooseThemeBackground() { addLog("THEME BACKGROUNDS DISABLED"); }
    void loadThemeBackground(int themeId, android.net.Uri uri) { /* disabled */ }

    void chooseHomeMedia() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { ((Activity) appContext).startActivityForResult(intent, PICK_HOME_MEDIA); }
        catch (Exception ex) { addLog("HOME MEDIA PICKER ERROR: " + ex.getMessage()); }
    }

    void loadHomeMedia(android.net.Uri uri) {
        homeCustomBitmap = null;
        homeCustomMovie = null;
        try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
            if (in != null) homeCustomMovie = Movie.decodeStream(in);
        } catch (Exception ignored) { }
        if (homeCustomMovie == null) {
            try (InputStream in = appContext.getContentResolver().openInputStream(uri)) {
                if (in != null) homeCustomBitmap = BitmapFactory.decodeStream(in);
            } catch (Exception ex) { addLog("HOME MEDIA LOAD FAILED"); }
        }
        homeCustomMovieStartedAt = android.os.SystemClock.uptimeMillis();
    }

    void drawHomeCustomMedia(Canvas c, RectF box) {
        if (homeCustomMovie != null && homeCustomMovie.width() > 0 && homeCustomMovie.height() > 0) {
            int duration = Math.max(1, homeCustomMovie.duration());
            homeCustomMovie.setTime((int)((android.os.SystemClock.uptimeMillis() - homeCustomMovieStartedAt) % duration));
            float fit = Math.min(box.width() / homeCustomMovie.width(), box.height() / homeCustomMovie.height());
            float dw = homeCustomMovie.width() * fit, dh = homeCustomMovie.height() * fit;
            c.save(); c.clipRect(box);
            c.translate(box.centerX() - dw / 2f, box.centerY() - dh / 2f);
            c.scale(fit, fit); homeCustomMovie.draw(c, 0, 0); c.restore();
            if (screen == HOME) postInvalidateDelayed(40);
        } else if (homeCustomBitmap != null && !homeCustomBitmap.isRecycled()) {
            image(c, homeCustomBitmap, box);
        } else if (menuGif != null) {
            int duration = Math.max(1, menuGif.duration());
            if (menuGifStartedAt < 0) menuGifStartedAt = android.os.SystemClock.uptimeMillis();
            menuGif.setTime((int)((android.os.SystemClock.uptimeMillis() - menuGifStartedAt) % duration));
            float fit = Math.min(box.width() / menuGif.width(), box.height() / menuGif.height());
            float dw = menuGif.width() * fit, dh = menuGif.height() * fit;
            c.save(); c.clipRect(box);
            c.translate(box.centerX() - dw / 2f, box.centerY() - dh / 2f);
            c.scale(fit, fit); menuGif.draw(c, 0, 0); c.restore();
            if (screen == HOME) postInvalidateDelayed(40);
        } else image(c, themeCharacter(0), box);
    }

    void drawThemeEffects(Canvas c) {
        int effect = (theme >= 0 && theme < themeEffects.length) ? themeEffects[theme] : 0;
        if (effect == 5) return;
        boolean crt = effect == 1 || (effect == 0 && (theme == 3 || theme == 8));
        boolean glitch = effect == 2 || (effect == 0 && (theme == 0 || theme == 4));
        boolean staticNoise = effect == 3 || (effect == 0 && theme == 9);
        boolean neon = effect == 4 || (effect == 0 && (theme == 1 || theme == 5 || theme == 7 || theme == 10));
        if (crt || (effect == 0 && scanlinesEnabled)) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(0x183CFF82);
            for (int y = 2; y < 800; y += 5) c.drawLine(0, y, 360, y, p);
            p.setStyle(Paint.Style.FILL);
        }
        if (glitch && (System.currentTimeMillis() / 700L) % 11L == 0L) {
            p.setColor(0x24FFFFFF); c.drawRect(0, 245, 360, 251, p);
            p.setColor((accent() & 0x00FFFFFF) | 0x33000000); c.drawRect(8, 498, 352, 503, p);
        }
        if (staticNoise && (System.currentTimeMillis() / 350L) % 3L == 0L) {
            p.setColor(0x18FFFFFF);
            for (int i = 0; i < 28; i++) {
                float y = (i * 29 + (System.currentTimeMillis() / 40L) % 29) % 800;
                int x = (i * 47) % 340; c.drawRect(x, y, x + 18, y + 1, p);
            }
        }
        if (neon) {
            int alpha = 0x18 + (int)(Math.abs(Math.sin(System.currentTimeMillis() / 500.0)) * 0x20);
            p.setColor((alpha << 24) | (accent() & 0x00FFFFFF));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f);
            c.drawRoundRect(15, 100, 345, 720, 18, 18, p); p.setStyle(Paint.Style.FILL);
        }
    }

    void portraitSettings(Canvas c) {
        portraitHeader(c, "SETTINGS", "NETWORK + STATUS");
        text(c, "TAP ADDRESS TO EDIT  •  TEST TO PING", 24, 124, 9, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            int y = 140 + i * 82;
            rect(c, 24, y, 336, y + 68, panel2(), false);
            text(c, names[i], 36, y + 24, 11, Color.WHITE, Paint.Align.LEFT);
            text(c, ips[i], 36, y + 45, 9, Color.LTGRAY, Paint.Align.LEFT);
            pButton(c, 242, y + 16, 80, 36, "TEST", accent());
        }
        rect(c, 24, 475, 336, 531, panel2(), false);
        text(c, "AUDIO OUTPUT  •  SELECT ONE MODE", 32, 490, 7.2f, Color.LTGRAY, Paint.Align.LEFT);
        pButton(c, 28, 497, 96, 28, audioOutputMode == 0 ? "MAX ONLY ✓" : "MAX ONLY", audioOutputMode == 0 ? accent() : 0xFF303444);
        pButton(c, 132, 497, 96, 28, audioOutputMode == 1 ? "BOTH ✓" : "BOTH", audioOutputMode == 1 ? accent() : 0xFF303444);
        pButton(c, 236, 497, 96, 28, audioOutputMode == 2 ? "PHONE ✓" : "PHONE", audioOutputMode == 2 ? accent() : 0xFF303444);
        text(c, phoneAudioStatus, 32, 542, 8, audioOutputMode == 0 ? Color.LTGRAY : 0xFFFFC857, Paint.Align.LEFT);
        text(c, "VOLUME IS READ-ONLY", 24, 558, 9, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "% — SYNCED FROM ESP32" : "WAITING FOR ESP32", 24, 576, 8, Color.WHITE, Paint.Align.LEFT);
        volumeIndicator(c, 24, 581, 245, 7);
        pButton(c, 24, 590, 312, 38, "THEMES  •  IMAGES  •  EFFECTS", accent());
        pButton(c, 24, 638, 100, 42, "DIAGNOSTICS", accent());
        pButton(c, 130, 638, 100, 42, "DEBUG LOG", 0xFF303444);
        pButton(c, 236, 638, 100, 42, "CLEAR LOG", red());
        pButton(c, 24, 684, 312, 32, "SHOW TIMING  •  " + (manualTimingMode ? "MANUAL MODE" : "BOTTANGO MODE"), manualTimingMode ? 0xFF246B48 : 0xFF303444);
    }

    String ageLabel(long timestamp) {
        if (timestamp <= 0L) return "NEVER";
        long seconds = Math.max(0L, (System.currentTimeMillis() - timestamp) / 1000L);
        return seconds < 2 ? "JUST NOW" : seconds + "s AGO";
    }

    void portraitDiagnostics(Canvas c) {
        portraitHeader(c, "SECURITY DIAGNOSTICS", "LIVE SYSTEM HEALTH");
        int onlineCount = 0;
        for (boolean connected : online) if (connected) onlineCount++;
        rect(c, 22, 110, 338, 210, panel2(), false);
        text(c, "SYSTEM STATUS", 32, 130, 8, accent(), Paint.Align.LEFT);
        text(c, "ESP32 NETWORK: " + onlineCount + " / 4 ONLINE", 32, 151, 9,
                onlineCount == 4 ? Color.GREEN : onlineCount > 0 ? 0xFFFFC857 : red(), Paint.Align.LEFT);
        String phoneWifi = phoneWifiRssi > -127 ? phoneWifiRssi + " dBm" : "UNAVAILABLE";
        text(c, "PHONE WI-FI: " + phoneWifi, 32, 171, 8, Color.WHITE, Paint.Align.LEFT);
        String botStatus = !lastPlaybackError.isEmpty() ? "ERROR" : playbackStateKnown ? "RESPONDING" : "WAITING";
        int botColor = !lastPlaybackError.isEmpty() ? red() : playbackStateKnown ? Color.GREEN : 0xFFFFC857;
        text(c, "BOTTANGO: " + botStatus, 32, 190, 8, botColor, Paint.Align.LEFT);
        text(c, "LAST PLAYBACK STATE: " + ageLabel(lastPlaybackPollAt), 32, 202, 6.5f, Color.LTGRAY, Paint.Align.LEFT);

        for (int i = 0; i < 4; i++) {
            int y = 220 + i * 88;
            rect(c, 22, y, 338, y + 78, panel2(), false);
            text(c, names[i] + "  //  " + (online[i] ? "ONLINE" : "OFFLINE"), 32, y + 20, 9,
                    online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, ips[i], 32, y + 39, 8, Color.LTGRAY, Paint.Align.LEFT);
            text(c, "LAST RX: " + ageLabel(lastSeen[i]), 32, y + 57, 7, Color.WHITE, Paint.Align.LEFT);
            int rssi = controllerWifiRssi[i];
            String wifi = lastWifiSeen[i] > 0 && rssi > -127 ? rssi + " dBm" : "N/A";
            text(c, "WI-FI " + wifi, 326, y + 39, 7, rssi >= -67 ? Color.GREEN : rssi > -90 ? 0xFFFFC857 : Color.LTGRAY, Paint.Align.RIGHT);
        }
        if (!lastPlaybackError.isEmpty()) {
            String err = "BOT ERROR: " + lastPlaybackError;
            if (err.length() > 48) err = err.substring(0, 48);
            text(c, err, 24, 584, 7, red(), Paint.Align.LEFT);
        } else {
            text(c, "DIAGNOSTICS ARE READ-ONLY — NO SHOW COMMANDS", 24, 584, 6.5f, Color.LTGRAY, Paint.Align.LEFT);
        }
        pButton(c, 24, 610, 98, 44, "PING ESP32", accent());
        pButton(c, 131, 610, 98, 44, "REFRESH BOT", 0xFF303444);
        pButton(c, 238, 610, 98, 44, "OPEN DEBUG", 0xFF303444);
    }

    void portraitDebug(Canvas c) {
        portraitHeader(c, "DEBUG", "WIRELESS SERIAL MONITOR");
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, "RX 4211  •  TX 4210  •  " + on + "/4 ONLINE", 24, 120, 9, Color.LTGRAY, Paint.Align.LEFT);
        rect(c, 22, 136, 338, 266, panel2(), false);
        text(c, "BOTTANGO PLAYBACK DIAGNOSTICS", 32, 156, 8, accent(), Paint.Align.LEFT);
        String connection = !lastPlaybackError.isEmpty() ? "ERROR: " + lastPlaybackError : playbackStateKnown ? "CONNECTED / STATE RECEIVED" : "WAITING FOR FIRST RESPONSE";
        text(c, connection, 32, 176, 7, !lastPlaybackError.isEmpty() ? red() : playbackStateKnown ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "ANIMATION: " + String.format(Locale.US, "%02d", selectedAnimation) + "  " + animNames[selectedAnimation - 1], 32, 195, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "PLAYBACK: " + (bottangoPlaying ? "PLAYING" : playbackStateKnown ? "STOPPED / IDLE" : "UNKNOWN"), 32, 213, 7, bottangoPlaying ? Color.GREEN : Color.LTGRAY, Paint.Align.LEFT);
        text(c, "TIME: " + formatTime(playbackTimeMs) + " / " + (durationMs > 0 ? formatTime(durationMs) : "DURATION UNKNOWN"), 32, 231, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "AUTO NEXT: " + (autoplay ? "ON" : "OFF") + "  •  LOOP: " + (loop ? "ON" : "OFF"), 32, 249, 7, Color.LTGRAY, Paint.Align.LEFT);
        rect(c, 22, 276, 338, 640, panel2(), false);
        text(c, "EVENT LOG", 30, 294, 7, accent(), Paint.Align.LEFT);
        int start = Math.max(0, log.size() - 18), y = 314;
        for (int i = start; i < log.size(); i++) {
            String line = log.get(i);
            if (line.length() > 46) line = line.substring(0, 46);
            text(c, line, 30, y, 7, Color.LTGRAY, Paint.Align.LEFT);
            y += 19;
        }
        pButton(c, 24, 660, 96, 42, "CLEAR", red());
        pButton(c, 132, 660, 96, 42, "STATUS", accent());
        pButton(c, 240, 660, 96, 42, "TEST ALL", Color.GREEN);
    }

    void portraitErrorPopup(Canvas c) {
        rect(c, 0, 0, 360, 800, 0xDD000000, false);
        rect(c, 22, 270, 338, 530, 0xFF10050A, false);
        rect(c, 22, 270, 338, 530, red(), true);
        text(c, "⚠ SYSTEM ERROR", 180, 310, 17, red(), Paint.Align.CENTER);
        text(c, errorTitle, 180, 350, 12, Color.WHITE, Paint.Align.CENTER);
        text(c, errorMessage, 180, 385, 10, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "Open DEBUG for details", 180, 420, 9, Color.LTGRAY, Paint.Align.CENTER);
        pButton(c, 34, 455, 90, 44, "RETRY", accent());
        pButton(c, 135, 455, 90, 44, "DETAILS", Color.WHITE);
        pButton(c, 236, 455, 90, 44, "CLOSE", red());
    }

    void image(Canvas c, Bitmap b, RectF dst) {
        if (b == null || b.isRecycled()) return;
        float boxW = dst.width(), boxH = dst.height();
        float scale = Math.min(boxW / b.getWidth(), boxH / b.getHeight());
        float dw = b.getWidth() * scale, dh = b.getHeight() * scale;
        float dx = dst.left + (boxW - dw) * 0.5f;
        float dy = dst.top + (boxH - dh) * 0.5f;
        c.drawBitmap(b, null, new RectF(dx, dy, dx + dw, dy + dh), p);
    }

    void drawHome(Canvas c) {
        title(c, "HOME", "WIRELESS SHOW CONTROL");
        image(c, themeCharacter(0), new RectF(15, 50, 230, 178));
        text(c, "FAZBEAR", 245, 74, 22, Color.WHITE, Paint.Align.LEFT);
        text(c, "CONTROL", 245, 98, 22, red(), Paint.Align.LEFT);
        text(c, "4 ESP32 CONTROLLERS", 245, 119, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "PHONE WI-FI", 375, 119, 6, Color.LTGRAY, Paint.Align.LEFT);
        signalBars(c, 427, 127, phoneWifiBars(), phoneWifiBars() >= 3 ? 0xFF43D17D : 0xFFFFC857, 4, 2, 12);
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, on + " / 4 ONLINE", 245, 137, 12, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        button(c, 245, 148, 105, 31, "START SHOW", accent());
        button(c, 360, 148, 105, 31, "DEBUG", Color.DKGRAY);

        button(c, 15, 190, 106, 42, "DEVICES", accent());
        button(c, 130, 190, 106, 42, "TIMELINE", accent());
        button(c, 245, 190, 106, 42, "CONTROL", accent());
        button(c, 360, 190, 105, 42, "SETTINGS", accent());
        text(c, "PHYSICAL ESP32 POTENTIOMETER = VOLUME SOURCE", 240, 250, 6, Color.LTGRAY, Paint.Align.CENTER);
        text(c, status, 240, 265, 6, Color.WHITE, Paint.Align.CENTER);
        for (int i = 0; i < 4; i++) {
            float sx = 90 + i * 88;
            text(c, names[i], sx + 12, 278, 6, Color.LTGRAY, Paint.Align.CENTER);
            int wifiBars = controllerWifiBars(i);
            int wifiColor = wifiBars >= 3 ? 0xFF43D17D : (wifiBars > 0 ? 0xFFFFC857 : 0xFF454754);
            signalBars(c, sx, 299, wifiBars, wifiColor, 4, 2, 12);
        }
        // Tiny live diagnostics line on the home/menu screen.
        int bestRssi = -127;
        long newestRx = 0L;
        for (int i = 0; i < 4; i++) {
            if (controllerWifiRssi[i] > bestRssi && lastWifiSeen[i] > 0L) bestRssi = controllerWifiRssi[i];
            if (lastSeen[i] > newestRx) newestRx = lastSeen[i];
        }
        String wifiSummary = bestRssi > -127 ? bestRssi + " dBm" : "N/A";
        String bottangoSummary = !lastPlaybackError.isEmpty() ? "ERROR" : playbackStateKnown ? "ONLINE" : "WAITING";
        String rxSummary = newestRx > 0L ? ageLabel(newestRx) : "NEVER";
        text(c, "SYS " + on + "/4  |  WIFI " + wifiSummary + "  |  BOTTANGO " + bottangoSummary,
                240, 326, 5.5f, 0xFFB8B6C7, Paint.Align.CENTER);
        text(c, "LAST ESP32 RX: " + rxSummary, 240, 337, 5.5f, 0xFF85899A, Paint.Align.CENTER);
        nav(c, HOME);
    }

    void deviceCard(Canvas c, int i, int y) {
        int a = i == page ? accent() : 0xFF263044;
        rect(c, 10, y, 470, y + 48, panel2(), false);
        rect(c, 10, y, 470, y + 48, a, true);
        image(c, themeCharacter(i), new RectF(16, y + 4, 68, y + 44));
        text(c, "ESP32 - " + names[i], 78, y + 15, 8, Color.WHITE, Paint.Align.LEFT);
        text(c, ips[i], 78, y + 28, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, online[i] ? "● ONLINE" : "● OFFLINE", 78, y + 40, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "Playing: " + playing[i], 205, y + 16, 6.5f, Color.WHITE, Paint.Align.LEFT);
        text(c, "Animation " + String.format(Locale.US, "%02d", i == 3 ? 5 : selectedAnimation), 205, y + 29, 6, accent(), Paint.Align.LEFT);
        button(c, 372, y + 7, 45, 30, "PLAY", Color.GREEN);
        button(c, 423, y + 7, 40, 30, "…", a);
    }

    void drawDevices(Canvas c) {
        title(c, "DEVICES", "4 ESP32 CONTROLLERS");
        for (int i = 0; i < 4; i++) deviceCard(c, i, 47 + i * 51);
        text(c, "TAP A DEVICE FOR ANIMATIONS + PLAYBACK", 240, 262, 5.5f, Color.LTGRAY, Paint.Align.CENTER);
        nav(c, DEVICES);
    }

    void drawDeviceDetail(Canvas c) {
        title(c, "ESP32 - " + names[page], ips[page]);
        button(c, 10, 48, 55, 26, "BACK", accent());
        image(c, themeCharacter(page), new RectF(75, 48, 175, 112));
        text(c, online[page] ? "● ONLINE" : "● OFFLINE", 190, 61, 7, online[page] ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "NOW PLAYING", 190, 78, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, playing[page], 190, 94, 11, Color.WHITE, Paint.Align.LEFT);
        text(c, "VOLUME  " + (syncedVolume >= 0 ? syncedVolume + "%" : "--%") + "  •  ESP32 POT", 190, 108, 6, Color.LTGRAY, Paint.Align.LEFT);

        text(c, "ANIMATIONS", 12, 132, 8, accent(), Paint.Align.LEFT);
        for (int i = 1; i <= 8; i++) {
            int col = (i - 1) % 4, row = (i - 1) / 4;
            int x = 12 + col * 116, y = 140 + row * 30;
            button(c, x, y, 105, 23, String.format(Locale.US, "%02d  %s", i, animNames[i - 1]), i == selectedAnimation ? accent() : 0xFF303444);
        }
        button(c, 12, 205, 92, 29, "PLAY", Color.GREEN);
        button(c, 112, 205, 92, 29, "PAUSE", Color.YELLOW);
        button(c, 212, 205, 92, 29, "RESTART", accent());
        button(c, 312, 205, 56, 29, "BACK", 0xFF303444);
        text(c, "AUTOPLAY NEXT", 15, 252, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, autoplay ? "ON" : "OFF", 110, 252, 7, autoplay ? Color.GREEN : red(), Paint.Align.LEFT);
        text(c, "UDP 4210", 470, 252, 6, Color.LTGRAY, Paint.Align.RIGHT);
    }

    void drawTimeline(Canvas c) {
        title(c, "TIMELINE", "AUDIO PLAYBACK");
        text(c, "NOW PLAYING", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, currentTrackName, 15, 73, 9, Color.WHITE, Paint.Align.LEFT);
        rect(c, 12, 84, 392, 146, panel2(), false);
        rect(c, 12, 84, 392, 146, accent(), true);
        p.setStrokeWidth(2);
        for (int x = 16; x < 390; x += 4) {
            double wave = Math.sin(x * 0.12) * 13 + Math.sin(x * 0.31) * 6 + Math.sin(x * 0.61) * 3;
            p.setColor(x % 24 < 8 ? 0xFFFF1744 : accent());
            c.drawLine(x, 115, x, (float)(115 + wave), p);
        }
        rect(c, 188, 86, 190, 144, Color.WHITE, false);
        text(c, formatTime(playbackTimeMs) + " / " + (durationMs > 0 ? formatTime(durationMs) : "--:--"), 202, 160, 7, Color.WHITE, Paint.Align.CENTER);
        text(c, "L", 420, 92, 6, Color.WHITE, Paint.Align.CENTER);
        text(c, "R", 458, 92, 6, Color.WHITE, Paint.Align.CENTER);
        for (int i = 0; i < 8; i++) {
            int h = 12 + (i % 5) * 5;
            rect(c, 415, 142 - h, 430, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
            rect(c, 448, 142 - h, 463, 142, i < 6 ? Color.GREEN : Color.YELLOW, false);
        }
        button(c, 35, 170, 65, 30, "-5s", accent());
        button(c, 108, 170, 80, 30, "◀◀", accent());
        button(c, 198, 166, 44, 38, "N/A", 0xFF5A4B30);
        button(c, 252, 170, 80, 30, "▶▶", accent());
        button(c, 340, 170, 65, 30, "+5s", accent());
        text(c, "CURRENT EVENT", 15, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "Freddy Move", 15, 238, 9, Color.WHITE, Paint.Align.LEFT);
        text(c, "00:45", 120, 238, 7, accent(), Paint.Align.LEFT);
        button(c, 18, 275, 150, 42, "PICK WAV", accent());
        button(c, 180, 275, 75, 42, localWavPlaying ? "STOP" : "PLAY", localWavPlaying ? red() : Color.GREEN);
        String wavLabel = selectedWavName.length() > 26 ? selectedWavName.substring(0, 25) + "…" : selectedWavName;
        text(c, wavLabel, 18, 333, 7, Color.WHITE, Paint.Align.LEFT);
        text(c, "PHONE WAV PLAYBACK", 18, 350, 5.5f, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "PHYSICAL VOLUME", 280, 222, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%" : "WAITING", 280, 238, 10, Color.WHITE, Paint.Align.LEFT);
        nav(c, TIMELINE);
    }

    void drawControl(Canvas c) {
        title(c, "SHOW CONTROL", "MULTI-ESP32");
        text(c, "SELECTED ANIMATION", 15, 58, 6, Color.LTGRAY, Paint.Align.LEFT);
        text(c, String.format(Locale.US, "%02d  %s", selectedAnimation, animNames[selectedAnimation - 1]), 15, 76, 12, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 92, 106, 40, "PLAY ALL", Color.GREEN);
        button(c, 129, 92, 106, 40, "PAUSE ALL", Color.YELLOW);
        button(c, 243, 92, 108, 40, "RESTART", accent());
        for (int i = 0; i < 4; i++) {
            int x = 15 + (i % 2) * 230, y = 145 + (i / 2) * 48;
            rect(c, x, y, x + 215, y + 40, panel2(), false);
            text(c, names[i], x + 10, y + 15, 7, Color.WHITE, Paint.Align.LEFT);
            text(c, online[i] ? "ONLINE" : "OFFLINE", x + 10, y + 29, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
            text(c, playing[i], x + 85, y + 22, 7, accent(), Paint.Align.LEFT);
        }
        button(c, 15, 243, 140, 25, loop ? "LOOP ON" : "LOOP OFF", loop ? Color.GREEN : Color.DKGRAY);
        button(c, 165, 243, 140, 25, autoplay ? "AUTO NEXT ON" : "AUTO NEXT OFF", autoplay ? Color.GREEN : Color.DKGRAY);
        nav(c, CONTROL);
    }

    void drawSettings(Canvas c) {
        title(c, "SETTINGS", "APP + CONTROLLER STATUS");
        text(c, "CONTROLLER IP ADDRESSES", 15, 57, 7, Color.LTGRAY, Paint.Align.LEFT);
        for (int i = 0; i < 4; i++) {
            int y = 65 + i * 40;
            text(c, names[i], 15, y + 17, 7, Color.WHITE, Paint.Align.LEFT);
            rect(c, 92, y, 280, y + 27, panel2(), false);
            text(c, ips[i], 102, y + 18, 7, Color.WHITE, Paint.Align.LEFT);
            button(c, 292, y, 75, 27, "TEST", accent());
            text(c, online[i] ? "ONLINE" : "OFFLINE", 382, y + 17, 6, online[i] ? Color.GREEN : red(), Paint.Align.LEFT);
        }
        text(c, "VOLUME IS READ-ONLY", 15, 239, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, syncedVolume >= 0 ? syncedVolume + "%  •  SYNCED FROM ESP32 POT" : "WAITING FOR ESP32", 160, 239, 6, Color.WHITE, Paint.Align.LEFT);
        button(c, 15, 250, 110, 25, theme == 0 ? "NEON PURPLE" : "CYAN THEME", accent());
        button(c, 135, 250, 110, 25, "DEBUG", Color.DKGRAY);
        button(c, 255, 250, 110, 25, "CLEAR LOG", red());
        nav(c, SETTINGS);
    }

    void drawDebug(Canvas c) {
        title(c, "DEBUG", "WIRELESS SERIAL + DIAGNOSTICS");
        int on = 0; for (boolean b : online) if (b) on++;
        text(c, "UDP RX 4211", 12, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, "UDP TX 4210", 110, 56, 7, Color.LTGRAY, Paint.Align.LEFT);
        text(c, on + "/4 ONLINE", 220, 56, 7, on == 4 ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "VOLUME " + (syncedVolume >= 0 ? syncedVolume + "%" : "WAITING"), 330, 56, 7, Color.WHITE, Paint.Align.LEFT);
        rect(c, 10, 64, 470, 242, panel2(), false);
        String playbackConn = !lastPlaybackError.isEmpty() ? "ERROR " + lastPlaybackError : playbackStateKnown ? "CONNECTED" : "WAITING";
        text(c, "BOTTANGO: " + playbackConn + "  •  " + (bottangoPlaying ? "PLAYING" : "STOPPED"), 16, 79, 6, !lastPlaybackError.isEmpty() ? red() : playbackStateKnown ? Color.GREEN : Color.YELLOW, Paint.Align.LEFT);
        text(c, "ANIM " + String.format(Locale.US, "%02d", selectedAnimation) + " " + animNames[selectedAnimation - 1] + "  •  " + formatTime(playbackTimeMs) + "/" + (durationMs > 0 ? formatTime(durationMs) : "--:--"), 16, 93, 6, Color.WHITE, Paint.Align.LEFT);
        text(c, "AUTO NEXT " + (autoplay ? "ON" : "OFF") + "  •  LOOP " + (loop ? "ON" : "OFF"), 16, 107, 6, Color.LTGRAY, Paint.Align.LEFT);
        int start = Math.max(0, log.size() - 8), y = 125;
        for (int i = start; i < log.size(); i++) {
            String s = log.get(i);
            if (s.length() > 74) s = s.substring(0, 74);
            text(c, s, 16, y, 5.5f, Color.LTGRAY, Paint.Align.LEFT);
            y += 15;
        }
        button(c, 12, 248, 95, 25, "CLEAR", red());
        button(c, 115, 248, 95, 25, "STATUS", accent());
        button(c, 218, 248, 110, 25, "TEST ALL", Color.GREEN);
        text(c, "ERROR POPUP: READY", 345, 264, 5.5f, errorPopup ? red() : Color.GREEN, Paint.Align.CENTER);
        nav(c, DEBUG);
    }

    void drawErrorPopup(Canvas c) {
        rect(c, 0, 0, 480, 320, 0x99000000, false);
        int l = 42, t = 67, r = 438, b = 252;
        rect(c, l, t, r, b, 0xFF10050A, false);
        rect(c, l, t, r, b, red(), true);
        text(c, "⚠  SYSTEM ERROR", 240, 92, 13, red(), Paint.Align.CENTER);
        text(c, errorTitle, 240, 116, 9, Color.WHITE, Paint.Align.CENTER);
        text(c, errorMessage, 240, 139, 8, Color.LTGRAY, Paint.Align.CENTER);
        text(c, "Details are available in DEBUG.", 240, 160, 6, Color.LTGRAY, Paint.Align.CENTER);
        button(c, 62, 191, 100, 34, "RETRY", accent());
        button(c, 190, 191, 100, 34, "DETAILS", Color.WHITE);
        button(c, 318, 191, 100, 34, "CLOSE", red());
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;

        // Landscape scheduled-show controls use the same logical coordinate system
        // as drawScheduledShowWide().  Handle them BEFORE the portrait 360x800
        // coordinate conversion; otherwise every landscape tap is rejected because
        // the raw landscape coordinates cannot fit inside the portrait bounds.
        if (scheduledShowActive && getWidth() > getHeight()) {
            final float W = 1000f, H = 462f;
            float scaleWide = Math.min(getWidth() / W, getHeight() / H);
            float oxWide = (getWidth() - W * scaleWide) / 2f;
            float oyWide = (getHeight() - H * scaleWide) / 2f;
            float wx = (e.getX() - oxWide) / scaleWide;
            float wy = (e.getY() - oyWide) / scaleWide;

            // Visible STOP SHOW button is x=708..838, y=366..447.
            // Include a generous but bounded hit area around it.
            if (wx >= 680f && wx <= 852f && wy >= 350f && wy <= 455f) {
                stopScheduledShow(true);
                invalidate();
                return true;
            }
            return true;
        }

        float scale = Math.min(getWidth() / 360f, getHeight() / 800f);
        float ox = (getWidth() - 360f * scale) / 2f;
        float oy = (getHeight() - 800f * scale) / 2f;
        float x = (e.getX() - ox) / scale;
        float y = (e.getY() - oy) / scale;
        if (x < 0 || x > 360 || y < 0 || y > 800) return true;

        if (scheduledShowActive) {
            if (y >= 72 && y < 120) {
                stopScheduledShow(true);
            }
            invalidate(); return true;
        }

        if (errorPopup) {
            if (y >= 450 && y <= 510) {
                if (x < 130) retryError();
                else if (x < 230) { errorPopup = false; screen = DEBUG; }
                else errorPopup = false;
            }
            invalidate(); return true;
        }

        if (screen == DEVICE_DETAIL) {
            if (y >= 100 && y < 145) { screen = DEVICES; invalidate(); return true; }
            if (y >= 300 && y < 500) {
                int col = x < 180 ? 0 : 1;
                int row = (int)((y - 304) / 48);
                int a = row * 2 + col + 1;
                if (a >= 1 && a <= 8) { selectedAnimation = a; invalidate(); return true; }
            }
            if (y >= 505 && y < 560) {
                if (x < 180) play(page, selectedAnimation);
                else { send(page, "[PAUSE]"); status = "PAUSED"; }
            } else if (y >= 560 && y < 615) {
                send(page, "[RESTART]");
                status = "RESTARTED";
            } else if (y >= 620 && y < 680) autoplay = !autoplay;
            invalidate(); return true;
        }

        if (y >= 720) {
            int n = Math.max(0, Math.min(5, (int)((x - 14) / 55)));
            int[] screens = {HOME, DEVICES, ANIMATIONS, CONTROL, SCHEDULE, SETTINGS};
            screen = screens[n]; invalidate(); return true;
        }

        if (screen == HOME) {
            if (y >= 450 && y < 520) { playAll(); screen = CONTROL; }
            else if (y >= 525 && y < 580) screen = DEVICES;
            else if (y >= 585 && y < 640) {
                if (x < 180) { screen = TIMELINE; ensureVuPermission(); }
                else if (localWavPlaying) stopLocalWav();
                else playLocalWav();
            }
            else if (y >= 645 && y < 705) screen = CONTROL;
        } else if (screen == DEVICES) {
            if (y >= 112 && y < 680) {
                int i = (int)((y - 112) / 142);
                if (i >= 0 && i < 4) { page = i; screen = DEVICE_DETAIL; }
            }
        } else if (screen == ANIMATIONS) {
            if (y >= 112 && y < 692) {
                int col = x < 180 ? 0 : 1;
                int row = (int)((y - 112) / 145);
                int a = row * 2 + col + 1;
                if (a >= 1 && a <= 8) {
                    selectedAnimation = a;
                    int cardX = col == 0 ? 20 : 184;
                    float localX = x - cardX;
                    int cardY = 112 + row * 145;
                    // The Animations tab is for selecting and customizing slots only.
                    // Playback remains available from the dedicated Control screen.
                    if (y >= cardY + 98 && y < cardY + 129) {
                        if (localX >= 103 && localX <= 151) chooseWavFileForAnimation(a - 1);
                        else if (localX >= 55 && localX < 99) chooseAnimationImage(a - 1);
                        else if (localX >= 5 && localX < 51) editAnimationName(a - 1);
                    }
                }
            }
        } else if (screen == TIMELINE) {
            if (y >= 528 && y < 574) {
                if (x < 218) chooseWavFile();
                else if (localWavPlaying) stopLocalWav();
                else playLocalWav();
            } else if (y >= 608 && y < 650) {
                if (x < 125) seekBy(-5000);
                else if (x >= 235) seekBy(5000);
                else status = "PAUSE NOT SUPPORTED BY BOTTANGO";
            } else if (y >= 180 && y < 330) {
                if (durationMs > 0) {
                    float ratio = Math.max(0f, Math.min(1f, (x - 24f) / 312f));
                    seekTo((int)(durationMs * ratio));
                } else {
                    status = "TIMELINE DURATION NOT PROVIDED BY BOTTANGO";
                }
            } else if (y >= 400 && y < 528) {
                ensureVuPermission();
            }
        } else if (screen == CONTROL) {
            if (y >= 180 && y < 245) {
                if (x < 180) playAll();
                else status = "PAUSE NOT SUPPORTED BY BOTTANGO";
            } else if (y >= 250 && y < 315) {
                if (x < 180) restartShow(); else skipAnimation();
            } else if (y >= 645 && y < 705) {
                if (x < 180) loop = !loop; else autoplay = !autoplay;
            }
        } else if (screen == SCHEDULE) {
            if (y >= 112 && y < 174) { scheduleEnabled = !scheduleEnabled; persistSchedule(); }
            else if (y >= 285 && y < 323) {
                new TimePickerDialog(appContext, (picker, hour, minute) -> { scheduleHour = hour; scheduleMinute = minute; persistSchedule(); invalidate(); }, scheduleHour, scheduleMinute, false).show();
            } else if (y >= 397 && y < 439) { scheduleDays = (scheduleDays + 1) % 3; persistSchedule(); }
            else if (y >= 520 && y < 568) { selectedAnimation = selectedAnimation >= animNames.length ? 1 : selectedAnimation + 1; persistSchedule(); }
            else if (y >= 578 && y < 622) {
                if (x < 180) chooseCountdownWavSlot(1);
                else chooseCountdownWavSlot(2);
            }
            else if (y >= 635 && y < 677) {
                if (x < 180) persistSchedule();
                else { persistSchedule(); startScheduledShow(); }
            }
        } else if (screen == SETTINGS) {
            if (y >= 140 && y < 468) {
                int i = (int)((y - 140) / 82);
                if (i >= 0 && i < 4) {
                    if (x >= 225) send(i, "[STATUS]");
                    else editControllerAddress(i);
                }
            } else if (y >= 492 && y < 532) {
                if (x < 128) selectAudioOutput(0);
                else if (x < 232) selectAudioOutput(1);
                else selectAudioOutput(2);
            } else if (y >= 590 && y < 630) showThemeCustomization();
            else if (y >= 638 && y < 682) {
                if (x < 125) screen = DIAGNOSTICS;
                else if (x < 235) screen = DEBUG;
                else log.clear();
            } else if (y >= 684 && y < 719) showShowTimingSettings();
        } else if (screen == DIAGNOSTICS) {
            if (y >= 605 && y < 670) {
                if (x < 125) {
                    for (int i = 0; i < 4; i++) send(i, "[STATUS]");
                    status = "DIAGNOSTIC STATUS REQUEST SENT";
                    addLog("DIAGNOSTICS // STATUS REQUEST SENT TO ALL CONTROLLERS");
                } else if (x < 235) {
                    pollBottangoState();
                    addLog("DIAGNOSTICS // BOTTANGO STATE REFRESH REQUESTED");
                } else {
                    screen = DEBUG;
                }
            }
        } else if (screen == DEBUG) {
            if (y >= 655 && y < 710) {
                if (x < 125) log.clear();
                else if (x < 235) for (int i = 0; i < 4; i++) send(i, "[STATUS]");
                else broadcast("[STATUS]");
            }
        }
        invalidate(); return true;
    }

    boolean touchDeviceDetail(float x, float y) {
        if (y >= 48 && y <= 78 && x < 70) { screen = DEVICES; invalidate(); return true; }
        if (y >= 140 && y < 200) {
            int col = (int)((x - 12) / 116), row = (int)((y - 140) / 30);
            if (col >= 0 && col < 4 && row >= 0 && row < 2) {
                int a = row * 4 + col + 1;
                selectedAnimation = a;
                play(page, a);
                invalidate(); return true;
            }
        }
        if (y >= 205 && y < 240) {
            if (x < 104) { play(page, selectedAnimation); }
            else if (x < 204) { send(page, "[PAUSE]"); status = "PAUSED " + names[page]; }
            else if (x < 304) { send(page, "[RESTART]"); progress[page] = 0; status = "RESTARTED " + names[page]; }
            else { screen = DEVICES; }
            invalidate(); return true;
        }
        if (y >= 240 && y < 270 && x < 160) { autoplay = !autoplay; invalidate(); return true; }
        return true;
    }
}
