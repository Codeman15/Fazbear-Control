Fazbear Control - Outro audio update

The coded Halloween outro now plays the soundtrack extracted from the user-provided
Videoleap_2026_10_08_15_11_47_094.mp4 file. The Android app renders the outro graphics
in Java; the MP4 video itself is not included or played. The extracted audio is stored
as app/src/main/res/raw/scheduled_outro_audio.m4a and is played at 100% MediaPlayer
volume. The existing 3-second delay before the coded outro and the intro soundtrack
behavior are preserved. Countdown/intermission/animation WAV volume settings remain
unchanged at the project's existing 100% setting.
