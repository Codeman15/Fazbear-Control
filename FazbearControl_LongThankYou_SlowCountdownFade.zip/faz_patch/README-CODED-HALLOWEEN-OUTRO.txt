CODED HALLOWEEN OUTRO UPDATE

- The Halloween outro is rendered natively in Java and plays silently.
- The old outro_chimes.mp3 resource has been removed.
- Countdown WAV 1, countdown WAV 2, intermission playlist WAVs, and assigned animation WAVs use 100% player volume. Existing timed fades remain in effect, so WAV 1 and WAV 2 still fade at their configured transition points.
- The coded intro soundtrack also uses 100% volume.
- The 3-second delay after show completion is unchanged.
