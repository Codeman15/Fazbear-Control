OUTRO + WAV VOLUME UPDATE

- The Halloween show outro is recreated natively in Java. No MP4 is required or bundled.
- It shows “Thanks for stopping by” followed by “Happy Halloween” on black.
- Chimes 2.mp3 is bundled as app/src/main/res/raw/outro_chimes.mp3 and plays once at 75% volume.
- The native outro starts 3 seconds after show completion and runs about 18.25 seconds.
- Countdown WAV 1 and WAV 2 continue to play for every scheduled countdown (WAV 1 first, WAV 2 during the final 5:30), restart from WAV 1 after each completed show, and use 75% volume with existing fades.
