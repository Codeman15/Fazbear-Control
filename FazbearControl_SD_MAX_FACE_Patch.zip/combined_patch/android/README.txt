Replace app/src/main/java/com/fazbear/control/MainActivity.java with this patched version.
It preserves the existing Phone/stop logic and adds matching numbered Freddy SD audio commands for MAX/BOTH.
