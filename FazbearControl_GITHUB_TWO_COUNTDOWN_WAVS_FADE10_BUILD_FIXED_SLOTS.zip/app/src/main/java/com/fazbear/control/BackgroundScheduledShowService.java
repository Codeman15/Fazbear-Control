package com.fazbear.control;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Owns the complete scheduled-show state machine when Fazbear Control is not visible.
 * The alarm only wakes/starts this service; it never starts an individual animation.
 */
public final class BackgroundScheduledShowService extends Service {
    private static final String CHANNEL_ID = "fazbear_scheduled_show";
    private static final int NOTIFICATION_ID = 7815;
    private static final long INTERMISSION_WINDOW_MS = 45L * 60_000L;
    private static final long FADE_START_MS = 30_000L;
    private static final long FADE_END_MS = 10_000L;
    private static final long TICK_MS = 250L;

    private final AtomicInteger generation = new AtomicInteger();
    private volatile boolean running;
    private Thread worker;
    private MediaPlayer player;
    private long showTargetMs;
    private long repeatIntervalMs;
    private boolean intermission;
    private int intermissionIndex;
    private String countdownWav1Uri, countdownWav2Uri;
    private int countdownHalf;
    private long countdownStartMs, countdownMidpointMs;
    private int currentSlot = -1;
    private int configuredStartSlot;
    private String[] animationUris = new String[8];
    private long[] manualDurations = new long[8];
    private int audioMode;
    private boolean manualTiming;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences prefs = getSharedPreferences("fazbear", MODE_PRIVATE);
        if (!prefs.getBoolean("schedule_enabled", false) || MainActivity.isAppVisible()) {
            stopSelf();
            return START_NOT_STICKY;
        }

        long target = intent != null ? intent.getLongExtra("show_target_ms", 0L) : 0L;
        int selected = intent != null ? intent.getIntExtra("animation", prefs.getInt("schedule_animation", 1))
                : prefs.getInt("schedule_animation", 1);
        if (target <= 0L) target = System.currentTimeMillis();

        startForeground(NOTIFICATION_ID, buildNotification("Scheduled show preparing"));
        if (running) return START_STICKY;

        configuredStartSlot = clampSlot(selected - 1);
        showTargetMs = target;
        loadConfig(prefs);
        repeatIntervalMs = calculateRepeatInterval(prefs, showTargetMs);
        running = true;
        worker = new Thread(this::runShow, "Fazbear-Background-Show");
        worker.start();
        return START_STICKY;
    }

    private void loadConfig(SharedPreferences prefs) {
        audioMode = prefs.getInt("audio_output_mode", 0);
        manualTiming = prefs.getBoolean("manual_timing_mode", false);
        countdownWav1Uri = prefs.getString("countdown_wav_1_uri", null);
        countdownWav2Uri = prefs.getString("countdown_wav_2_uri", null);
        for (int i = 0; i < 8; i++) {
            animationUris[i] = prefs.getString("animWavUri" + i, null);
            manualDurations[i] = Math.max(1000L, prefs.getLong("manual_duration_" + i, 1000L));
        }
    }

    private long calculateRepeatInterval(SharedPreferences prefs, long target) {
        long next = ScheduleAlarm.nextTime(prefs.getInt("schedule_hour", 19),
                prefs.getInt("schedule_minute", 0), prefs.getInt("schedule_days", 0), target);
        long interval = next - target;
        return interval > 0L ? interval : 24L * 60 * 60_000L;
    }

    private void runShow() {
        try {
            while (running && !MainActivity.isAppVisible() && isScheduleEnabled()) {
                loadConfig(getSharedPreferences("fazbear", MODE_PRIVATE));
                runOneScheduledCycle();
                if (!running || MainActivity.isAppVisible() || !isScheduleEnabled()) break;
                showTargetMs = System.currentTimeMillis() + Math.max(1000L, repeatIntervalMs);
            }
        } finally {
            stopPlayer();
            running = false;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    }

    private void runOneScheduledCycle() {
        intermission = false;
        currentSlot = -1;
        postStatus("Scheduled show countdown");

        long now = System.currentTimeMillis();
        countdownStartMs = now;
        countdownMidpointMs = now + Math.max(0L, (showTargetMs - now) / 2L);
        countdownHalf = 1;
        if (audioMode != 0 && countdownWav1Uri != null && !countdownWav1Uri.isEmpty()) {
            intermission = true;
            playCountdownWav(countdownWav1Uri);
        }
        while (running && !MainActivity.isAppVisible() && isScheduleEnabled() && System.currentTimeMillis() < showTargetMs) {
            now = System.currentTimeMillis();
            long remaining = showTargetMs - now;
            if (now >= countdownMidpointMs && countdownHalf != 2) {
                countdownHalf = 2;
                stopPlayer();
                if (audioMode != 0 && countdownWav2Uri != null && !countdownWav2Uri.isEmpty()) playCountdownWav(countdownWav2Uri);
            }
            if (intermission) applyFade(now);
            updateNotification(remaining > 0 ? "Show starts in " + formatCountdown(remaining) : "Starting show");
            sleep(TICK_MS);
        }

        if (!running || MainActivity.isAppVisible() || !isScheduleEnabled()) return;
        stopPlayer();
        intermission = false;

        int slot = findNextPlayableSlot(configuredStartSlot);
        if (slot < 0) {
            sendAll("[STOP]");
            postStatus("WAV ERROR — no detectable WAV files; timer restarted");
            showTargetMs = System.currentTimeMillis() + Math.max(1000L, repeatIntervalMs);
            return;
        }

        while (running && !MainActivity.isAppVisible() && isScheduleEnabled()) {
            currentSlot = slot;
            sendAll("[START " + (slot + 1) + "]");
            updateNotification("Animation " + (slot + 1) + " running");

            long duration = getAnimationDuration(slot);
            boolean phonePlayback = audioMode != 0;
            if (phonePlayback) startAnimationAudio(slot);

            long deadline = System.currentTimeMillis() + duration;
            while (running && !MainActivity.isAppVisible() && isScheduleEnabled()) {
                if (phonePlayback && player == null) break;
                if (System.currentTimeMillis() >= deadline) break;
                sleep(TICK_MS);
            }
            stopPlayer();

            int next = findNextPlayableSlot((slot + 1) % 8);
            if (next < 0) {
                sendAll("[STOP]");
                postStatus("Scheduled show complete — no more playable WAVs");
                break;
            }
            slot = next;
        }

        sendAll("[STOP]");
        // Preserve the original schedule interval, just like the foreground scheduler.
        showTargetMs = System.currentTimeMillis() + Math.max(1000L, repeatIntervalMs);
        postStatus("Scheduled show complete — timer reset");
    }

    private int findNextPlayableSlot(int from) {
        int start = clampSlot(from);
        for (int n = 0; n < 8; n++) {
            int slot = (start + n) % 8;
            // Slots 7/8 remain optional until a detectable WAV is assigned.
            if ((slot == 6 || slot == 7) && !isPlayableWav(slot)) continue;
            if (isPlayableWav(slot)) return slot;
        }
        return -1;
    }

    private boolean isPlayableWav(int slot) {
        if (slot < 0 || slot >= animationUris.length) return false;
        String uri = animationUris[slot];
        if (uri == null || uri.trim().isEmpty()) return false;
        try {
            android.content.res.AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(Uri.parse(uri), "r");
            if (afd == null) return false;
            afd.close();
            return true;
        } catch (Exception e) { return false; }
    }

    private long getAnimationDuration(int slot) {
        String uri = animationUris[slot];
        if (uri != null) {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            try {
                mmr.setDataSource(this, Uri.parse(uri));
                String value = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                long ms = value == null ? 0L : Long.parseLong(value);
                if (ms > 0L) return ms;
            } catch (Exception ignored) {
            } finally {
                try { mmr.release(); } catch (Exception ignored) { }
            }
        }
        return manualTiming ? manualDurations[slot] : Math.max(1000L, manualDurations[slot]);
    }

    private void startAnimationAudio(int slot) {
        stopPlayer();
        String uri = animationUris[slot];
        if (uri == null) return;
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setDataSource(this, Uri.parse(uri));
            mp.setOnCompletionListener(p -> { synchronized (BackgroundScheduledShowService.this) { if (player == p) player = null; } });
            mp.setOnErrorListener((p, what, extra) -> { synchronized (BackgroundScheduledShowService.this) { if (player == p) player = null; } return true; });
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            stopPlayer();
        }
    }

    private void playCountdownWav(String uri) {
        stopPlayer();
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setDataSource(this, Uri.parse(uri));
            mp.setOnCompletionListener(p -> {
                synchronized (BackgroundScheduledShowService.this) {
                    if (player == p) player = null;
                }
                if (running && intermission && System.currentTimeMillis() < showTargetMs) {
                    String next = countdownHalf == 1 ? countdownWav1Uri : countdownWav2Uri;
                    if (next != null) playCountdownWav(next);
                }
            });
            mp.setOnErrorListener((p, what, extra) -> { synchronized (BackgroundScheduledShowService.this) { if (player == p) player = null; } return true; });
            mp.prepare();
            mp.start();
        } catch (Exception e) { stopPlayer(); }
    }

    private void startIntermission() {
        SharedPreferences prefs = getSharedPreferences("fazbear", MODE_PRIVATE);
        String saved = prefs.getString("intermission_wav_playlist", "[]");
        java.util.ArrayList<String> uris = new java.util.ArrayList<>();
        try {
            org.json.JSONArray arr = new org.json.JSONArray(saved);
            for (int i = 0; i < arr.length(); i++) {
                String uri = arr.optJSONObject(i) == null ? "" : arr.optJSONObject(i).optString("uri", "");
                if (!uri.isEmpty() && isReadable(uri)) uris.add(uri);
            }
        } catch (Exception ignored) { }
        if (uris.isEmpty()) return;
        intermissionIndex = 0;
        playIntermissionTrack(uris);
    }

    private void playIntermissionTrack(java.util.ArrayList<String> uris) {
        if (!running || !intermission || System.currentTimeMillis() >= showTargetMs || uris.isEmpty()) return;
        stopPlayer();
        String uri = uris.get(intermissionIndex % uris.size());
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setDataSource(this, Uri.parse(uri));
            mp.setOnCompletionListener(p -> {
                if (running && intermission && System.currentTimeMillis() < showTargetMs) {
                    intermissionIndex = (intermissionIndex + 1) % uris.size();
                    playIntermissionTrack(uris);
                }
            });
            mp.setOnErrorListener((p, what, extra) -> {
                if (running && intermission && System.currentTimeMillis() < showTargetMs) {
                    intermissionIndex = (intermissionIndex + 1) % uris.size();
                    playIntermissionTrack(uris);
                }
                return true;
            });
            mp.prepare();
            mp.start();
        } catch (Exception ignored) { }
    }

    private boolean isReadable(String uri) {
        try {
            android.content.res.AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(Uri.parse(uri), "r");
            if (afd == null) return false;
            afd.close();
            return true;
        } catch (Exception e) { return false; }
    }

    private void applyFade(long now) {
        if (player == null || !player.isPlaying()) return;
        long remainingToMidpoint = countdownMidpointMs - now;

        // WAV 1 fades during the final 10 seconds before WAV 2 starts.
        if (countdownHalf == 1) {
            float volume = remainingToMidpoint <= 0L ? 0f
                    : remainingToMidpoint < 10_000L ? remainingToMidpoint / 10_000f : 1f;
            try { player.setVolume(volume, volume); } catch (Exception ignored) { }
            return;
        }

        // WAV 2 fades during the final 20 seconds before the show.
        long remaining = Math.max(0L, showTargetMs - now);
        float volume = remaining >= 20_000L ? 1f : remaining <= 0L ? 0f : remaining / 20_000f;
        try { player.setVolume(volume, volume); } catch (Exception ignored) { }
    }

    private void sendAll(String command) {
        SharedPreferences prefs = getSharedPreferences("fazbear", MODE_PRIVATE);
        String[] defaults = {"10.0.0.28", "10.0.0.102", "10.0.0.103", "10.0.0.104"};
        for (int i = 0; i < 4; i++) {
            String ip = prefs.getString("ip" + i, defaults[i]);
            try (DatagramSocket socket = new DatagramSocket()) {
                byte[] data = command.getBytes("UTF-8");
                socket.send(new DatagramPacket(data, data.length, InetAddress.getByName(ip), 4210));
            } catch (Exception ignored) { }
        }
    }

    private boolean isScheduleEnabled() {
        return getSharedPreferences("fazbear", MODE_PRIVATE).getBoolean("schedule_enabled", false);
    }

    private int clampSlot(int slot) { return Math.max(0, Math.min(7, slot)); }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); running = false; }
    }

    private void stopPlayer() {
        MediaPlayer mp;
        synchronized (this) { mp = player; player = null; }
        if (mp != null) {
            try { if (mp.isPlaying()) mp.stop(); } catch (Exception ignored) { }
            try { mp.reset(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
        }
    }

    private String formatCountdown(long ms) {
        long total = Math.max(0L, (ms + 999L) / 1000L);
        long h = total / 3600L;
        long m = (total % 3600L) / 60L;
        long s = total % 60L;
        return String.format(java.util.Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Scheduled Shows", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Fazbear Control background scheduled show");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Fazbear Control")
                .setContentText(text).setOngoing(true).build();
    }

    private void updateNotification(String text) {
        try { getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, buildNotification(text)); } catch (Exception ignored) { }
    }

    private void postStatus(String text) { updateNotification(text); }

    @Override public void onDestroy() {
        running = false;
        generation.incrementAndGet();
        stopPlayer();
        Thread t = worker;
        if (t != null) t.interrupt();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
