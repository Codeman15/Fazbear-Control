FULL 24MB-BUDGET BUILD

Preserved from the scheduled-show timer build:
- Full Android app source and Gradle project
- Scheduled show countdown and restart behavior
- Original-duration timer reset for each scheduled run
- Landscape live Show Timer
- Stop Show touch handling
- Phone audio/intermission scheduling behavior
- Existing app features and configuration files

Photo set:
- All 50 theme character/background/stage photos
- Theme 10 character/background/stage photos
- Default Freddy/Bonnie/Chica/Stage photos
- Schedule/timer artwork

Theme photos were converted to LOSSLESS WebP. This changes storage format only; image pixels are preserved and Android resource names remain the same (R.drawable names are unchanged).
