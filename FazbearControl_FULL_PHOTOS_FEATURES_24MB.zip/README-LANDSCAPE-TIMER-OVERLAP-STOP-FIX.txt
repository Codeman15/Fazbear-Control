LANDSCAPE TIMER / STOP BUTTON FIX

- Keeps the 1536x864 timer artwork at its original aspect ratio; it is fitted to the phone landscape view instead of stretched.
- Corrects the live-value cover rectangles so black cover areas stay inside the intended value fields.
- Keeps the artwork labels, borders, characters, and control panels visible.
- Replaces only the sample countdown digits with the live countdown.
- Corrects the red STOP SHOW touch target to the actual button location in the artwork.
- STOP SHOW still stops the scheduled show, phone WAV audio, controllers, and Bottango, then returns the app to portrait.

Build note: this environment could not build the APK because the Gradle wrapper attempted to download Gradle and network access was unavailable.
