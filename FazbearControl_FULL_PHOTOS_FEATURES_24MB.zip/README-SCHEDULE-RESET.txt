SCHEDULE SHOW/TIMER RESET FIX

When a scheduled show completes, the app now automatically resets the scheduled-show state to the next scheduled occurrence.

- Resets to Animation 1.
- Stops any remaining phone WAV and controller playback.
- Clears completed-show state.
- Recalculates the timer from the current time to the next scheduled run.
- Keeps the schedule timer ready for the next run instead of remaining on SHOW COMPLETE.
- The next scheduled run starts the show from the beginning again.

The Android build could not be compiled in this environment because Gradle 9.3.0 is not cached and internet access is unavailable.
