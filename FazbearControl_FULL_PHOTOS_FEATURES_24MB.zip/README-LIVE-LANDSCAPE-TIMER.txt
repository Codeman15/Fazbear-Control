LIVE LANDSCAPE TIMER UPDATE

The supplied Show Timer artwork is the default schedule_timer_photo resource.
When a scheduled show starts, the Activity switches to landscape automatically.
The landscape screen uses the artwork's 1536x691 timer region without stretching,
and the printed sample digits are covered by the live countdown value.
The X / EXIT SHOW button stops the show and returns the Activity to portrait.
The adjacent SHOW CONTROL block remains informational/non-clickable.
