FAZBEAR CONTROL - LANDSCAPE TIMER OVERLAP FIX

Changes:
- Removed duplicate/ghosted schedule and intermission text from the live landscape timer.
- The artwork remains the background and its original labels/borders are preserved.
- Only live values are drawn into the existing value fields.
- The sample timer digits are covered and replaced by the live countdown.
- STOP SHOW remains mapped to the red STOP SHOW button; the adjacent LOCKED panel is inert.
- ZIP is intended to remain under the 24 MB upload limit.

Build note: Android Gradle build could not be completed in this offline environment because Gradle 9.3.0 is not cached and the wrapper attempted to reach services.gradle.org.
